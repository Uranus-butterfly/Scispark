@echo off
chcp 65001 >nul
title SciSpark - 停止
cd /d "%~dp0"

python tools\launcher.py --stop
echo.
pause
