#!/bin/bash
# 双击这个文件停止 SciSpark（数据保留在 ./data）
cd "$(dirname "$0")" || exit 1

# 自愈：去掉隔离标记，避免以后双击又被 macOS 拦
if command -v xattr >/dev/null 2>&1; then
  xattr -dr com.apple.quarantine . 2>/dev/null
fi
for f in "启动.command" "停止.command"; do
  chmod +x "$f" 2>/dev/null
done

python3 tools/launcher.py --stop
echo
read -r -p "按回车关闭窗口…" _
