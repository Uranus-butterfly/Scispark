import { useState } from "react";
import { NavLink, Outlet, useLocation, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  FolderKanban,
  FolderOpen,
  GitBranch,
  Library,
  Lightbulb,
  MessagesSquare,
  Network,
  Radar,
  Settings as SettingsIcon,
  Sparkles,
  LayoutDashboard,
  ChevronLeft,
  Power,
} from "lucide-react";
import { projectsApi, settingsApi, systemApi } from "@/lib/api";
import { cn, formatCny } from "@/lib/utils";
import { pickName, useT } from "@/lib/i18n";

const globalNav = [
  { to: "/", label: "项目", icon: FolderKanban, end: true },
  { to: "/settings", label: "设置", icon: SettingsIcon, end: false },
];

const projectNav = [
  { seg: "", label: "工作台", icon: LayoutDashboard },
  { seg: "papers", label: "论文库", icon: Library },
  { seg: "local", label: "本地论文", icon: FolderOpen },
  { seg: "chat", label: "共创对话", icon: MessagesSquare },
  { seg: "mindmap", label: "研究脑图", icon: GitBranch },
  { seg: "graph", label: "论文图谱", icon: Network },
  { seg: "ideas", label: "创新点", icon: Lightbulb },
  { seg: "scan", label: "进展扫描", icon: Radar },
];

function Logo() {
  const { t } = useT();
  return (
    <div className="flex items-center gap-2.5 px-4 py-4">
      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-violet-500 text-white shadow-sm shadow-brand-600/25">
        <Sparkles size={16} strokeWidth={2.2} />
      </div>
      <div className="leading-tight">
        <div className="text-[14px] font-semibold tracking-tight text-ink-900">SciSpark</div>
        <div className="text-[11px] text-ink-400">{t("科研创新助手")}</div>
      </div>
    </div>
  );
}

/** 左侧栏的语言滑块：滑到左边统一中文，滑到右边统一英文（界面 + 调研结果一起变）。 */
function LangSwitch() {
  const { lang, setLang } = useT();
  return (
    <div className="mx-3 mb-2 flex items-center gap-0.5 rounded-lg border border-line bg-canvas p-0.5">
      <button
        onClick={() => setLang("zh")}
        className={cn(
          "flex-1 rounded-md px-2 py-1 text-[11px] transition-colors",
          lang === "zh"
            ? "bg-surface font-medium text-ink-900 shadow-sm"
            : "text-ink-400 hover:text-ink-700",
        )}
      >
        中文
      </button>
      <button
        onClick={() => setLang("en")}
        className={cn(
          "flex-1 rounded-md px-2 py-1 text-[11px] transition-colors",
          lang === "en"
            ? "bg-surface font-medium text-ink-900 shadow-sm"
            : "text-ink-400 hover:text-ink-700",
        )}
      >
        English
      </button>
    </div>
  );
}

function CostCard() {
  const { t } = useT();
  const { data } = useQuery({
    queryKey: ["cost"],
    queryFn: settingsApi.cost,
    refetchInterval: 30_000,
    retry: false,
  });
  const b = data?.budget;
  const pct = b && b.limit_cny > 0 ? Math.min(100, (b.today_cny / b.limit_cny) * 100) : 0;

  return (
    <div className="mx-3 mb-3 rounded-lg border border-line bg-canvas/70 px-3 py-2.5">
      <div className="flex items-center justify-between text-[11px] text-ink-500">
        <span>{t("今日花费")}</span>
        <span className="font-mono text-ink-700">{formatCny(b?.today_cny)}</span>
      </div>
      <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-line">
        <div
          className={cn(
            "h-full rounded-full transition-all",
            pct > 85 ? "bg-red-500" : pct > 60 ? "bg-amber-500" : "bg-brand-500",
          )}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="mt-1.5 flex items-center justify-between text-[10px] text-ink-400">
        <span>{t("上限")} {formatCny(b?.limit_cny, 0)}</span>
        <span className={data?.peak ? "text-amber-600" : "text-emerald-600"}>
          {data?.peak ? t("高峰价") : t("空闲价")}
        </span>
      </div>
    </div>
  );
}

function ProjectHeader({ projectId }: { projectId: string }) {
  const { t } = useT();
  const { data: project } = useQuery({
    queryKey: ["project", projectId],
    queryFn: () => projectsApi.get(projectId),
    retry: false,
  });

  return (
    <div className="border-b border-line px-3 py-2.5">
      <NavLink
        to="/"
        className="mb-2 inline-flex items-center gap-1 rounded-md px-1 py-0.5 text-[11px] text-ink-400 transition-colors hover:text-ink-700"
      >
        <ChevronLeft size={12} /> {t("全部项目")}
      </NavLink>
      <div className="px-1">
        <div className="truncate text-[13px] font-semibold text-ink-900">
          {project ? pickName(project.name, project.name_en) : t("加载中…")}
        </div>
        <div className="mt-0.5 line-clamp-2 text-[11px] leading-relaxed text-ink-400">
          {project?.topic ?? ""}
        </div>
      </div>
      <nav className="mt-2.5 space-y-0.5">
        {projectNav.map((item) => (
          <NavLink
            key={item.seg}
            to={`/p/${projectId}${item.seg ? `/${item.seg}` : ""}`}
            end={!item.seg}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2 rounded-md px-2 py-1.5 text-[13px] transition-colors",
                isActive
                  ? "bg-brand-50 font-medium text-brand-700"
                  : "text-ink-500 hover:bg-canvas hover:text-ink-900",
              )
            }
          >
            <item.icon size={14} />
            {t(item.label)}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}

export default function AppShell() {
  const { t } = useT();
  const params = useParams();
  const location = useLocation();
  const projectId = location.pathname.startsWith("/p/") ? params.projectId : undefined;
  const [closed, setClosed] = useState(false);

  const onShutdown = async () => {
    if (!window.confirm(t("关闭后服务会停止，正在跑的调研/扫描也会中断。确定关闭？"))) return;
    try {
      await systemApi.shutdown();
    } catch {
      /* 服务已经先挂了也算成功 */
    }
    setClosed(true);
  };

  if (closed) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 bg-canvas px-6 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface text-ink-400 shadow-sm">
          <Power size={20} />
        </div>
        <div className="text-[15px] font-semibold text-ink-900">{t("SciSpark 已关闭")}</div>
        <div className="max-w-md text-[12.5px] leading-relaxed text-ink-500">
          {t("数据都在")} <code className="rounded bg-surface px-1 font-mono">data/</code> {t("里，没有丢。")}
          {t("下次双击「启动」脚本就能继续。")}
          <br />
          {t("现在可以关掉这个标签页了。")}
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full">
      <aside className="flex w-56 shrink-0 flex-col border-r border-line bg-surface">
        <Logo />
        <LangSwitch />
        {projectId ? (
          <ProjectHeader projectId={projectId} />
        ) : (
          <nav className="space-y-0.5 px-3">
            {globalNav.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-2 rounded-lg px-2.5 py-2 text-[13px] transition-colors",
                    isActive
                      ? "bg-brand-50 font-medium text-brand-700"
                      : "text-ink-500 hover:bg-canvas hover:text-ink-900",
                  )
                }
              >
                <item.icon size={15} />
                {t(item.label)}
              </NavLink>
            ))}
          </nav>
        )}
        <div className="flex-1" />
        <CostCard />
        <button
          onClick={onShutdown}
          className="mx-3 mb-3 flex items-center justify-center gap-1.5 rounded-lg border border-line px-2 py-1.5 text-[11.5px] text-ink-500 transition-colors hover:border-red-200 hover:bg-red-50 hover:text-red-600"
          title={t("停止服务（也可以双击「停止」脚本）")}
        >
          <Power size={12} /> {t("关闭 SciSpark")}
        </button>
      </aside>
      <main className="min-w-0 flex-1 overflow-y-auto">
        <Outlet />
      </main>
    </div>
  );
}
