import type { HTMLAttributes, InputHTMLAttributes, ReactNode, TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Card({ className, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-xl border border-line bg-surface shadow-[0_1px_2px_rgba(15,23,42,0.04)]",
        className,
      )}
      {...rest}
    />
  );
}

export function CardHeader({
  title,
  desc,
  right,
  className,
}: {
  title: ReactNode;
  desc?: ReactNode;
  right?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-start justify-between gap-4 px-5 pt-4 pb-3", className)}>
      <div className="min-w-0">
        <div className="text-[15px] font-semibold text-ink-900">{title}</div>
        {desc && <div className="mt-0.5 text-[13px] leading-relaxed text-ink-500">{desc}</div>}
      </div>
      {right && <div className="shrink-0">{right}</div>}
    </div>
  );
}

export function Input({ className, ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-9 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink-900",
        "placeholder:text-ink-400 transition-colors",
        "focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/15",
        "disabled:bg-canvas disabled:text-ink-400",
        className,
      )}
      {...rest}
    />
  );
}

export function Textarea({ className, ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(
        "w-full rounded-lg border border-line bg-white px-3 py-2 text-sm leading-relaxed text-ink-900",
        "placeholder:text-ink-400 transition-colors resize-y",
        "focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/15",
        className,
      )}
      {...rest}
    />
  );
}

export function Field({
  label,
  hint,
  children,
  className,
}: {
  label: ReactNode;
  hint?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <div className="text-[13px] font-medium text-ink-700">{label}</div>
      {children}
      {hint && <div className="text-xs leading-relaxed text-ink-400">{hint}</div>}
    </div>
  );
}
