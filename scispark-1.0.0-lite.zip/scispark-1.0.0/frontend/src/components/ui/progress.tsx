import { cn } from "@/lib/utils";

export function Progress({
  value,
  className,
  indeterminate,
}: {
  value: number;
  className?: string;
  indeterminate?: boolean;
}) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  return (
    <div className={cn("h-1.5 w-full overflow-hidden rounded-full bg-line", className)}>
      <div
        className={cn(
          "h-full rounded-full bg-brand-500 transition-[width] duration-500 ease-out",
          indeterminate && "animate-pulse",
        )}
        style={{ width: `${indeterminate ? 100 : pct}%` }}
      />
    </div>
  );
}
