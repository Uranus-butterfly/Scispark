/** 后端 API 封装。 */

const BASE = "/api";

export class ApiError extends Error {
  status: number;
  detail?: string;
  constructor(status: number, message: string, detail?: string) {
    super(message);
    this.status = status;
    this.detail = detail;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
    ...init,
  });
  if (!res.ok) {
    let detail = "";
    try {
      const body = await res.json();
      detail = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      detail = await res.text().catch(() => "");
    }
    throw new ApiError(res.status, detail || `请求失败（${res.status}）`, detail);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export const api = {
  get: <T>(p: string) => request<T>(p),
  post: <T>(p: string, body?: unknown) =>
    request<T>(p, { method: "POST", body: body ? JSON.stringify(body) : undefined }),
  put: <T>(p: string, body?: unknown) =>
    request<T>(p, { method: "PUT", body: body ? JSON.stringify(body) : undefined }),
  patch: <T>(p: string, body?: unknown) =>
    request<T>(p, { method: "PATCH", body: body ? JSON.stringify(body) : undefined }),
  del: <T>(p: string) => request<T>(p, { method: "DELETE" }),
};

// ---------------- 类型 ----------------
export interface Project {
  id: string;
  name: string;
  name_en?: string | null;
  topic: string;
  description?: string | null;
  status: string;
  created_at: string;
  updated_at: string;
  paper_count: number;
  idea_count: number;
  rq_count: number;
}

export interface SettingItem {
  value: string;
  secret: boolean;
  label: string;
  configured: boolean;
  raw_empty: boolean;
}

export interface BudgetInfo {
  today_cny: number;
  month_cny: number;
  limit_cny: number;
  remaining_cny: number;
}

export interface SettingsPayload {
  items: Record<string, SettingItem>;
  budget: BudgetInfo;
  cache: { entries: number; bytes: number; dir: string };
  pricing: {
    peak: boolean;
    hint: string;
    usd_to_cny: number;
    models: { flash: string; pro: string };
    table: Record<string, { cache_hit: number; input: number; output: number }>;
  };
}

// ---------------- 端点 ----------------
export const projectsApi = {
  list: () => api.get<Project[]>("/projects"),
  get: (id: string) => api.get<Project>(`/projects/${id}`),
  create: (body: { name: string; name_en?: string; topic: string; description?: string }) =>
    api.post<Project>("/projects", body),
  update: (id: string, body: Partial<Pick<Project, "name" | "name_en" | "topic" | "description" | "status">>) =>
    api.patch<Project>(`/projects/${id}`, body),
  remove: (id: string) => api.del<{ ok: boolean }>(`/projects/${id}`),
};

export const settingsApi = {
  read: () => api.get<SettingsPayload>("/settings"),
  write: (values: Record<string, string>) =>
    api.put<SettingsPayload>("/settings", { values }),
  /** 带上表单里还没保存的值，后端临时覆盖、不写库 */
  testLlm: (values?: Record<string, string>) =>
    api.post<{ ok: boolean; message?: string; data?: unknown }>("/settings/test-llm", {
      values: values ?? {},
    }),
  cost: () => api.get<{ budget: BudgetInfo; peak: boolean; peak_hint: string }>("/settings/cost"),
  clearCache: () => api.post<{ ok: boolean; message?: string }>("/settings/cache/clear"),
  paths: () =>
    api.get<{ data_dir: string; db: string; cache: string; reports: string }>("/settings/paths"),
};

export const systemApi = {
  health: () => api.get<{ ok: boolean; version: string }>("/health"),
  /** 关闭后端（容器会一起停）。只允许本机调用。 */
  shutdown: () => api.post<{ ok: boolean; message?: string }>("/system/shutdown", {}),
};

// ---------------- 论文 ----------------
export interface Insight {
  problem?: string;
  method?: string;
  datasets: string[];
  findings: string[];
  limitations: string[];
  key_claims: { claim: string; type: string; quote?: string }[];
  concepts: string[];
  quality?: number;
}

export interface Paper {
  id: string;
  project_id: string;
  source: string;
  source_id: string;
  doi?: string | null;
  arxiv_id?: string | null;
  title: string;
  abstract?: string | null;
  tldr?: string | null;
  authors: string[];
  year?: number | null;
  venue?: string | null;
  url?: string | null;
  pdf_url?: string | null;
  citation_count: number;
  published_at?: string | null;
  relevance?: number | null;
  relevance_reason?: string | null;
  status: string;
  /** 为什么是「跳过 / 理解失败」——给用户看的说明 */
  status_reason?: string | null;
  /** 属于哪一次调研（null = 本地导入 / 升级前的早期数据） */
  batch_id?: string | null;
  insight: (Partial<Insight> & { concepts?: string[]; limitations?: string[] }) | null;
}

export interface PaperDetail extends Paper {
  claims: { text: string; claim_type: string; polarity: number; quote?: string }[];
}

export interface Job {
  id: string;
  type: string;
  status: "queued" | "running" | "done" | "failed" | "cancelled";
  progress: number;
  step?: string | null;
  error?: string | null;
  result?: Record<string, unknown> | null;
  created_at: string;
  finished_at?: string | null;
}

export interface VenuePrefs {
  preferred: string[];
  journals_only: boolean;
  min_citations: number;
}

export interface BatchInfo {
  /** null 表示「未分批」这一虚拟分组 */
  id: string | null;
  label: string;
  query: string;
  date_from: string | null;
  date_to: string | null;
  inserted: number;
  cost_cny: number;
  created_at: string | null;
  paper_count: number;
  loose?: boolean;
}

export const papersApi = {
  batches: (projectId: string) => api.get<BatchInfo[]>(`/projects/${projectId}/batches`),
  renameBatch: (projectId: string, batchId: string, label: string) =>
    api.patch<{ id: string; label: string }>(
      `/projects/${projectId}/batches/${batchId}`,
      { label },
    ),
  deleteBatch: (projectId: string, batchId: string) =>
    api.del<{ deleted_papers: number }>(`/projects/${projectId}/batches/${batchId}`),
  venues: (projectId: string) =>
    api.get<{ items: { venue: string; count: number }[]; unlabeled: number }>(
      `/projects/${projectId}/papers/venues`,
    ),
  venuePrefs: (projectId: string) =>
    api.get<VenuePrefs>(`/projects/${projectId}/venue-prefs`),
  saveVenuePrefs: (projectId: string, body: VenuePrefs) =>
    api.put<VenuePrefs>(`/projects/${projectId}/venue-prefs`, body),
  retryUnderstanding: (projectId: string) =>
    api.post<{ job_id: string | null; count: number }>(
      `/projects/${projectId}/papers/retry-understanding`,
      {},
    ),
  list: (
    projectId: string,
    params: {
      q?: string;
      status?: string;
      venue?: string;
      batch?: string;
      sort?: string;
      limit?: number;
      offset?: number;
    } = {},
  ) => {
    const sp = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") sp.set(k, String(v));
    });
    return api.get<{ total: number; items: Paper[] }>(
      `/projects/${projectId}/papers?${sp.toString()}`,
    );
  },
  stats: (projectId: string) =>
    api.get<{ total: number; by_status: Record<string, number>; understood: number; concepts: number }>(
      `/projects/${projectId}/papers/stats`,
    ),
  get: (paperId: string) => api.get<PaperDetail>(`/papers/${paperId}`),
  ingest: (
    projectId: string,
    body: {
      query?: string;
      max_papers?: number;
      understand?: boolean;
      date_from?: string;
      date_to?: string;
      batch_label?: string;
    },
  ) => api.post<{ job_id: string }>(`/projects/${projectId}/ingest`, body),
  understand: (projectId: string, body: { limit?: number; paper_ids?: string[] }) =>
    api.post<{ job_id: string }>(`/projects/${projectId}/understand`, body),
};

export const jobsApi = {
  get: (jobId: string) => api.get<Job>(`/jobs/${jobId}`),
  list: (projectId?: string) =>
    api.get<Job[]>(`/jobs${projectId ? `?project_id=${projectId}` : ""}`),
};

// ---------------- 本地论文 ----------------
export interface LocalDoc {
  id: string;
  rel_path: string;
  file_name: string;
  ext: string;
  size_bytes: number;
  pages: number;
  chars: number;
  title: string | null;
  status: "new" | "extracted" | "failed";
  error: string | null;
  paper_id: string | null;
  created_at: string;
  meta: {
    summary?: string;
    stance?: string;
    openings?: string[];
    views?: number;
    sections?: { section: string; gist: string }[];
  };
}

export interface BrowseEntry {
  name: string;
  path: string;
  rel_path: string;
}

export interface BrowseResult {
  exists: boolean;
  /** 当前目录（宿主路径，和 Finder 里看到的一致） */
  path: string;
  root: string;
  parent: string | null;
  quick: { label: string; path: string }[];
  dirs: (BrowseEntry & { papers: number })[];
  files: (BrowseEntry & { ext: string; size: number })[];
  /** 存在但系统没授权访问的目录（macOS 隐私保护常见于「文稿 / 桌面」） */
  denied: BrowseEntry[];
}

export interface RootInfo {
  root: string;
  exists: boolean;
  parent: string | null;
  quick: { label: string; path: string }[];
  host_home: string;
  mounted: boolean;
}

export interface OutlinePoint {
  point: string;
  sources: string[];
  detail?: string;
  tension?: string;
}

export interface OutlineData {
  id: string;
  title: string;
  docs: string[];
  created_at: string;
  cost_cny: number;
  body: {
    title?: string;
    premise?: string;
    sections?: { heading: string; points: OutlinePoint[] }[];
    evolution?: string;
    consensus?: string[];
    disputes?: string[];
    gaps?: { gap: string; why?: string; who_noticed?: string[] }[];
  };
}

export interface DiscussedIdea {
  id: string;
  title: string;
  one_liner: string;
  gap: string;
  why_novel: string;
  method_sketch: string;
  risks: string;
  feasibility: number;
  impact: number;
  novelty_status?: "unchecked" | "novel" | "partial" | "done";
  extra: {
    next_step?: string;
    collision?: string;
    novelty?: number;
    evidence?: string[];
    check?: NoveltyReport;
  };
}

export interface DiscussionData {
  id: string;
  judgement?: string;
  discussion: string[];
  counterpoints: string[];
  created_at: string;
  ideas: DiscussedIdea[];
}

export const localApi = {
  root: (pid: string) => api.get<RootInfo>(`/projects/${pid}/local/root`),
  setRoot: (pid: string, path: string) =>
    api.put<RootInfo>(`/projects/${pid}/local/root`, { path }),
  /** 文件夹选择器：只列子目录 */
  pick: (pid: string, path = "") =>
    api.get<BrowseResult>(`/projects/${pid}/local/pick?path=${encodeURIComponent(path)}`),
  browse: (pid: string, path = "") =>
    api.get<BrowseResult>(`/projects/${pid}/local/browse?path=${encodeURIComponent(path)}`),
  docs: (pid: string) => api.get<LocalDoc[]>(`/projects/${pid}/local/docs`),
  import: (pid: string, paths: string[]) =>
    api.post<{ job_id: string }>(`/projects/${pid}/local/import`, { paths }),
  outline: (pid: string) => api.get<OutlineData | null>(`/projects/${pid}/local/outline`),
  buildOutline: (pid: string, docIds?: string[]) =>
    api.post<{ job_id: string }>(`/projects/${pid}/local/outline`, { doc_ids: docIds ?? null }),
  discussion: (pid: string) => api.get<DiscussionData | null>(`/projects/${pid}/local/discussion`),
  discuss: (pid: string, outlineId?: string) =>
    api.post<{ job_id: string }>(`/projects/${pid}/local/discuss`, {
      outline_id: outlineId ?? null,
    }),
  removeDoc: (pid: string, docId: string) =>
    api.del<{ ok: boolean }>(`/projects/${pid}/local/docs/${docId}`),
};

// ---------------- 图谱与 Gap ----------------
export type GraphLayer = "cites" | "coupling" | "similar" | "same_concept";

export interface GraphNode {
  id: string;
  title: string;
  year: string;
  source: string;
  citations: number;
  degree: number;
  concepts: string[];
  problem: string;
}

export interface GraphEdge {
  source: string;
  target: string;
  rel: GraphLayer;
  weight: number;
}

export interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
  stats: {
    papers: number;
    edges: number;
    isolated: number;
    by_rel: Partial<Record<GraphLayer, number>>;
    raw_by_rel: Partial<Record<GraphLayer, number>>;
    built_at: string | null;
  };
}

export interface GapItem {
  id: string;
  strategy: "limitation_cluster" | "contradiction" | "combination" | "transfer";
  title: string;
  statement: string;
  detail: string | null;
  support: { paper_id?: string; claim_id?: string; quote?: string; note?: string }[];
  paper_count: number;
  strength: number;
  verdict: "real_gap" | "weak" | "solved" | null;
  created_at: string;
}

export interface NoveltyReport {
  status: "done" | "partial" | "novel" | "unchecked";
  confidence?: number;
  summary?: string;
  closest: {
    paper_id: string;
    overlap: string;
    what_it_does: string;
    delta: string;
  }[];
  suggestions: string[];
  kb_candidates: number;
  live_candidates: number;
  checked_at: string;
}

export const graphApi = {
  get: (pid: string, layers?: GraphLayer[]) =>
    api.get<GraphData>(
      `/projects/${pid}/graph${layers?.length ? `?layers=${layers.join(",")}` : ""}`,
    ),
  build: (pid: string, layers?: GraphLayer[]) =>
    api.post<{ job_id: string }>(`/projects/${pid}/graph/build`, { layers: layers ?? null }),
  neighbors: (pid: string, paperId: string) =>
    api.get<{ id: string; title: string; rel: string; weight: number }[]>(
      `/projects/${pid}/graph/neighbors/${paperId}`,
    ),
  gaps: (pid: string, strategy?: string) =>
    api.get<GapItem[]>(`/projects/${pid}/gaps${strategy ? `?strategy=${strategy}` : ""}`),
  mineGaps: (pid: string) => api.post<{ job_id: string }>(`/projects/${pid}/gaps/mine`, {}),
  deleteGap: (pid: string, gapId: string) =>
    api.del<{ ok: boolean }>(`/projects/${pid}/gaps/${gapId}`),
  novelty: (pid: string, ideaId: string, live = false) =>
    api.post<{ job_id: string }>(`/projects/${pid}/novelty`, { idea_id: ideaId, live }),
};

// ---------------- 共创对话 ----------------
export type ChatState = "diverging" | "narrowing" | "converging" | "done";

export interface RqNode {
  id: string;
  parent_id: string | null;
  node_type: "rq" | "hypothesis" | "narrowing" | "use_case" | "idea";
  title: string;
  body: string | null;
  author: "ai" | "user";
  status: string;
  depth: number;
  thoughts: {
    text?: string;
    reasoning?: string;
    plan?: string;
    criticism?: string;
    speak?: string;
  };
  suggestions: string[];
  papers: string[];
  created_at: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  model: string | null;
  cost_cny: number;
  created_at: string;
  meta: {
    thoughts?: RqNode["thoughts"];
    suggestions?: string[];
    nodes?: string[];
    papers?: string[];
    focus?: string;
    state?: ChatState;
  };
}

export interface ChatView {
  id: string;
  title: string;
  state: ChatState;
  focus: string | null;
  created_at: string;
  messages: ChatMessage[];
  tree: RqNode[];
  cost_cny: number;
}

export interface ChatTurnResult {
  message_id: string;
  reply: string;
  state: ChatState;
  thoughts: RqNode["thoughts"];
  suggestions: string[];
  nodes: string[];
  papers: string[];
  focus: string | null;
  cost_cny: number;
}

export const chatApi = {
  latest: (pid: string) => api.get<ChatView | null>(`/projects/${pid}/chat`),
  start: (pid: string, topic?: string) =>
    api.post<ChatTurnResult & { conversation_id: string }>(`/projects/${pid}/chat/start`, {
      topic: topic ?? null,
    }),
  get: (pid: string, cid: string) => api.get<ChatView>(`/projects/${pid}/chat/${cid}`),
  turn: (pid: string, cid: string, text: string) =>
    api.post<ChatTurnResult>(`/projects/${pid}/chat/${cid}/turn`, { text }),
};

// ---------------- 进展扫描 ----------------
export type ScanWindow = "week" | "month" | "quarter" | "half_year" | "year";

export interface ScanReport {
  headline: string;
  overview?: string;
  window?: [string, string];
  themes?: {
    name: string;
    summary: string;
    trend?: "rising" | "steady" | "new";
    paper_ids: string[];
  }[];
  notable?: { paper_id: string; why: string }[];
  whats_new?: string[];
  open_questions?: string[];
  watch_next?: string[];
  counts?: { found: number; new: number; read: number };
  cost_cny?: number;
}

export interface ScanRun {
  id: string;
  window_start: string;
  window_end: string;
  status: string;
  items_found?: number;
  items_new?: number;
  items_read?: number;
  cost_cny: number;
  created_at: string;
  finished_at?: string | null;
}

export interface ScanView {
  topic: {
    id: string;
    name: string;
    query: string;
    enabled: boolean;
    auto_patrol: boolean;
    last_scan_at: string | null;
  };
  runs: ScanRun[];
  latest_report: ScanReport | null;
  latest_run: ScanRun | null;
}

export const scanApi = {
  get: (pid: string) => api.get<ScanView>(`/projects/${pid}/scan`),
  updateTopic: (pid: string, body: { enabled?: boolean; query?: string }) =>
    api.put<ScanView>(`/projects/${pid}/scan/topic`, body),
  run: (pid: string, body: { window?: ScanWindow; date_from?: string; date_to?: string; max_read?: number }) =>
    api.post<{ job_id: string }>(`/projects/${pid}/scan/run`, body),
};

// ---------------- 创新点 ----------------
export interface IdeaRow {
  id: string;
  title: string;
  one_liner: string | null;
  strategy: string | null;
  elo: number;
  matches: number;
  wins: number;
  losses: number;
  novelty_status: string;
  status: string;
  feasibility: number | null;
  impact: number | null;
  has_proposal: number;
  created_at: string;
}

export interface IdeaDetail extends IdeaRow {
  gap: string | null;
  problem: string | null;
  method_sketch: string | null;
  why_novel: string | null;
  risks: string | null;
  proposal_md: string | null;
  novelty_report: {
    check?: {
      status?: string;
      summary?: string;
      closest?: { paper_id: string; what_it_does: string; delta: string }[];
      suggestions?: string[];
    };
  };
  evidence: { id: string; title: string; tldr: string | null }[];
  comparisons: {
    round: number;
    idea_a: string;
    idea_b: string;
    winner: string;
    rationale: string;
    elo_a_after: number;
    elo_b_after: number;
    created_at: string;
  }[];
}

export const ideasApi = {
  list: (pid: string) => api.get<IdeaRow[]>(`/projects/${pid}/ideas`),
  get: (pid: string, ideaId: string) => api.get<IdeaDetail>(`/projects/${pid}/ideas/${ideaId}`),
  tournament: (pid: string, rounds = 1) =>
    api.post<{ job_id: string }>(`/projects/${pid}/ideas/tournament`, { rounds }),
  proposal: (pid: string, ideaId: string) =>
    api.post<{ job_id: string }>(`/projects/${pid}/ideas/proposal`, { idea_id: ideaId }),
};

// ---------------- 研究脑图 ----------------
export type MapNodeType = "rq" | "hypothesis" | "narrowing" | "use_case" | "idea";

export interface MapNode {
  id: string;
  parent_id: string | null;
  node_type: MapNodeType;
  title: string;
  body: string | null;
  author: "ai" | "user";
  status: string;
  depth: number;
  papers: string[];
  thoughts: { text?: string; why?: string };
  pos: { x: number | null; y: number | null };
  created_at: string;
}

export interface MindMap {
  id: string;
  title: string;
  nodes: MapNode[];
  updated_at: string;
}

export interface ExpandResult {
  created: string[];
  note: string;
  nodes: MapNode[];
  cost_cny: number;
}

export const mindmapApi = {
  get: (pid: string) => api.get<MindMap | null>(`/projects/${pid}/mindmap`),
  create: (pid: string, title?: string) =>
    api.post<MindMap>(`/projects/${pid}/mindmap`, { title: title ?? null }),
  addNode: (pid: string, body: { parent_id: string; title: string; body?: string; node_type?: string }) =>
    api.post<MindMap>(`/projects/${pid}/mindmap/nodes`, body),
  updateNode: (
    pid: string,
    nodeId: string,
    body: { title?: string; body?: string; node_type?: string; status?: string; pos_x?: number; pos_y?: number },
  ) => api.patch<MindMap>(`/projects/${pid}/mindmap/nodes/${nodeId}`, body),
  deleteNode: (pid: string, nodeId: string) =>
    api.del<MindMap>(`/projects/${pid}/mindmap/nodes/${nodeId}`),
  expand: (pid: string, nodeId: string, mode: "explore" | "ideas" = "explore") =>
    api.post<ExpandResult>(`/projects/${pid}/mindmap/expand`, { node_id: nodeId, mode }),
  seed: (pid: string) => api.post<ExpandResult>(`/projects/${pid}/mindmap/seed`, {}),
};
