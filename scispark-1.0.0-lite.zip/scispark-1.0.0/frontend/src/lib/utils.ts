import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCny(v: number | null | undefined, digits = 2) {
  if (v == null) return "¥0.00";
  if (v === 0) return "¥0.00";
  if (v < 0.01) return `¥${v.toFixed(4)}`;
  return `¥${v.toFixed(digits)}`;
}

export function formatRelative(iso: string | null | undefined) {
  if (!iso) return "—";
  const t = new Date(iso.replace(" ", "T")).getTime();
  if (Number.isNaN(t)) return iso;
  const diff = Date.now() - t;
  const m = Math.floor(diff / 60000);
  // 直接读缓存里的界面语言，避免 utils -> i18n -> api 的循环依赖
  const en = localStorage.getItem("scispark.ui_lang") === "en";
  if (m < 1) return en ? "just now" : "刚刚";
  if (m < 60) return en ? `${m} min ago` : `${m} 分钟前`;
  const h = Math.floor(m / 60);
  if (h < 24) return en ? `${h} h ago` : `${h} 小时前`;
  const d = Math.floor(h / 24);
  if (d < 30) return en ? `${d} d ago` : `${d} 天前`;
  return iso.slice(0, 10);
}

export function formatBytes(n: number) {
  if (!n) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}
