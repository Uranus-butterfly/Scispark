import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { settingsApi } from "./api";
import { EN } from "./i18n-dict";

export type Lang = "zh" | "en";

export function currentLang(): Lang {
  return localStorage.getItem("scispark.ui_lang") === "en" ? "en" : "zh";
}

/**
 * 全局取文案：传中文原文，返回当前语言下的文案。
 * 英文缺失时回退中文原文，所以漏翻只会显示中文，不会报错。
 */
export function t(s: string): string {
  return currentLang() === "en" ? EN[s] ?? s : s;
}

/**
 * 切换语言：界面与调研结果统一跟随（不再分开设置），写本地缓存 + 后端设置，
 * 然后刷新页面重渲染全部文案。语言切换是低频操作，刷新最省心也最不容易漏。
 */
export function setLang(l: Lang) {
  localStorage.setItem("scispark.ui_lang", l);
  settingsApi.write({ ui_language: l, result_language: l }).catch(() => {});
  window.location.reload();
}

/**
 * 项目名的显示取值：英文界面优先用英文名，没有就回退原名。
 * 项目名是用户数据，不做机器翻译，只在你填了英文名时才切换。
 */
export function pickName(name: string, nameEn?: string | null): string {
  return currentLang() === "en" && nameEn ? nameEn : name;
}

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (s: string) => string };

const LangCtx = createContext<Ctx>({ lang: "zh", setLang, t });

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang] = useState<Lang>(currentLang);

  // 首次挂载以后端设置为准（多端一致）；失败就沿用本地缓存。
  useEffect(() => {
    let alive = true;
    settingsApi
      .read()
      .then((d) => {
        const v = d.items?.["ui_language"]?.value;
        if (alive && (v === "en" || v === "zh") && v !== currentLang()) {
          localStorage.setItem("scispark.ui_lang", v);
          // 全局 t() 读 localStorage 但不订阅 React state，直接刷新一次才能让所有页面
          // 同步到新语言。只在本地缓存与后端不一致时发生一次（之后两者一致）。
          window.location.reload();
        }
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);

  return <LangCtx.Provider value={{ lang, setLang, t }}>{children}</LangCtx.Provider>;
}

export function useT() {
  return useContext(LangCtx);
}
