import { Navigate, Route, Routes } from "react-router-dom";
import AppShell from "@/components/layout/AppShell";
import ProjectListPage from "@/features/projects/ProjectListPage";
import WorkbenchPage from "@/features/workbench/WorkbenchPage";
import PaperLibraryPage from "@/features/papers/PaperLibraryPage";
import LocalPapersPage from "@/features/local/LocalPapersPage";
import GraphPage from "@/features/graph/GraphPage";
import ChatPage from "@/features/chat/ChatPage";
import ScanPage from "@/features/scan/ScanPage";
import IdeasPage from "@/features/ideas/IdeasPage";
import MindMapPage from "@/features/mindmap/MindMapPage";
import SettingsPage from "@/features/settings/SettingsPage";

export default function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<ProjectListPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/p/:projectId" element={<WorkbenchPage />} />
        <Route path="/p/:projectId/papers" element={<PaperLibraryPage />} />
        <Route path="/p/:projectId/local" element={<LocalPapersPage />} />
        <Route path="/p/:projectId/chat" element={<ChatPage />} />
        <Route path="/p/:projectId/mindmap" element={<MindMapPage />} />
        <Route path="/p/:projectId/graph" element={<GraphPage />} />
        <Route path="/p/:projectId/scan" element={<ScanPage />} />
        <Route path="/p/:projectId/ideas" element={<IdeasPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
