import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { jobsApi, type Job } from "@/lib/api";

/**
 * 轮询任务进度。任务结束（done/failed）后停止，并回调 onDone。
 * 注意：onDone 用 ref 存，避免调用方每次渲染换函数导致重复触发。
 */
export function useJob(jobId: string | null, onDone?: (job: Job) => void) {
  const [job, setJob] = useState<Job | null>(null);
  const [error, setError] = useState<string | null>(null);
  const doneRef = useRef(false);
  const cbRef = useRef(onDone);
  cbRef.current = onDone;

  const { data } = useQuery({
    queryKey: ["job", jobId],
    queryFn: () => jobsApi.get(jobId!),
    enabled: !!jobId,
    refetchInterval: (q) => {
      const d = q.state.data as Job | undefined;
      if (!d) return 1500;
      return d.status === "running" || d.status === "queued" ? 1500 : false;
    },
    retry: false,
  });

  useEffect(() => {
    if (!data) return;
    setJob(data);
    if ((data.status === "done" || data.status === "failed") && !doneRef.current) {
      doneRef.current = true;
      cbRef.current?.(data);
    }
  }, [data]);

  useEffect(() => {
    doneRef.current = false;
    setJob(null);
    setError(null);
  }, [jobId]);

  return { job, error, setError };
}
