import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ChevronRight,
  GitBranch,
  LayoutGrid,
  Lightbulb,
  Loader2,
  Maximize2,
  Minus,
  Network,
  Plus,
  Search,
  Sparkles,
  Trash2,
  Wand2,
} from "lucide-react";
import { mindmapApi, papersApi, type MapNode, type MindMap } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge, Spinner } from "@/components/ui/feedback";
import { PageHeader } from "@/components/layout/PageHeader";
import { cn, formatCny } from "@/lib/utils";
import { PaperInsightDrawer } from "@/features/papers/PaperInsightDrawer";
import { t } from "@/lib/i18n";

// 画布坐标空间跟随容器尺寸（见 ResizeObserver），这样 100% 缩放就是 1:1 像素，
// 不会因为 viewBox 和容器比例不一致而在四周留白、把内容压小
const MAG = 1.45; // 放大镜倍数（配合半径，一次能看清一张卡）
const LENS_R = 132;
const DEFAULT_W = 1200;
const DEFAULT_H = 800;
const NODE_W = 236;
const NODE_H = 78;

const TYPE_META: Record<string, { label: string; ring: string; dot: string; bg: string }> = {
  rq: { label: t("问题"), ring: "border-brand-300", dot: "bg-brand-500", bg: "bg-white" },
  hypothesis: { label: t("假设"), ring: "border-violet-300", dot: "bg-violet-500", bg: "bg-white" },
  narrowing: { label: t("排除"), ring: "border-slate-300", dot: "bg-slate-400", bg: "bg-slate-50" },
  use_case: { label: t("场景"), ring: "border-sky-300", dot: "bg-sky-500", bg: "bg-white" },
  idea: { label: t("做法"), ring: "border-emerald-300", dot: "bg-emerald-500", bg: "bg-white" },
};

/** 自动布局：左→右的整齐树，叶子均分纵向空间 */
function autoLayout(nodes: MapNode[]): Record<string, { x: number; y: number }> {
  const children = new Map<string, MapNode[]>();
  let root: MapNode | null = null;
  for (const n of nodes) {
    if (!n.parent_id) root = n;
    else {
      const arr = children.get(n.parent_id) ?? [];
      arr.push(n);
      children.set(n.parent_id, arr);
    }
  }
  const out: Record<string, { x: number; y: number }> = {};
  let cursor = 0;
  const GAP_Y = 108;
  const GAP_X = 300;

  const walk = (n: MapNode, depth: number): number => {
    const kids = children.get(n.id) ?? [];
    let y: number;
    if (!kids.length) {
      y = cursor * GAP_Y + 80;
      cursor += 1;
    } else {
      const ys = kids.map((k) => walk(k, depth + 1));
      y = (Math.min(...ys) + Math.max(...ys)) / 2;
    }
    out[n.id] = { x: 80 + depth * GAP_X, y };
    return y;
  };
  if (root) walk(root, 0);
  for (const n of nodes) if (!out[n.id]) out[n.id] = { x: 80, y: 80 };
  return out;
}

export default function MindMapPage() {
  const { projectId = "" } = useParams();
  const qc = useQueryClient();

  const { data: map, isLoading } = useQuery({
    queryKey: ["mindmap", projectId],
    queryFn: () => mindmapApi.get(projectId),
    enabled: !!projectId,
  });
  const { data: papers } = useQuery({
    queryKey: ["papers", projectId, "mindmap"],
    queryFn: () => papersApi.list(projectId, { limit: 300 }),
    enabled: !!projectId,
  });

  const [pos, setPos] = useState<Record<string, { x: number; y: number }>>({});
  const [view, setView] = useState({ k: 1, x: 0, y: 0 });
  const [size, setSize] = useState({ w: DEFAULT_W, h: DEFAULT_H });
  const [lens, setLens] = useState<{ x: number; y: number } | null>(null);
  const [lensOn, setLensOn] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [note, setNote] = useState<string>("");
  const [openPaper, setOpenPaper] = useState<string | null>(null);
  const [draft, setDraft] = useState({ title: "", body: "", type: "rq" });

  const wrapRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ id: string; dx: number; dy: number; moved: boolean } | null>(null);
  const panRef = useRef<{ x: number; y: number; vx: number; vy: number; moved: boolean } | null>(null);

  const titles = useMemo(() => {
    const m = new Map<string, string>();
    for (const p of papers?.items ?? []) m.set(p.id, p.title);
    return m;
  }, [papers]);

  // 节点位置：后端有就用后端的，没有就自动布局
  useEffect(() => {
    if (!map?.nodes.length) return;
    const auto = autoLayout(map.nodes);
    const next: Record<string, { x: number; y: number }> = {};
    for (const n of map.nodes) {
      next[n.id] =
        n.pos?.x != null && n.pos?.y != null
          ? { x: n.pos.x, y: n.pos.y }
          : auto[n.id] ?? { x: 80, y: 80 };
    }
    setPos(next);
  }, [map]);

  const nodes = map?.nodes ?? [];
  const node = nodes.find((n) => n.id === selected) ?? null;

  useEffect(() => {
    if (node) setDraft({ title: node.title, body: node.body ?? "", type: node.node_type });
  }, [node?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const refresh = (data?: MindMap | null) => {
    if (data) qc.setQueryData(["mindmap", projectId], data);
    else qc.invalidateQueries({ queryKey: ["mindmap", projectId] });
    qc.invalidateQueries({ queryKey: ["cost"] });
  };

  const create = useMutation({
    mutationFn: () => mindmapApi.create(projectId),
    onSuccess: (d) => refresh(d),
  });
  const addNode = useMutation({
    mutationFn: (parentId: string) =>
      mindmapApi.addNode(projectId, { parent_id: parentId, title: t("新想法（点开改写）") }),
    onSuccess: (d) => refresh(d),
  });
  const saveNode = useMutation({
    mutationFn: () =>
      mindmapApi.updateNode(projectId, node!.id, {
        title: draft.title.trim() || t("未命名"),
        body: draft.body,
        node_type: draft.type,
      }),
    onSuccess: (d) => refresh(d),
  });
  const removeNode = useMutation({
    mutationFn: (id: string) => mindmapApi.deleteNode(projectId, id),
    onSuccess: (d) => {
      refresh(d);
      setSelected(null);
    },
  });
  const expand = useMutation({
    mutationFn: ({ id, mode }: { id: string; mode: "explore" | "ideas" }) =>
      mindmapApi.expand(projectId, id, mode),
    onMutate: ({ mode }) => setBusy(mode),
    onSuccess: (r) => {
      setNote(r.note);
      refresh(null);
    },
    onSettled: () => setBusy(null),
  });
  const seed = useMutation({
    mutationFn: () => mindmapApi.seed(projectId),
    onMutate: () => setBusy("seed"),
    onSuccess: (r) => {
      setNote(r.note);
      refresh(null);
    },
    onSettled: () => setBusy(null),
  });

  // ---------- 坐标换算 ----------
  const toCanvas = useCallback(
    (clientX: number, clientY: number) => {
      const rect = wrapRef.current?.getBoundingClientRect();
      if (!rect) return { x: 0, y: 0 };
      return {
        x: ((clientX - rect.left) / rect.width) * size.w,
        y: ((clientY - rect.top) / rect.height) * size.h,
      };
    },
    [size],
  );

  // 容器尺寸变化时同步画布坐标空间
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) setSize({ w: Math.round(r.width), h: Math.round(r.height) });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // 滚轮缩放（原生监听，避免浏览器整页缩放）
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const p = toCanvas(e.clientX, e.clientY);
      setView((v) => {
        const k = Math.max(0.3, Math.min(3, v.k * (e.deltaY < 0 ? 1.1 : 0.91)));
        const ratio = k / v.k;
        return { k, x: p.x - (p.x - v.x) * ratio, y: p.y - (p.y - v.y) * ratio };
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [toCanvas]);

  const fit = (override?: Record<string, { x: number; y: number }>) => {
    const src = override ?? pos;
    const pts = nodes.map((n) => src[n.id]).filter(Boolean);
    if (!pts.length) return setView({ k: 1, x: 0, y: 0 });
    const minX = Math.min(...pts.map((p) => p.x));
    const maxX = Math.max(...pts.map((p) => p.x)) + NODE_W;
    const minY = Math.min(...pts.map((p) => p.y));
    const maxY = Math.max(...pts.map((p) => p.y)) + NODE_H;
    const k = Math.max(0.3, Math.min(1.5, Math.min((size.w - 120) / (maxX - minX), (size.h - 120) / (maxY - minY))));
    setView({ k, x: size.w / 2 - ((minX + maxX) / 2) * k, y: size.h / 2 - ((minY + maxY) / 2) * k });
  };

  // 初次进入自动适应
  const fittedRef = useRef(false);
  useEffect(() => {
    if (!fittedRef.current && nodes.length && Object.keys(pos).length) {
      fittedRef.current = true;
      fit();
    }
  }, [nodes.length, pos]); // eslint-disable-line react-hooks/exhaustive-deps

  /** 重新排一遍（卡片改大之后，老位置会挤在一起） */
  const relayout = () => {
    const auto = autoLayout(nodes);
    setPos(auto);
    for (const n of nodes) {
      const p = auto[n.id];
      if (p) mindmapApi.updateNode(projectId, n.id, { pos_x: p.x, pos_y: p.y }).catch(() => {});
    }
    // 注意：不能 setTimeout(fit)，闭包里拿到的还是旧 pos
    fit(auto);
  };

  const persistPos = (id: string) => {
    const p = pos[id];
    if (!p) return;
    mindmapApi.updateNode(projectId, id, { pos_x: p.x, pos_y: p.y }).catch(() => {});
  };

  const childrenOf = (id: string) => nodes.filter((n) => n.parent_id === id);

  /**
   * 放大镜里的内容。
   * 这里不能用 foreignObject —— 它在 <g clip-path> 里不渲染（Chrome 实测空白），
   * 所以用纯 SVG 重画一份简化卡片：圆角矩形 + 按字数折行的文字。
   */
  const renderLensContent = () => (
    <>
      {nodes.map((n) => {
        if (!n.parent_id) return null;
        const a = pos[n.parent_id];
        const b = pos[n.id];
        if (!a || !b) return null;
        const x1 = a.x + NODE_W;
        const y1 = a.y + NODE_H / 2;
        const x2 = b.x;
        const y2 = b.y + NODE_H / 2;
        const mid = (x1 + x2) / 2;
        return (
          <path
            key={`le-${n.id}`}
            d={`M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}`}
            fill="none"
            stroke="#cbd5e1"
            strokeWidth={1.4}
          />
        );
      })}
      {nodes.map((n) => {
        const p = pos[n.id];
        if (!p) return null;
        const meta = TYPE_META[n.node_type] ?? TYPE_META.rq;
        const stroke =
          n.node_type === "idea"
            ? "#6ee7b7"
            : n.node_type === "hypothesis"
              ? "#c4b5fd"
              : n.node_type === "narrowing"
                ? "#cbd5e1"
                : n.node_type === "use_case"
                  ? "#7dd3fc"
                  : "#a5b4fc";
        const chars = Math.floor((NODE_W - 28) / 12);
        const lines: string[] = [];
        for (let i = 0; i < n.title.length && lines.length < 3; i += chars) {
          lines.push(n.title.slice(i, i + chars));
        }
        return (
          <g key={`ln-${n.id}`}>
            <rect
              x={p.x}
              y={p.y}
              width={NODE_W}
              height={NODE_H}
              rx={12}
              fill="#ffffff"
              stroke={stroke}
              strokeWidth={2}
            />
            <text x={p.x + 14} y={p.y + 22} style={{ fontSize: 10, fill: "#94a3b8" }}>
              {meta.label}
            </text>
            {lines.map((line, i) => (
              <text
                key={i}
                x={p.x + 14}
                y={p.y + 40 + i * 15}
                style={{ fontSize: 12, fill: "#0f172a", fontWeight: 500 }}
              >
                {line}
              </text>
            ))}
          </g>
        );
      })}
    </>
  );

  const renderContent = (interactive: boolean) => (
    <>

                {/* 连线 */}
                {nodes.map((n) => {
                  if (!n.parent_id) return null;
                  const a = pos[n.parent_id];
                  const b = pos[n.id];
                  if (!a || !b) return null;
                  const x1 = a.x + NODE_W;
                  const y1 = a.y + NODE_H / 2;
                  const x2 = b.x;
                  const y2 = b.y + NODE_H / 2;
                  const mid = (x1 + x2) / 2;
                  const active = selected === n.id || selected === n.parent_id;
                  return (
                    <path
                      key={`e-${n.id}`}
                      d={`M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}`}
                      fill="none"
                      stroke={active ? "#6366f1" : "#cbd5e1"}
                      strokeWidth={active ? 2 : 1.4}
                    />
                  );
                })}

                {/* 节点 */}
                {nodes.map((n) => {
                  const p = pos[n.id];
                  if (!p) return null;
                  const meta = TYPE_META[n.node_type] ?? TYPE_META.rq;
                  const isSel = selected === n.id;
                  return (
                    <foreignObject
                      key={n.id}
                      x={p.x}
                      y={p.y}
                      width={NODE_W}
                      height={NODE_H}
                      style={{ overflow: "visible" }}
                    >
                      <div
                        onPointerDown={
                          interactive
                            ? (e) => {
                                e.stopPropagation();
                                const c = toCanvas(e.clientX, e.clientY);
                                dragRef.current = {
                                  id: n.id,
                                  dx: c.x - p.x,
                                  dy: c.y - p.y,
                                  moved: false,
                                };
                                setSelected(n.id);
                              }
                            : undefined
                        }
                        onClick={interactive ? (e) => e.stopPropagation() : undefined}
                        className={cn(
                          "flex h-full w-full cursor-grab flex-col justify-center rounded-xl border-2 px-2.5 py-1.5 shadow-sm transition-shadow active:cursor-grabbing",
                          meta.bg,
                          isSel ? "border-brand-500 shadow-md ring-2 ring-brand-200" : meta.ring,
                        )}
                      >
                        <div className="flex items-center gap-1">
                          <span className={cn("h-2 w-2 shrink-0 rounded-full", meta.dot)} />
                          <span className="text-[10px] text-ink-400">{meta.label}</span>
                          {n.author === "user" && <span className="text-[9px] text-ink-300">{t("你")}</span>}
                          {n.papers.length > 0 && (
                            <span className="text-[9px] text-ink-300">·{n.papers.length} {t("篇")}</span>
                          )}
                        </div>
                        <div className="mt-1 line-clamp-3 text-[12.5px] font-medium leading-snug text-ink-900">
                          {n.title}
                        </div>
                      </div>
                    </foreignObject>
                  );
                })}

    </>
  );

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner className="h-5 w-5" />
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t("研究脑图")}
        desc={t("画布优先：你自己加节点、拖位置，AI 只在你指的地方展开")}
        actions={
          map ? (
            <>
              <Button size="sm" disabled={!!busy} onClick={() => seed.mutate()} loading={busy === "seed"}>
                <Wand2 size={13} /> {t("AI 给几个方向")}
              </Button>
              <Button
                size="sm"
                variant="primary"
                disabled={!!busy}
                onClick={() => selected && expand.mutate({ id: selected, mode: "ideas" })}
                loading={busy === "ideas"}
                title={selected ? "" : t("先选一个节点")}
              >
                <Lightbulb size={13} /> {t("出创新点")}
              </Button>
            </>
          ) : null
        }
      />

      {!map ? (
        <div className="flex flex-1 items-center justify-center">
          <div className="max-w-md text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-violet-500 text-white shadow-sm">
              <GitBranch size={20} />
            </div>
            <div className="mt-3 text-[15px] font-semibold text-ink-900">{t("从研究方向出发")}</div>
            <div className="mt-1.5 text-[12.5px] leading-relaxed text-ink-500">
              中间是项目的研究主题。你可以自己往外加想法，也可以让 AI 先给几个方向，
              然后指着任意节点让它继续拆或给创新点。
            </div>
            <Button variant="primary" className="mt-4" loading={create.isPending} onClick={() => create.mutate()}>
              <Sparkles size={14} /> {t("开始画")}
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex min-h-0 flex-1">
          {/* 画布 */}
          <div
            ref={wrapRef}
            className="relative min-w-0 flex-1 overflow-hidden bg-canvas"
            style={{ touchAction: "none", overscrollBehavior: "contain" }}
          >
            <svg
              viewBox={`0 0 ${size.w} ${size.h}`}
              className="block h-full w-full"
              style={{ touchAction: "none" }}
              onPointerDown={(e) => {
                if (dragRef.current) return;
                panRef.current = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y, moved: false };
              }}
              onPointerMove={(e) => {
                const d = dragRef.current;
                if (d) {
                  const p = toCanvas(e.clientX, e.clientY);
                  d.moved = true;
                  setPos((cur) => ({ ...cur, [d.id]: { x: p.x - d.dx, y: p.y - d.dy } }));
                  return;
                }
                const pan = panRef.current;
                if (pan) {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const dx = ((e.clientX - pan.x) / rect.width) * size.w;
                  const dy = ((e.clientY - pan.y) / rect.height) * size.h;
                  if (Math.abs(dx) > 3 || Math.abs(dy) > 3) pan.moved = true;
                  if (pan.moved) setView((v) => ({ ...v, x: pan.vx + dx, y: pan.vy + dy }));
                }
                if (lensOn) setLens(toCanvas(e.clientX, e.clientY));
              }}
              onPointerUp={() => {
                const d = dragRef.current;
                if (d?.moved) persistPos(d.id);
                dragRef.current = null;
                panRef.current = null;
              }}
              onPointerLeave={() => {
                dragRef.current = null;
                panRef.current = null;
                setLens(null);
              }}
            >
              <g transform={`translate(${view.x},${view.y}) scale(${view.k})`}>{renderContent(true)}</g>

              {/* 放大镜：同一份内容再放大一遍，镜片里字号跟着放大 */}
              {lens && (
                <g pointerEvents="none">
                  <defs>
                    <clipPath id="mm-lens">
                      <circle cx={lens.x} cy={lens.y} r={LENS_R} />
                    </clipPath>
                  </defs>
                  <circle cx={lens.x} cy={lens.y} r={LENS_R} fill="#ffffff" />
                  <g clipPath="url(#mm-lens)">
                    <g transform={`translate(${lens.x},${lens.y}) scale(${MAG}) translate(${-lens.x},${-lens.y})`}>
                      <g transform={`translate(${view.x},${view.y}) scale(${view.k})`}>{renderLensContent()}</g>
                    </g>
                  </g>
                  <circle cx={lens.x} cy={lens.y} r={LENS_R} fill="none" stroke="#4f46e5" strokeWidth={2} />
                </g>
              )}
            </svg>

            {/* 工具条 */}
            <div className="absolute left-3 top-3 flex items-center gap-1 rounded-lg border border-line bg-surface/95 p-0.5 shadow-sm">
              <button
                onClick={() => selected && addNode.mutate(selected)}
                disabled={!selected}
                className="flex items-center gap-1 rounded px-2 py-1 text-[11px] text-ink-600 hover:bg-canvas disabled:opacity-40"
                title={t("在选中节点下加一个自己的想法")}
              >
                <Plus size={12} /> {t("加节点")}
              </button>
              <span className="mx-0.5 h-4 w-px bg-line" />
              <button
                onClick={() => selected && expand.mutate({ id: selected, mode: "explore" })}
                disabled={!selected || !!busy}
                className="flex items-center gap-1 rounded px-2 py-1 text-[11px] text-ink-600 hover:bg-canvas disabled:opacity-40"
                title={t("让 AI 把这个节点拆成子问题")}
              >
                {busy === "explore" ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
                AI 展开
              </button>
              <span className="mx-0.5 h-4 w-px bg-line" />
              <button
                onClick={() => {
                  setLensOn((v) => !v);
                  if (lensOn) setLens(null);
                }}
                className={cn(
                  "flex items-center gap-1 rounded px-2 py-1 text-[11px] transition-colors",
                  lensOn ? "bg-brand-50 text-brand-700" : "text-ink-600 hover:bg-canvas",
                )}
                title={t("放大镜：鼠标移到画布上，局部放大看清字")}
              >
                <Search size={12} /> {t("放大镜")}
              </button>
              <span className="mx-0.5 h-4 w-px bg-line" />
              <button
                onClick={relayout}
                className="flex items-center gap-1 rounded px-2 py-1 text-[11px] text-ink-600 hover:bg-canvas"
                title={t("重新排一遍（卡片大小改了之后位置会挤）")}
              >
                <LayoutGrid size={12} /> {t("整理布局")}
              </button>
              <button
                onClick={() => fit()}
                className="rounded p-1 text-ink-500 hover:bg-canvas"
                title={t("适应窗口")}
              >
                <Maximize2 size={12} />
              </button>
            </div>

            {/* 缩放 */}
            <div className="absolute bottom-3 left-3 flex items-center gap-1 rounded-lg border border-line bg-surface/95 px-1 py-0.5 shadow-sm">
              <button
                onClick={() =>
                  setView((v) => ({ ...v, k: Math.max(0.3, v.k * 0.85), x: size.w / 2 - (size.w / 2 - v.x) * 0.85, y: size.h / 2 - (size.h / 2 - v.y) * 0.85 }))
                }
                className="rounded p-1 text-ink-500 hover:bg-canvas"
              >
                <Minus size={12} />
              </button>
              <span className="w-9 text-center font-mono text-[10.5px] text-ink-500">
                {Math.round(view.k * 100)}%
              </span>
              <button
                onClick={() =>
                  setView((v) => ({ ...v, k: Math.min(3, v.k * 1.18), x: size.w / 2 - (size.w / 2 - v.x) * 1.18, y: size.h / 2 - (size.h / 2 - v.y) * 1.18 }))
                }
                className="rounded p-1 text-ink-500 hover:bg-canvas"
              >
                <Plus size={12} />
              </button>
            </div>

            {busy && (
              <div className="absolute inset-0 flex items-center justify-center bg-canvas/40">
                <div className="flex items-center gap-2 rounded-lg border border-line bg-surface px-3 py-2 text-[12px] text-ink-600 shadow-sm">
                  <Loader2 size={13} className="animate-spin" /> {t("AI 正在想…")}
                </div>
              </div>
            )}

            {note && (
              <div className="absolute bottom-3 right-3 max-w-[320px] rounded-lg border border-brand-100 bg-brand-50/95 px-2.5 py-1.5 text-[11px] leading-relaxed text-brand-800">
                {note}
              </div>
            )}
          </div>

          {/* 右侧节点面板 */}
          <aside className="flex w-[340px] shrink-0 flex-col border-l border-line bg-surface">
            {!node ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 text-center">
                <Network size={18} className="text-ink-300" />
                <div className="text-[12px] leading-relaxed text-ink-400">
                  {t("点一个节点")}
                  <br />
                  {t("可以改标题、写说明、让 AI 展开")}
                </div>
              </div>
            ) : (
              <>
                <div className="border-b border-line px-3.5 py-2.5">
                  <div className="flex items-center gap-1.5">
                    <Badge tone="neutral">{TYPE_META[node.node_type]?.label ?? t("问题")}</Badge>
                    <span className="text-[10.5px] text-ink-400">
                      {node.author === "user" ? t("你写的") : t("AI 生成")}
                    </span>
                    {node.parent_id && (
                      <button
                        onClick={() => removeNode.mutate(node.id)}
                        className="ml-auto rounded p-1 text-ink-300 hover:bg-red-50 hover:text-red-600"
                        title={t("删除这个节点及其子节点")}
                      >
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </div>

                <div className="min-h-0 flex-1 space-y-2.5 overflow-y-auto px-3.5 py-3">
                  <div>
                    <div className="text-[10.5px] font-medium text-ink-400">{t("标题")}</div>
                    <input
                      value={draft.title}
                      onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
                      className="mt-1 w-full rounded-md border border-line bg-canvas px-2 py-1.5 text-[12.5px] text-ink-900 outline-none focus:border-brand-300"
                    />
                  </div>
                  <div>
                    <div className="text-[10.5px] font-medium text-ink-400">{t("说明")}</div>
                    <textarea
                      value={draft.body}
                      onChange={(e) => setDraft((d) => ({ ...d, body: e.target.value }))}
                      rows={4}
                      placeholder={t("这个节点为什么成立？边界在哪？")}
                      className="mt-1 w-full resize-y rounded-md border border-line bg-canvas px-2 py-1.5 text-[12px] leading-relaxed text-ink-800 outline-none placeholder:text-ink-400 focus:border-brand-300"
                    />
                  </div>
                  <div>
                    <div className="text-[10.5px] font-medium text-ink-400">{t("类型")}</div>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {Object.entries(TYPE_META).map(([k, v]) => (
                        <button
                          key={k}
                          onClick={() => setDraft((d) => ({ ...d, type: k }))}
                          className={cn(
                            "rounded border px-1.5 py-0.5 text-[10.5px]",
                            draft.type === k
                              ? "border-brand-300 bg-brand-50 text-brand-700"
                              : "border-line text-ink-500 hover:bg-canvas",
                          )}
                        >
                          {v.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {(draft.title !== node.title ||
                    draft.body !== (node.body ?? "") ||
                    draft.type !== node.node_type) && (
                    <Button size="sm" variant="primary" className="w-full" loading={saveNode.isPending} onClick={() => saveNode.mutate()}>
                      {t("保存修改")}
                    </Button>
                  )}

                  {!!node.thoughts?.text && (
                    <div className="rounded-lg bg-canvas px-2.5 py-2">
                      <div className="text-[10.5px] font-medium text-ink-400">{t("AI 为什么这么拆")}</div>
                      <div className="text-[11.5px] leading-relaxed text-ink-700">{node.thoughts.text}</div>
                    </div>
                  )}

                  {!!node.papers.length && (
                    <div>
                      <div className="text-[10.5px] font-medium text-ink-400">{t("关联论文")}</div>
                      <div className="mt-1 space-y-0.5">
                        {node.papers.map((pid) => (
                          <button
                            key={pid}
                            onClick={() => setOpenPaper(pid)}
                            className="block w-full truncate rounded px-1 py-0.5 text-left text-[11px] text-brand-700 hover:bg-brand-50"
                          >
                            {titles.get(pid) ?? t("（论文）")}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="space-y-1 border-t border-line pt-2">
                    <button
                      onClick={() => expand.mutate({ id: node.id, mode: "explore" })}
                      disabled={!!busy}
                      className="flex w-full items-center gap-1.5 rounded px-1.5 py-1 text-left text-[11.5px] text-ink-600 hover:bg-canvas disabled:opacity-40"
                    >
                      <Sparkles size={12} className="text-brand-600" /> {t("让 AI 拆成子问题")}
                      <ChevronRight size={11} className="ml-auto text-ink-300" />
                    </button>
                    <button
                      onClick={() => expand.mutate({ id: node.id, mode: "ideas" })}
                      disabled={!!busy}
                      className="flex w-full items-center gap-1.5 rounded px-1.5 py-1 text-left text-[11.5px] text-ink-600 hover:bg-canvas disabled:opacity-40"
                    >
                      <Lightbulb size={12} className="text-emerald-600" /> {t("从这里出创新点")}
                      <ChevronRight size={11} className="ml-auto text-ink-300" />
                    </button>
                    <button
                      onClick={() => addNode.mutate(node.id)}
                      className="flex w-full items-center gap-1.5 rounded px-1.5 py-1 text-left text-[11.5px] text-ink-600 hover:bg-canvas"
                    >
                      <Plus size={12} className="text-ink-400" /> {t("加一个我自己的想法")}
                      <ChevronRight size={11} className="ml-auto text-ink-300" />
                    </button>
                  </div>
                </div>
              </>
            )}
            <div className="border-t border-line px-3 py-1.5 text-[10.5px] text-ink-400">
              {nodes.length} 个节点 · 拖节点调位置，滚轮缩放画布
              {expand.data?.cost_cny ? ` · 上次展开 ${formatCny(expand.data.cost_cny)}` : ""}
            </div>
          </aside>
        </div>
      )}

      <PaperInsightDrawer paperId={openPaper} onClose={() => setOpenPaper(null)} />
    </div>
  );
}
