import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { projectsApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field, Input, Textarea } from "@/components/ui/card";
import { t } from "@/lib/i18n";

export function NewProjectDialog({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated?: (id: string) => void;
}) {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [nameEn, setNameEn] = useState("");
  const [topic, setTopic] = useState("");
  const [description, setDescription] = useState("");

  const create = useMutation({
    mutationFn: () =>
      projectsApi.create({
        name: name.trim(),
        name_en: nameEn.trim() || undefined,
        topic: topic.trim(),
        description: description.trim(),
      }),
    onSuccess: (p) => {
      qc.invalidateQueries({ queryKey: ["projects"] });
      setName("");
      setNameEn("");
      setTopic("");
      setDescription("");
      onClose();
      onCreated?.(p.id);
    },
  });

  const valid = name.trim().length > 0 && topic.trim().length > 0;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={t("新建研究项目")}
      desc={t("一个项目对应一个研究方向。后续的论文库、问题树、创新点都挂在项目下。")}
      footer={
        <>
          <Button onClick={onClose}>{t("取消")}</Button>
          <Button
            variant="primary"
            disabled={!valid}
            loading={create.isPending}
            onClick={() => create.mutate()}
          >
            {t("创建项目")}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field label={t("项目名称")} hint={t("简短好记即可，比如「RAG 评测方法」")}>
          <Input
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("RAG 评测方法")}
            maxLength={120}
          />
        </Field>
        <Field label={t("英文名（可选）")} hint={t("英文界面下显示这个名字；留空则沿用上面的中文名")}>
          <Input
            value={nameEn}
            onChange={(e) => setNameEn(e.target.value)}
            placeholder="RAG Evaluation"
            maxLength={120}
          />
        </Field>
        <Field
          label={t("研究主题")}
          hint={t("用一两句话描述你想研究什么。这句话会作为 AI 检索和理解论文的总纲。")}
        >
          <Textarea
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder={t("如何更可靠地评测检索增强生成系统的忠实度与引用准确性")}
            rows={3}
            maxLength={400}
          />
        </Field>
        <Field label={t("补充说明（可选）")}>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={t("你的背景、已有的想法、明确不想做的方向……")}
            rows={2}
          />
        </Field>
        {create.isError && (
          <div className="rounded-lg border border-red-100 bg-red-50 px-3 py-2 text-[12px] text-red-600">
            {(create.error as Error).message}
          </div>
        )}
      </div>
    </Dialog>
  );
}
