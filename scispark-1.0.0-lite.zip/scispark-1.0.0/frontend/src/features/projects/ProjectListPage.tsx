import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, FileText, FolderKanban, Lightbulb, Plus, Settings2, Trash2 } from "lucide-react";
import { projectsApi, settingsApi, type Project } from "@/lib/api";
import { Badge, EmptyState, Spinner } from "@/components/ui/feedback";
import { Button } from "@/components/ui/button";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { formatRelative } from "@/lib/utils";
import { NewProjectDialog } from "./NewProjectDialog";
import { pickName, t } from "@/lib/i18n";

function ProjectCard({ p, onDelete }: { p: Project; onDelete: (p: Project) => void }) {
  return (
    <div className="group relative flex flex-col rounded-xl border border-line bg-surface p-5 transition-all hover:border-brand-500/40 hover:shadow-[0_4px_16px_rgba(15,23,42,0.06)]">
      <Link to={`/p/${p.id}`} className="absolute inset-0 z-0" aria-label={p.name} />
      <div className="relative z-10 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="truncate text-[15px] font-semibold text-ink-900">{pickName(p.name, p.name_en)}</div>
          <div className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-ink-500">{p.topic}</div>
        </div>
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onDelete(p);
          }}
          className="z-20 rounded-md p-1.5 text-ink-400 opacity-0 transition-all hover:bg-red-50 hover:text-red-600 group-hover:opacity-100"
          title={t("删除项目")}
        >
          <Trash2 size={14} />
        </button>
      </div>

      <div className="relative z-10 mt-4 flex flex-wrap items-center gap-1.5">
        <Badge tone="brand">
          <FileText size={10} /> {p.paper_count} {t("篇论文")}
        </Badge>
        <Badge tone="violet">
          <Lightbulb size={10} /> {p.idea_count} {t("个创新点")}
        </Badge>
        <Badge>{p.rq_count} {t("个问题节点")}</Badge>
      </div>

      <div className="relative z-10 mt-4 flex items-center justify-between border-t border-line pt-3 text-[11.5px] text-ink-400">
        <span>{t("更新于")} {formatRelative(p.updated_at)}</span>
        <span className="inline-flex items-center gap-1 text-brand-600 opacity-0 transition-opacity group-hover:opacity-100">
          {t("进入")} <ArrowRight size={11} />
        </span>
      </div>
    </div>
  );
}

export default function ProjectListPage() {
  const nav = useNavigate();
  const [open, setOpen] = useState(false);

  const { data: projects, isLoading } = useQuery({
    queryKey: ["projects"],
    queryFn: projectsApi.list,
  });
  const { data: settings } = useQuery({ queryKey: ["settings"], queryFn: settingsApi.read });

  const noKey = settings ? !settings.items.deepseek_api_key?.configured : false;

  const handleDelete = async (p: Project) => {
    if (!confirm(`确定删除项目「${p.name}」？\n该项目下的所有论文、问题树、创新点都会一并删除，不可恢复。`))
      return;
    await projectsApi.remove(p.id);
    window.location.reload();
  };

  return (
    <div className="min-h-full">
      <PageHeader
        title={t("项目")}
        desc={t("每个项目是一个研究方向，独立拥有论文库、问题树与创新点。")}
        actions={
          <Button variant="primary" onClick={() => setOpen(true)}>
            <Plus size={15} /> {t("新建项目")}
          </Button>
        }
      />
      <PageBody>
        {noKey && (
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
            <div className="text-[13px] text-amber-800">
              {t("还没配置 DeepSeek API Key，AI 相关功能无法使用。")}
            </div>
            <Link to="/settings">
              <Button size="sm" variant="secondary">
                <Settings2 size={13} /> {t("去配置")}
              </Button>
            </Link>
          </div>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Spinner className="h-5 w-5" />
          </div>
        ) : !projects || projects.length === 0 ? (
          <EmptyState
            icon={<FolderKanban size={22} />}
            title={t("还没有项目")}
            desc={t("新建一个项目，填写你关心的研究主题，AI 会据此检索论文、梳理脉络、陪你收敛创新方向。")}
            action={
              <Button variant="primary" onClick={() => setOpen(true)}>
                <Plus size={15} /> {t("新建第一个项目")}
              </Button>
            }
          />
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {projects.map((p) => (
              <ProjectCard key={p.id} p={p} onDelete={handleDelete} />
            ))}
          </div>
        )}
      </PageBody>

      <NewProjectDialog
        open={open}
        onClose={() => setOpen(false)}
        onCreated={(id) => nav(`/p/${id}`)}
      />
    </div>
  );
}
