import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BookMarked, CalendarDays, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Field, Input, Textarea } from "@/components/ui/card";
import { papersApi, type VenuePrefs } from "@/lib/api";
import { cn } from "@/lib/utils";
import { t } from "@/lib/i18n";

export interface IngestForm {
  query: string;
  max_papers: number;
  understand: boolean;
  date_from?: string;
  date_to?: string;
  /** 这批调研叫什么（留空就用检索主题） */
  batch_label?: string;
}

const MONTHS = Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, "0"));
const DAYS = Array.from({ length: 31 }, (_, i) => String(i + 1).padStart(2, "0"));

/**
 * 年 / 月 / 日 分开填。
 *
 * 原来用原生 <input type="date">，年份那段在很多浏览器里只能改两位
 * （想从 2026 改到 2020 会变成 0020），体验很差。拆成三个控件后
 * 年份是普通文本框、月日是下拉，不会再有这个问题。
 */
function DateParts({
  label,
  value,
  onChange,
  defaultMonth,
  defaultDay,
}: {
  label: string;
  value: string;
  onChange: (iso: string) => void;
  defaultMonth: string;
  defaultDay: string;
}) {
  const [year, setYear] = useState("");
  const [month, setMonth] = useState(defaultMonth);
  const [day, setDay] = useState(defaultDay);

  // 外部值变化时同步（比如点了「近三年」）
  useEffect(() => {
    if (!value) {
      setYear("");
      return;
    }
    const [y, m, d] = value.split("-");
    setYear(y ?? "");
    if (m) setMonth(m);
    if (d) setDay(d);
  }, [value]);

  const emit = (y: string, m: string, d: string) => {
    onChange(y.length === 4 ? `${y}-${m}-${d}` : "");
  };

  return (
    <div>
      <div className="mb-1 text-[12px] font-medium text-ink-700">{label}</div>
      <div className="flex items-center gap-1">
        <input
          value={year}
          onChange={(e) => {
            const v = e.target.value.replace(/\D/g, "").slice(0, 4);
            setYear(v);
            emit(v, month, day);
          }}
          inputMode="numeric"
          placeholder={t("不限")}
          className="h-9 w-[76px] rounded-lg border border-line bg-white px-2 text-center font-mono text-[13px] text-ink-900 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15"
        />
        <span className="text-[11px] text-ink-400">{t("年")}</span>
        <select
          value={month}
          onChange={(e) => {
            setMonth(e.target.value);
            emit(year, e.target.value, day);
          }}
          className="h-9 rounded-lg border border-line bg-white px-1.5 text-[12.5px] text-ink-800 outline-none focus:border-brand-500"
        >
          {MONTHS.map((m) => (
            <option key={m} value={m}>
              {m} {t("月")}
            </option>
          ))}
        </select>
        <select
          value={day}
          onChange={(e) => {
            setDay(e.target.value);
            emit(year, month, e.target.value);
          }}
          className="h-9 rounded-lg border border-line bg-white px-1.5 text-[12.5px] text-ink-800 outline-none focus:border-brand-500"
        >
          {DAYS.map((d) => (
            <option key={d} value={d}>
              {d} {t("日")}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}

export function IngestDialog({
  open,
  onClose,
  projectId,
  defaultQuery,
  onSubmit,
  submitting,
}: {
  open: boolean;
  onClose: () => void;
  projectId: string;
  defaultQuery: string;
  onSubmit: (form: IngestForm) => void;
  submitting?: boolean;
}) {
  const [query, setQuery] = useState(defaultQuery);
  const [maxPapers, setMaxPapers] = useState(40);
  const [understand, setUnderstand] = useState(true);
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [venueText, setVenueText] = useState("");
  const [journalsOnly, setJournalsOnly] = useState(false);
  const [minCitations, setMinCitations] = useState(0);
  const [batchLabel, setBatchLabel] = useState("");

  const { data: prefs } = useQuery({
    queryKey: ["venuePrefs", projectId],
    queryFn: () => papersApi.venuePrefs(projectId),
    enabled: open && !!projectId,
  });

  useEffect(() => {
    if (open) {
      setQuery(defaultQuery);
      setBatchLabel("");
    }
  }, [open, defaultQuery]);

  // 打开时把上次存的期刊偏好填回来
  useEffect(() => {
    if (!prefs) return;
    setVenueText((prefs.preferred || []).join("、"));
    setJournalsOnly(!!prefs.journals_only);
    setMinCitations(prefs.min_citations || 0);
  }, [prefs]);

  const setQuickRange = (years: number | null) => {
    if (years === null) {
      setDateFrom("");
      setDateTo("");
      return;
    }
    const today = new Date();
    const from = new Date(today);
    from.setFullYear(from.getFullYear() - years);
    const iso = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    setDateFrom(iso(from));
    setDateTo(iso(today));
  };

  const submit = async () => {
    const venuePrefs: VenuePrefs = {
      preferred: venueText
        .split(/[,，、;；\n]/)
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 20),
      journals_only: journalsOnly,
      min_citations: minCitations,
    };
    // 先存偏好，再开始调研（失败不阻塞）
    try {
      await papersApi.saveVenuePrefs(projectId, venuePrefs);
    } catch {
      /* 忽略：偏好没存上也能跑 */
    }
    onSubmit({
      query: query.trim(),
      max_papers: maxPapers,
      understand,
      date_from: dateFrom || undefined,
      date_to: dateTo || undefined,
      batch_label: batchLabel.trim() || undefined,
    });
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={t("开始调研")}
      desc={t("AI 会扩展检索式、从 arXiv 与 OpenAlex 抓取论文、去重排序，再逐篇抽取结构化理解。")}
      width="max-w-xl"
      footer={
        <>
          <Button onClick={onClose}>{t("取消")}</Button>
          <Button variant="primary" loading={submitting} disabled={!query.trim()} onClick={submit}>
            <Sparkles size={14} /> {t("开始")}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field label={t("检索主题")} hint={t("默认用项目主题。也可以临时换一个更具体的方向。")}>
          <Textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            rows={3}
            placeholder={t("例如：检索增强生成的引用准确性评测")}
          />
        </Field>

        <Field
          label={t("这一批叫什么（可选）")}
          hint={t("每次调研都会在论文库里开一个新分组。留空就用上面的检索主题当名字，之后也能改。")}
        >
          <Input
            value={batchLabel}
            onChange={(e) => setBatchLabel(e.target.value)}
            maxLength={40}
            placeholder={query.trim().slice(0, 40) || t("例如：引用归因")}
          />
        </Field>

        <Field
          label={`保留篇数：${maxPapers} 篇`}
          hint={t("精排后会保留最相关的这么多篇，并逐篇做结构化理解。篇数越多越慢越贵。")}
        >
          <input
            type="range"
            min={10}
            max={150}
            step={10}
            value={maxPapers}
            onChange={(e) => setMaxPapers(Number(e.target.value))}
            className="w-full accent-indigo-600"
          />
          <div className="mt-1 flex justify-between text-[11px] text-ink-400">
            <span>{t("10（约 ¥0.05）")}</span>
            <span>{t("150（约 ¥0.5）")}</span>
          </div>
        </Field>

        {/* 时间范围 */}
        <div className="rounded-lg border border-line px-3 py-2.5">
          <div className="mb-2 flex items-center gap-1.5 text-[12px] font-medium text-ink-700">
            <CalendarDays size={12} className="text-ink-400" /> {t("发表时间范围")}
            <span className="ml-auto flex items-center gap-1">
              {[
                { label: t("近 1 年"), y: 1 },
                { label: t("近 3 年"), y: 3 },
                { label: t("近 5 年"), y: 5 },
              ].map((q) => (
                <button
                  key={q.y}
                  onClick={() => setQuickRange(q.y)}
                  className="rounded border border-line px-1.5 py-0.5 text-[10.5px] text-ink-500 hover:bg-canvas"
                >
                  {q.label}
                </button>
              ))}
              <button
                onClick={() => setQuickRange(null)}
                className="rounded border border-line px-1.5 py-0.5 text-[10.5px] text-ink-500 hover:bg-canvas"
              >
                {t("不限")}
              </button>
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <DateParts
              label={t("起始")}
              value={dateFrom}
              onChange={setDateFrom}
              defaultMonth="01"
              defaultDay="01"
            />
            <DateParts
              label={t("截止")}
              value={dateTo}
              onChange={setDateTo}
              defaultMonth="12"
              defaultDay="31"
            />
          </div>
          <div className="mt-1.5 text-[11px] text-ink-400">
            {t("年份留空表示不限。只填年份时会自动补成 01-01 / 12-31。")}
          </div>
        </div>

        {/* 期刊偏好 */}
        <div className="rounded-lg border border-line px-3 py-2.5">
          <div className="mb-2 flex items-center gap-1.5 text-[12px] font-medium text-ink-700">
            <BookMarked size={12} className="text-ink-400" /> {t("发表渠道偏好")}
            <span className="ml-auto text-[10.5px] font-normal text-ink-400">
              {t("会记在本项目上，下次自动带上")}
            </span>
          </div>

          <Field
            label={t("优先期刊 / 会议")}
            hint={t("逗号或顿号分隔。命中这些名字的论文在排序时加权（不是硬性过滤）。")}
          >
            <Input
              value={venueText}
              onChange={(e) => setVenueText(e.target.value)}
              placeholder={t("例如：Nature、Science、ACL、NeurIPS、TPAMI")}
            />
          </Field>

          <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-2">
            <label className="flex cursor-pointer items-center gap-1.5 text-[12px] text-ink-700">
              <input
                type="checkbox"
                checked={journalsOnly}
                onChange={(e) => setJournalsOnly(e.target.checked)}
                className="accent-indigo-600"
              />
              {t("只要正式发表（排除 arXiv 预印本）")}
            </label>
            <label className="flex items-center gap-1.5 text-[12px] text-ink-700">
              {t("被引 ≥")}
              <input
                type="number"
                min={0}
                value={minCitations}
                onChange={(e) => setMinCitations(Math.max(0, Number(e.target.value) || 0))}
                className="h-7 w-16 rounded border border-line bg-white px-1.5 text-center font-mono text-[12px]"
              />
              {t("次的优先")}
            </label>
          </div>

          <div className="mt-2 text-[11px] leading-relaxed text-ink-400">
            {t("被引和期刊名都只是排序权重，不会把不相关的新论文直接砍掉——刚发表的好论文被引一定是 0。")}
          </div>
        </div>

        <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-line bg-canvas/60 px-3 py-2.5">
          <input
            type="checkbox"
            checked={understand}
            onChange={(e) => setUnderstand(e.target.checked)}
            className="mt-0.5 accent-indigo-600"
          />
          <span className="text-[12.5px] leading-relaxed text-ink-700">
            {t("同时做结构化理解")}
            <span className="block text-[11.5px] text-ink-400">
              {t("逐篇抽取问题 / 方法 / 数据集 / 发现 / 局限 / 关键断言。不做的话只有标题和摘要。")}
            </span>
          </span>
        </label>
      </div>
    </Dialog>
  );
}
