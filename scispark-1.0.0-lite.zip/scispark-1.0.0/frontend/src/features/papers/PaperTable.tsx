import type { Paper } from "@/lib/api";
import { Badge } from "@/components/ui/feedback";
import { cn } from "@/lib/utils";
import { t } from "@/lib/i18n";

function RelevanceBar({ v }: { v: number | null | undefined }) {
  if (v == null) return <span className="text-[11.5px] text-ink-400">—</span>;
  const pct = Math.round(v * 100);
  const color = v >= 0.8 ? "bg-emerald-500" : v >= 0.6 ? "bg-brand-500" : v >= 0.4 ? "bg-amber-500" : "bg-ink-400";
  return (
    <div className="flex items-center gap-1.5">
      <div className="h-1 w-10 overflow-hidden rounded-full bg-line">
        <div className={cn("h-full rounded-full", color)} style={{ width: `${pct}%` }} />
      </div>
      <span className="font-mono text-[11px] text-ink-500">{(v * 10).toFixed(1)}</span>
    </div>
  );
}

export function PaperTable({
  papers,
  selectedId,
  onSelect,
  onFilterVenue,
}: {
  papers: Paper[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onFilterVenue?: (venue: string) => void;
}) {
  return (
    <div className="overflow-hidden rounded-xl border border-line bg-surface">
      <table className="w-full table-fixed">
        <thead>
          <tr className="border-b border-line bg-canvas/60 text-[11.5px] text-ink-500">
            <th className="w-10 px-3 py-2" />
            <th className="px-2 py-2 text-left font-medium">{t("标题")}</th>
            <th className="w-40 px-2 py-2 text-left font-medium">{t("期刊 / 会议")}</th>
            <th className="w-14 px-2 py-2 text-left font-medium">{t("年份")}</th>
            <th className="w-16 px-2 py-2 text-right font-medium">{t("引用")}</th>
            <th className="w-24 px-2 py-2 text-left font-medium">{t("相关度")}</th>
            <th className="w-20 px-3 py-2 text-left font-medium">{t("状态")}</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {papers.map((p, i) => {
            const active = p.id === selectedId;
            return (
              <tr
                key={p.id}
                onClick={() => onSelect(p.id)}
                className={cn(
                  "cursor-pointer transition-colors",
                  active ? "bg-brand-50/70" : "hover:bg-canvas/70",
                )}
              >
                <td className="px-3 py-2.5 text-right font-mono text-[11px] text-ink-400">
                  {i + 1}
                </td>
                <td className="px-2 py-2.5">
                  <div className="line-clamp-2 text-[13px] font-medium leading-snug text-ink-900">
                    {p.title}
                  </div>
                  <div className="mt-0.5 truncate text-[11px] text-ink-400">
                    {p.authors.slice(0, 3).join("、")}
                    {p.authors.length > 3 ? t(" 等") : ""}
                  </div>
                  {p.relevance_reason && (
                    <div className="mt-0.5 line-clamp-1 text-[11px] text-brand-600/80">
                      {p.relevance_reason}
                    </div>
                  )}
                </td>
                <td className="px-2 py-2.5">
                  {p.venue ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onFilterVenue?.(p.venue!);
                      }}
                      title={`只看 ${p.venue}`}
                      className="line-clamp-2 w-full text-left text-[11.5px] leading-snug text-ink-600 hover:text-brand-700 hover:underline"
                    >
                      {p.venue}
                    </button>
                  ) : (
                    <span className="text-[11.5px] text-ink-300">—</span>
                  )}
                </td>
                <td className="px-2 py-2.5 font-mono text-[11.5px] text-ink-500">
                  {p.year ?? "—"}
                </td>
                <td className="px-2 py-2.5 text-right font-mono text-[11.5px] text-ink-500">
                  {p.citation_count}
                </td>
                <td className="px-2 py-2.5">
                  <RelevanceBar v={p.relevance} />
                </td>
                <td className="px-3 py-2.5">
                  {p.status === "understood" ? (
                    <Badge tone="violet">{t("已理解")}</Badge>
                  ) : p.status === "skipped" || p.status === "failed" ? (
                    <span title={p.status_reason || ""}>
                      <Badge tone="amber">{p.status === "skipped" ? t("已跳过") : t("理解失败")}</Badge>
                    </span>
                  ) : (
                    <Badge>{t("待理解")}</Badge>
                  )}
                  {(p.status === "skipped" || p.status === "failed") &&
                    p.status_reason && (
                      <div className="mt-0.5 line-clamp-2 max-w-[150px] text-[10px] leading-snug text-ink-400">
                        {p.status_reason}
                      </div>
                    )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
