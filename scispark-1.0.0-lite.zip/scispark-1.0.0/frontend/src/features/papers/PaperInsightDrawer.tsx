import { useQuery } from "@tanstack/react-query";
import {
  BookOpen,
  ExternalLink,
  FileText,
  FlaskConical,
  Lightbulb,
  Quote,
  TriangleAlert,
} from "lucide-react";
import { papersApi } from "@/lib/api";
import { Badge, Divider, Spinner } from "@/components/ui/feedback";
import { cn } from "@/lib/utils";
import { t } from "@/lib/i18n";

function Section({
  icon,
  title,
  children,
  tone = "neutral",
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
  tone?: "neutral" | "amber" | "green";
}) {
  return (
    <div className="space-y-1.5">
      <div
        className={cn(
          "flex items-center gap-1.5 text-[12px] font-medium",
          tone === "amber" ? "text-amber-700" : tone === "green" ? "text-emerald-700" : "text-ink-700",
        )}
      >
        {icon}
        {title}
      </div>
      <div className="text-[13px] leading-relaxed text-ink-700">{children}</div>
    </div>
  );
}

function Bullets({ items, empty }: { items: string[]; empty: string }) {
  if (!items.length) return <span className="text-[12.5px] text-ink-400">{empty}</span>;
  return (
    <ul className="space-y-1">
      {items.map((x, i) => (
        <li key={i} className="flex gap-1.5">
          <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-ink-400" />
          <span>{x}</span>
        </li>
      ))}
    </ul>
  );
}

const CLAIM_LABEL: Record<string, { label: string; tone: "green" | "amber" | "violet" | "brand" }> = {
  finding: { label: t("主张"), tone: "green" },
  result: { label: t("证据"), tone: "brand" },
  limitation: { label: t("局限"), tone: "amber" },
  assumption: { label: t("假设"), tone: "violet" },
};

function ClaimsList({
  claims,
}: {
  claims: { text: string; claim_type: string; quote?: string }[];
}) {
  if (!claims.length) return null;
  return (
    <div className="space-y-2">
      <div className="text-[12px] font-medium text-ink-700">
        抽取到的观点（{claims.length}）
      </div>
      {claims.map((c, i) => {
        const meta = CLAIM_LABEL[c.claim_type] || CLAIM_LABEL.finding;
        return (
          <div key={i} className="rounded-lg border border-line bg-canvas/50 px-3 py-2">
            <div className="flex items-start gap-1.5">
              <Badge tone={meta.tone}>{meta.label}</Badge>
              <span className="text-[12.5px] leading-relaxed text-ink-700">{c.text}</span>
            </div>
            {c.quote && (
              <div className="mt-1.5 border-l-2 border-line pl-2 font-mono text-[11px] leading-relaxed text-ink-400">
                {c.quote}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export function PaperInsightDrawer({
  paperId,
  onClose,
}: {
  paperId: string | null;
  onClose: () => void;
}) {
  const { data, isLoading } = useQuery({
    queryKey: ["paper", paperId],
    queryFn: () => papersApi.get(paperId!),
    enabled: !!paperId,
  });

  if (!paperId) return null;

  const ins = data?.insight;

  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="flex-1 bg-ink-900/15" onClick={onClose} aria-hidden />
      <aside className="flex h-full w-full max-w-[560px] flex-col border-l border-line bg-surface shadow-2xl">
        <div className="flex items-center justify-between border-b border-line px-5 py-3">
          <div className="text-[13px] font-semibold text-ink-900">{t("论文详情")}</div>
          <button
            onClick={onClose}
            className="rounded-md px-2 py-1 text-[12px] text-ink-500 hover:bg-canvas hover:text-ink-900"
          >
            {t("关闭")}
          </button>
        </div>

        {isLoading || !data ? (
          <div className="flex flex-1 items-center justify-center">
            <Spinner />
          </div>
        ) : (
          <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
            <div>
              <h2 className="text-[15px] font-semibold leading-snug text-ink-900">{data.title}</h2>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <Badge tone="brand">{data.source}</Badge>
                {data.year && <Badge>{data.year}</Badge>}
                <Badge>引用 {data.citation_count}</Badge>
                {data.relevance != null && (
                  <Badge tone="green">相关度 {(data.relevance * 10).toFixed(1)}/10</Badge>
                )}
                {data.status === "understood" ? (
                  <Badge tone="violet">{t("已理解")}</Badge>
                ) : data.status === "skipped" || data.status === "failed" ? (
                  <Badge tone="amber">{data.status === "skipped" ? t("已跳过") : t("理解失败")}</Badge>
                ) : (
                  <Badge>{t("待理解")}</Badge>
                )}
              </div>
              <div className="mt-2 text-[11.5px] leading-relaxed text-ink-400">
                {data.authors.slice(0, 6).join("、")}
                {data.authors.length > 6 ? t(" 等") : ""}
                {data.venue ? ` · ${data.venue}` : ""}
              </div>
              {data.relevance_reason && (
                <div className="mt-2 rounded-lg border border-brand-100 bg-brand-50 px-2.5 py-1.5 text-[12px] leading-relaxed text-brand-700">
                  {data.relevance_reason}
                </div>
              )}
              {(data.status === "skipped" || data.status === "failed") && data.status_reason && (
                <div className="mt-2 rounded-lg border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[12px] leading-relaxed text-amber-800">
                  没有做结构化理解：{data.status_reason}
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2">
              {data.url && (
                <a href={data.url} target="_blank" rel="noreferrer">
                  <span className="inline-flex items-center gap-1 rounded-md border border-line px-2 py-1 text-[11.5px] text-ink-600 hover:bg-canvas">
                    <ExternalLink size={11} /> {t("原文")}
                  </span>
                </a>
              )}
              {data.pdf_url && (
                <a href={data.pdf_url} target="_blank" rel="noreferrer">
                  <span className="inline-flex items-center gap-1 rounded-md border border-line px-2 py-1 text-[11.5px] text-ink-600 hover:bg-canvas">
                    <FileText size={11} /> PDF
                  </span>
                </a>
              )}
              {data.doi && (
                <a
                  href={`https://doi.org/${data.doi}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 rounded-md border border-line px-2 py-1 text-[11.5px] text-ink-600 hover:bg-canvas"
                >
                  DOI
                </a>
              )}
            </div>

            <Divider />

            {!ins ? (
              <div className="space-y-3">
                <div className="rounded-lg border border-dashed border-line px-4 py-4 text-center text-[12.5px] text-ink-400">
                  {data.claims?.length
                    ? t("这篇是本地导入的论文，没有结构化卡片，但已抽取观点（见下）")
                    : t("这篇还没做结构化理解，摘要原文见下方")}
                </div>
                <ClaimsList claims={data.claims || []} />
              </div>
            ) : (
              <div className="space-y-4">
                {ins.problem && (
                  <Section icon={<BookOpen size={12} />} title={t("要解决的问题")}>
                    {ins.problem}
                  </Section>
                )}
                {ins.method && (
                  <Section icon={<FlaskConical size={12} />} title={t("核心方法")}>
                    {ins.method}
                  </Section>
                )}
                {!!ins.datasets?.length && (
                  <Section icon={<FileText size={12} />} title={t("数据集 / 基准")}>
                    <div className="flex flex-wrap gap-1.5">
                      {ins.datasets.map((d) => (
                        <Badge key={d} tone="neutral">
                          {d}
                        </Badge>
                      ))}
                    </div>
                  </Section>
                )}
                <Section icon={<Lightbulb size={12} />} title={t("主要发现")} tone="green">
                  <Bullets items={ins.findings || []} empty={t("摘要中未明确给出结论")} />
                </Section>
                <Section icon={<TriangleAlert size={12} />} title={t("局限")} tone="amber">
                  <Bullets items={ins.limitations || []} empty={t("摘要中未提及明显局限")} />
                </Section>
                {!!ins.concepts?.length && (
                  <Section icon={<Quote size={12} />} title={t("概念标签")}>
                    <div className="flex flex-wrap gap-1.5">
                      {ins.concepts.map((c) => (
                        <Badge key={c} tone="brand">
                          {c}
                        </Badge>
                      ))}
                    </div>
                  </Section>
                )}
                {!!ins.key_claims?.length && (
                  <div className="space-y-2">
                    <div className="text-[12px] font-medium text-ink-700">
                      {t("关键断言（附原文，可核对）")}
                    </div>
                    {ins.key_claims.map((c, i) => (
                      <div
                        key={i}
                        className="rounded-lg border border-line bg-canvas/50 px-3 py-2"
                      >
                        <div className="flex items-start gap-1.5">
                          <Badge
                            tone={
                              c.type === "limitation"
                                ? "amber"
                                : c.type === "assumption"
                                  ? "violet"
                                  : "green"
                            }
                          >
                            {c.type}
                          </Badge>
                          <span className="text-[12.5px] leading-relaxed text-ink-700">
                            {c.claim}
                          </span>
                        </div>
                        {c.quote && (
                          <div className="mt-1.5 border-l-2 border-line pl-2 font-mono text-[11px] leading-relaxed text-ink-400">
                            {c.quote}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            <Divider />
            <div>
              <div className="mb-1.5 text-[12px] font-medium text-ink-700">{t("摘要原文")}</div>
              <p className="whitespace-pre-wrap text-[12.5px] leading-relaxed text-ink-500">
                {data.abstract || t("（无摘要）")}
              </p>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}
