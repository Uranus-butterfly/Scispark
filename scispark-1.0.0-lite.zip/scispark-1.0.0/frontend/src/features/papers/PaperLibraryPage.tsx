import { useEffect, useMemo, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BookOpenCheck,
  CheckCircle2,
  Layers,
  Library,
  Loader2,
  RotateCcw,
  Rows3,
  Search,
  Sparkles,
  Trash2,
  TriangleAlert,
} from "lucide-react";
import { papersApi, projectsApi, settingsApi, type BatchInfo } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/card";
import { Badge, EmptyState, Spinner } from "@/components/ui/feedback";
import { Progress } from "@/components/ui/progress";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { useJob } from "@/hooks/useJob";
import { cn, formatCny } from "@/lib/utils";
import { IngestDialog, type IngestForm } from "./IngestDialog";
import { PaperTable } from "./PaperTable";
import { PaperInsightDrawer } from "./PaperInsightDrawer";
import { t } from "@/lib/i18n";

export default function PaperLibraryPage() {
  const { projectId = "" } = useParams();
  const qc = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [jobId, setJobId] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(searchParams.get("paper"));
  const [q, setQ] = useState("");
  const [sort, setSort] = useState("relevance");
  const [venue, setVenue] = useState("");
  const [batch, setBatch] = useState("");
  const [grouped, setGrouped] = useState(true);
  const [lastResult, setLastResult] = useState<Record<string, unknown> | null>(null);

  // 选中状态同步到 URL，方便刷新/分享
  useEffect(() => {
    const next = new URLSearchParams(searchParams);
    if (selected) next.set("paper", selected);
    else next.delete("paper");
    if (next.toString() !== searchParams.toString()) {
      setSearchParams(next, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  const { data: project } = useQuery({
    queryKey: ["project", projectId],
    queryFn: () => projectsApi.get(projectId),
    enabled: !!projectId,
  });
  const { data: stats } = useQuery({
    queryKey: ["paperStats", projectId],
    queryFn: () => papersApi.stats(projectId),
    enabled: !!projectId,
  });
  const { data: list, isLoading } = useQuery({
    queryKey: ["papers", projectId, q, sort, venue, batch],
    queryFn: () =>
      papersApi.list(projectId, {
        q: q || undefined,
        sort,
        venue: venue || undefined,
        batch: batch || undefined,
        limit: 200,
      }),
    enabled: !!projectId,
  });
  const { data: batches } = useQuery({
    queryKey: ["batches", projectId],
    queryFn: () => papersApi.batches(projectId),
    enabled: !!projectId,
  });
  const { data: venues } = useQuery({
    queryKey: ["paperVenues", projectId],
    queryFn: () => papersApi.venues(projectId),
    enabled: !!projectId,
  });
  const { data: cost } = useQuery({ queryKey: ["cost"], queryFn: settingsApi.cost });

  const skippedCount =
    (stats?.by_status?.skipped ?? 0) + (stats?.by_status?.failed ?? 0);

  const { job } = useJob(jobId, (j) => {
    setLastResult(j.result ?? null);
    qc.invalidateQueries({ queryKey: ["papers", projectId] });
    qc.invalidateQueries({ queryKey: ["paperStats", projectId] });
    qc.invalidateQueries({ queryKey: ["batches", projectId] });
    qc.invalidateQueries({ queryKey: ["cost"] });
    qc.invalidateQueries({ queryKey: ["project", projectId] });
  });

  const retryUnderstand = useMutation({
    mutationFn: () => papersApi.retryUnderstanding(projectId),
    onSuccess: (r) => {
      if (r.job_id) setJobId(r.job_id);
      else qc.invalidateQueries({ queryKey: ["papers", projectId] });
    },
  });

  const renameBatch = useMutation({
    mutationFn: ({ id, label }: { id: string; label: string }) =>
      papersApi.renameBatch(projectId, id, label),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["batches", projectId] }),
  });

  const deleteBatch = useMutation({
    mutationFn: (id: string) => papersApi.deleteBatch(projectId, id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["batches", projectId] });
      qc.invalidateQueries({ queryKey: ["papers", projectId] });
      qc.invalidateQueries({ queryKey: ["paperStats", projectId] });
      qc.invalidateQueries({ queryKey: ["paperVenues", projectId] });
    },
  });

  const ingest = useMutation({
    mutationFn: (form: IngestForm) => papersApi.ingest(projectId, form),
    onSuccess: (r) => {
      setDialogOpen(false);
      setLastResult(null);
      setJobId(r.job_id);
    },
  });

  const understand = useMutation({
    mutationFn: () => papersApi.understand(projectId, { limit: 60 }),
    onSuccess: (r) => {
      setLastResult(null);
      setJobId(r.job_id);
    },
  });

  const running = job?.status === "running" || job?.status === "queued";
  const papers = list?.items ?? [];

  // 批次改名：点标题进入编辑，回车/失焦保存。
  // 值从输入框本身读，不依赖 state——回车紧接着输入时 React 可能还没重渲染，
  // 闭包里的 editing.value 会是旧值（踩过：改名静默失效）。
  const [editing, setEditing] = useState<{ id: string; value: string } | null>(null);
  const saveBatchName = (raw?: string) => {
    if (!editing) return;
    const cur = editing;
    const v = (raw ?? cur.value).trim();
    setEditing(null);
    if (!v || v === (batches ?? []).find((b) => b.id === cur.id)?.label) return;
    renameBatch.mutate({ id: cur.id, label: v });
  };
  const removeBatch = (id: string, label: string, count: number) => {
    if (
      !window.confirm(
        `${t("删除")}「${label}」${t("这一批？")}\n\n${t("这一批的")} ${count} ${t("篇论文会一起删掉，不能撤销。")}\n${t("（图谱、脑图里引用到它们的节点会变成无证据）")}`,
      )
    )
      return;
    deleteBatch.mutate(id);
  };

  /**
   * 按调研批次分块。
   *
   * 同一项目连着调研两个方向时，论文会混在一起分不清来源，所以默认分组显示：
   * 每批一个标题（批次名 + 检索主题 + 时间 + 篇数），下面是这一批的论文。
   * 顺序跟批次列表一致（新的在前）。
   */
  const groups = useMemo(() => {
    if (!grouped || batch || q) return null;
    const info = new Map<string, BatchInfo>();
    for (const b of batches ?? []) info.set(b.id ?? "__none__", b);

    const bucket = new Map<string, typeof papers>();
    for (const p of papers) {
      const k = p.batch_id ?? "__none__";
      const arr = bucket.get(k);
      if (arr) arr.push(p);
      else bucket.set(k, [p]);
    }

    const order = (batches ?? []).map((b) => b.id ?? "__none__");
    const keys = [...bucket.keys()].sort((a, b) => {
      const ia = order.indexOf(a);
      const ib = order.indexOf(b);
      return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib);
    });

    return keys.map((k) => ({
      key: k,
      info: info.get(k),
      items: bucket.get(k) ?? [],
    }));
  }, [grouped, batch, q, batches, papers]);

  const res = lastResult as
    | {
        sources?: { arxiv?: { records?: number }; openalex?: { records?: number } };
        deduped?: number;
        selected?: number;
        inserted?: number;
        understood?: { understood?: number; cost_cny?: number };
      }
    | null;

  return (
    <div className="min-h-full">
      <PageHeader
        title={t("论文库")}
        desc={project ? project.topic : t("检索、去重、排序后的论文，每篇带一张中文结构化卡片")}
        actions={
          <>
            <Button
              disabled={running}
              onClick={() => setDialogOpen(true)}
              variant="primary"
            >
              <Sparkles size={14} /> {t("开始调研")}
            </Button>
            <Button
              disabled={running || !stats?.by_status?.ranked}
              loading={understand.isPending}
              title={t("对已入库但未做结构化理解的论文补跑")}
              onClick={() => understand.mutate()}
            >
              <BookOpenCheck size={14} /> {t("理解未处理")}
            </Button>
            {skippedCount > 0 && (
              <Button
                disabled={running}
                loading={retryUnderstand.isPending}
                title={t("把「已跳过 / 理解失败」的论文重置后重跑一次理解")}
                onClick={() => retryUnderstand.mutate()}
              >
                <RotateCcw size={14} /> {t("重试")} {skippedCount} {t("篇")}
              </Button>
            )}
          </>
        }
      />

      <PageBody className="space-y-4">
        {/* 统计 */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { label: t("论文总数"), value: stats?.total ?? 0 },
            { label: t("已理解"), value: stats?.understood ?? 0 },
            {
              label: t("待理解"),
              value: (stats?.by_status?.ranked ?? 0) + (stats?.by_status?.new ?? 0),
            },
            {
              label: t("跳过 / 失败"),
              value: (stats?.by_status?.skipped ?? 0) + (stats?.by_status?.failed ?? 0),
            },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-line bg-surface px-4 py-3">
              <div className="text-[11.5px] text-ink-400">{s.label}</div>
              <div className="mt-0.5 font-mono text-[20px] font-semibold leading-none text-ink-900">
                {s.value}
              </div>
            </div>
          ))}
        </div>

        {/* 任务进度 */}
        {(running || job?.status === "failed" || res) && (
          <div
            className={
              job?.status === "failed"
                ? "rounded-xl border border-red-100 bg-red-50 px-4 py-3"
                : "rounded-xl border border-line bg-surface px-4 py-3"
            }
          >
            {running && (
              <>
                <div className="flex items-center justify-between text-[12.5px]">
                  <span className="flex items-center gap-1.5 text-ink-700">
                    <Loader2 size={13} className="animate-spin" />
                    {job?.step || t("处理中…")}
                  </span>
                  <span className="font-mono text-ink-500">
                    {Math.round((job?.progress ?? 0) * 100)}%
                  </span>
                </div>
                <Progress className="mt-2" value={job?.progress ?? 0} />
              </>
            )}
            {job?.status === "failed" && (
              <div className="flex items-start gap-2 text-[12.5px] text-red-700">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <div className="font-medium">{t("调研失败")}</div>
                  <div className="mt-0.5 whitespace-pre-wrap break-words text-[11.5px] text-red-600/90">
                    {(job.error || "").split("\n")[0]}
                  </div>
                </div>
              </div>
            )}
            {job?.status === "done" && res && (
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[12px] text-ink-600">
                <span className="flex items-center gap-1 font-medium text-emerald-700">
                  <CheckCircle2 size={13} /> {t("调研完成")}
                </span>
                <span>
                  arXiv {res.sources?.arxiv?.records ?? 0} · OpenAlex{" "}
                  {res.sources?.openalex?.records ?? 0}
                </span>
                <span>去重后 {res.deduped ?? 0}</span>
                <span>精排选 {res.selected ?? 0}</span>
                <span className="text-ink-900">新增 {res.inserted ?? 0} {t("篇")}</span>
                {res.understood?.understood != null && (
                  <span>理解 {res.understood.understood} {t("篇")}</span>
                )}
                <Badge tone="brand">
                  本次花费 {formatCny(res.understood?.cost_cny ?? 0)}
                </Badge>
                <span className="ml-auto text-[11px] text-ink-400">
                  今日累计 {formatCny(cost?.budget.today_cny)}
                </span>
              </div>
            )}
          </div>
        )}

        {/* 搜索与排序 */}
        {!!papers.length || q ? (
          <>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-[240px] flex-1">
                <Search
                  size={14}
                  className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-ink-400"
                />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder={t("在已入库论文中检索（英文关键词效果更好）")}
                  className="pl-8"
                />
              </div>
              <select
                value={batch}
                onChange={(e) => setBatch(e.target.value)}
                className="h-9 max-w-[210px] rounded-lg border border-line bg-white px-2.5 text-[12.5px] text-ink-700 focus:border-brand-500 focus:outline-none"
                title={t("按调研批次筛选")}
              >
                <option value="">{t("全部调研批次")}</option>
                {(batches ?? []).map((b) => (
                  <option key={b.id ?? "__none__"} value={b.id ?? "__none__"}>
                    {(b.label.length > 20 ? `${b.label.slice(0, 19)}…` : b.label)}（
                    {b.paper_count}）
                  </option>
                ))}
              </select>
              <select
                value={venue}
                onChange={(e) => setVenue(e.target.value)}
                className="h-9 max-w-[190px] rounded-lg border border-line bg-white px-2.5 text-[12.5px] text-ink-700 focus:border-brand-500 focus:outline-none"
                title={t("按期刊 / 会议筛选")}
              >
                <option value="">{t("全部期刊 / 会议")}</option>
                {(venues?.items ?? []).map((v) => (
                  <option key={v.venue} value={v.venue}>
                    {v.venue.length > 26 ? `${v.venue.slice(0, 25)}…` : v.venue}（{v.count}）
                  </option>
                ))}
                {!!venues?.unlabeled && <option value="__none__">未标注（{venues.unlabeled}）</option>}
              </select>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="h-9 rounded-lg border border-line bg-white px-2.5 text-[12.5px] text-ink-700 focus:border-brand-500 focus:outline-none"
              >
                <option value="relevance">{t("按相关度")}</option>
                <option value="date">{t("按发表时间")}</option>
                <option value="citations">{t("按引用数")}</option>
                <option value="title">{t("按标题")}</option>
              </select>
              <span className="text-[11.5px] text-ink-400">共 {list?.total ?? 0} {t("篇")}</span>
              {!batch && !q && (
                <button
                  onClick={() => setGrouped((v) => !v)}
                  className={cn(
                    "flex items-center gap-1 rounded-lg border px-2 py-1.5 text-[11.5px] transition-colors",
                    grouped
                      ? "border-brand-200 bg-brand-50 text-brand-700"
                      : "border-line text-ink-500 hover:bg-canvas",
                  )}
                  title={t("按调研批次分块显示 / 平铺")}
                >
                  {grouped ? <Layers size={12} /> : <Rows3 size={12} />}
                  {grouped ? t("已按批次分块") : t("按批次分块")}
                </button>
              )}
            </div>

            {isLoading ? (
              <div className="flex justify-center py-16">
                <Spinner className="h-5 w-5" />
              </div>
            ) : groups ? (
              // 分块视图：每批一个标题条，下面是这一批的论文
              <div className="space-y-5">
                {groups.map((g) => (
                  <div key={g.key}>
                    <div className="mb-1.5 flex flex-wrap items-center gap-2 px-0.5">
                      <Layers size={13} className="shrink-0 text-brand-500" />
                      {editing !== null && editing.id === g.info?.id ? (
                        <input
                          autoFocus
                          value={editing.value}
                          maxLength={40}
                          onChange={(e) =>
                            setEditing({ id: g.info!.id!, value: e.target.value })
                          }
                          onBlur={(e) => saveBatchName(e.currentTarget.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") (e.currentTarget as HTMLInputElement).blur();
                            if (e.key === "Escape") setEditing(null);
                          }}
                          className="w-48 rounded border border-brand-300 px-1.5 py-0.5 text-[12.5px] font-medium text-ink-900 outline-none"
                        />
                      ) : (
                        <button
                          onClick={() =>
                            g.info?.id && setEditing({ id: g.info.id, value: g.info.label })
                          }
                          disabled={!g.info?.id}
                          title={g.info?.id ? t("点一下改名字") : t("未分批的论文（本地导入 / 早期数据），不能改名")}
                          className="rounded px-0.5 text-[12.5px] font-medium text-ink-900 enabled:hover:bg-canvas enabled:hover:text-brand-700 disabled:cursor-default"
                        >
                          {g.info?.label ? t(g.info.label) : t("未分批")}
                        </button>
                      )}
                      <Badge tone={g.info?.loose ? "neutral" : "brand"}>
                        {g.items.length} {t("篇")}
                      </Badge>
                      {g.info?.query && (
                        <span className="min-w-0 flex-1 truncate text-[11px] text-ink-400">
                          {t("主题：")}{g.info.query}
                        </span>
                      )}
                      {g.info?.created_at && (
                        <span className="ml-auto shrink-0 text-[11px] text-ink-400">
                          {g.info.created_at.slice(0, 10)}
                        </span>
                      )}
                      {g.info?.id && (
                        <>
                          <button
                            onClick={() => setBatch(g.info!.id!)}
                            className="shrink-0 rounded border border-line px-1.5 py-0.5 text-[10.5px] text-ink-500 hover:bg-canvas"
                            title={t("只看这一批")}
                          >
                            {t("只看这批")}
                          </button>
                          <button
                            onClick={() =>
                              removeBatch(g.info!.id!, g.info!.label, g.items.length)
                            }
                            className="shrink-0 rounded border border-line p-0.5 text-ink-400 hover:border-red-200 hover:bg-red-50 hover:text-red-600"
                            title={t("删掉这一批（连同它的论文）")}
                          >
                            <Trash2 size={11} />
                          </button>
                        </>
                      )}
                    </div>
                    <PaperTable
                      papers={g.items}
                      selectedId={selected}
                      onSelect={setSelected}
                      onFilterVenue={(v) => setVenue(v)}
                    />
                  </div>
                ))}
              </div>
            ) : (
              <PaperTable
                papers={papers}
                selectedId={selected}
                onSelect={setSelected}
                onFilterVenue={(v) => setVenue(v)}
              />
            )}
          </>
        ) : (
          <EmptyState
            icon={<Library size={22} />}
            title={t("论文库还是空的")}
            desc={t("点右上角「开始调研」，AI 会从 arXiv 和 OpenAlex 检索、去重、排序，并逐篇抽取结构化理解。一次 40 篇大约花 ¥0.15。")}
            action={
              <Button variant="primary" onClick={() => setDialogOpen(true)}>
                <Sparkles size={14} /> {t("开始调研")}
              </Button>
            }
          />
        )}
      </PageBody>

      <IngestDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        projectId={projectId}
        defaultQuery={project?.topic ?? ""}
        submitting={ingest.isPending}
        onSubmit={(form) => ingest.mutate(form)}
      />
      <PaperInsightDrawer paperId={selected} onClose={() => setSelected(null)} />
    </div>
  );
}
