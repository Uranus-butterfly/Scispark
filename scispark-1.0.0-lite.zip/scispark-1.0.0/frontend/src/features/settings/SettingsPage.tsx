import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle2,
  Database,
  KeyRound,
  Plug,
  RefreshCw,
  Trash2,
  TriangleAlert,
  Wallet,
  Zap,
} from "lucide-react";
import { settingsApi } from "@/lib/api";
import { t } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, Field, Input } from "@/components/ui/card";
import { Badge, Divider, Spinner } from "@/components/ui/feedback";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { formatBytes, formatCny } from "@/lib/utils";

function SectionTitle({ icon, title, desc }: { icon: React.ReactNode; title: string; desc?: string }) {
  return (
    <div className="flex items-start gap-2.5">
      <div className="mt-0.5 flex h-7 w-7 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
        {icon}
      </div>
      <div>
        <div className="text-[14px] font-semibold text-ink-900">{title}</div>
        {desc && <div className="mt-0.5 text-[12.5px] leading-relaxed text-ink-500">{desc}</div>}
      </div>
    </div>
  );
}

export default function SettingsPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["settings"], queryFn: settingsApi.read });
  const { data: paths } = useQuery({ queryKey: ["paths"], queryFn: settingsApi.paths });

  const [form, setForm] = useState<Record<string, string>>({});
  const [baseline, setBaseline] = useState<Record<string, string>>({});
  const [testResult, setTestResult] = useState<{ ok: boolean; message?: string } | null>(null);

  useEffect(() => {
    if (!data) return;
    const init: Record<string, string> = {};
    for (const [k, v] of Object.entries(data.items)) {
      init[k] = v.secret ? "" : v.value;
    }
    setForm(init);
    setBaseline(init);
  }, [data]);

  // 收集要提交的值：空的 secret 字段表示「不修改」
  const collectValues = () => {
    const values: Record<string, string> = {};
    for (const [k, v] of Object.entries(form)) {
      const isSecret = data?.items[k]?.secret;
      if (isSecret && v.trim() === "") continue;
      values[k] = v;
    }
    return values;
  };

  const dirty = Object.keys({ ...form, ...baseline }).some(
    (k) => (form[k] ?? "") !== (baseline[k] ?? ""),
  );

  const save = useMutation({
    mutationFn: () => settingsApi.write(collectValues()),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["settings"] });
      qc.invalidateQueries({ queryKey: ["cost"] });
    },
  });

  // 测试连接 = 先保存（保证「填了就生效」），再用表单值兜底测试
  const test = useMutation({
    mutationFn: async () => {
      const values = collectValues();
      try {
        await settingsApi.write(values);
      } catch {
        /* 保存失败也继续测，后端会用临时覆盖 */
      }
      return settingsApi.testLlm(values);
    },
    onSuccess: (r) => {
      setTestResult(r);
      qc.invalidateQueries({ queryKey: ["settings"] });
      qc.invalidateQueries({ queryKey: ["cost"] });
    },
    onError: (e) => setTestResult({ ok: false, message: (e as Error).message }),
  });

  const clearCache = useMutation({
    mutationFn: settingsApi.clearCache,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["settings"] }),
  });

  const priceRows = useMemo(() => {
    if (!data) return [];
    return Object.entries(data.pricing.table).map(([model, p]) => ({
      model,
      hit: p.cache_hit,
      input: p.input,
      output: p.output,
    }));
  }, [data]);

  if (isLoading || !data) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner className="h-5 w-5" />
      </div>
    );
  }

  const keyConfigured = data.items.deepseek_api_key?.configured;

  return (
    <div className="min-h-full">
      <PageHeader
        title={t("设置")}
        desc={t("API 配置、模型选择与成本控制。改动立即生效，无需重启容器。")}
        actions={
          <>
            {dirty && <Badge tone="amber">{t("有未保存的修改")}</Badge>}
            <Button variant="primary" loading={save.isPending} onClick={() => save.mutate()}>
              {t("保存设置")}
            </Button>
          </>
        }
      />
      <PageBody className="max-w-4xl space-y-5">
        {save.isSuccess && (
          <div className="flex items-center gap-2 rounded-lg border border-emerald-100 bg-emerald-50 px-3 py-2 text-[13px] text-emerald-700">
            <CheckCircle2 size={14} /> {t("已保存")}
          </div>
        )}
        {save.isError && (
          <div className="rounded-lg border border-red-100 bg-red-50 px-3 py-2 text-[13px] text-red-600">
            {(save.error as Error).message}
          </div>
        )}

        {/* ---------- API ---------- */}
        <Card>
          <CardHeader
            title={<SectionTitle icon={<KeyRound size={14} />} title="DeepSeek API" desc={t("Key 保存在本地数据库，不会外传。")} />}
            right={
              keyConfigured ? (
                <Badge tone="green">
                  <CheckCircle2 size={10} /> {t("已配置")}
                </Badge>
              ) : (
                <Badge tone="amber">
                  <TriangleAlert size={10} /> {t("未配置")}
                </Badge>
              )
            }
          />
          <Divider />
          <div className="space-y-4 px-5 py-4">
            <Field
              label="API Key"
              hint={
                data.items.deepseek_api_key?.configured
                  ? `${t("当前：")}${data.items.deepseek_api_key.value}${t("（留空表示不修改）")}`
                  : t("在 platform.deepseek.com 创建，形如 sk-xxxx。填完直接点「测试连接」即可，会自动保存。")
              }
            >
              <Input
                type="password"
                autoComplete="off"
                value={form.deepseek_api_key ?? ""}
                onChange={(e) => setForm({ ...form, deepseek_api_key: e.target.value })}
                placeholder={keyConfigured ? t("••••••••（留空不修改）") : "sk-..."}
              />
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Base URL" hint={t("一般无需修改")}>
                <Input
                  value={form.deepseek_base_url ?? ""}
                  onChange={(e) => setForm({ ...form, deepseek_base_url: e.target.value })}
                  placeholder="https://api.deepseek.com"
                />
              </Field>
              <Field label={t("LLM 模式")} hint={t("mock 用于零成本联调界面")}>
                <select
                  value={form.llm_mode || "live"}
                  onChange={(e) => setForm({ ...form, llm_mode: e.target.value })}
                  className="h-9 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink-900 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/15"
                >
                  <option value="live">{t("live · 真实调用")}</option>
                  <option value="mock">{t("mock · 不调用（零成本）")}</option>
                </select>
              </Field>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Button loading={test.isPending} onClick={() => test.mutate()}>
                  <Plug size={13} /> {t("测试连接")}
                </Button>
                <span className="text-[11.5px] text-ink-400">
                  {t("会先把当前填写的内容保存，再发起一次最小请求")}
                </span>
              </div>
              {testResult && (
                <div
                  className={
                    testResult.ok
                      ? "flex items-start gap-1.5 rounded-lg border border-emerald-100 bg-emerald-50 px-3 py-2 text-[12.5px] leading-relaxed text-emerald-700"
                      : "flex items-start gap-1.5 rounded-lg border border-red-100 bg-red-50 px-3 py-2 text-[12.5px] leading-relaxed text-red-600"
                  }
                >
                  {testResult.ok ? (
                    <CheckCircle2 size={13} className="mt-0.5 shrink-0" />
                  ) : (
                    <TriangleAlert size={13} className="mt-0.5 shrink-0" />
                  )}
                  <span>{testResult.message}</span>
                </div>
              )}
            </div>
          </div>
        </Card>

        {/* ---------- 模型 ---------- */}
        <Card>
          <CardHeader
            title={<SectionTitle icon={<Zap size={14} />} title={t("模型分级")} desc={t("便宜的模型干重活，贵的模型只做裁判。")} />}
          />
          <Divider />
          <div className="grid gap-4 px-5 py-4 sm:grid-cols-2">
            <Field label={t("快速模型")} hint={t("抽取 / 精排 / 翻译 / 大部分对话")}>
              <Input
                value={form.model_flash ?? ""}
                onChange={(e) => setForm({ ...form, model_flash: e.target.value })}
                placeholder="deepseek-flash"
              />
            </Field>
            <Field label={t("强模型")} hint={t("Elo 锦标赛裁判、可选的深度分析")}>
              <Input
                value={form.model_pro ?? ""}
                onChange={(e) => setForm({ ...form, model_pro: e.target.value })}
                placeholder="deepseek-v4-pro"
              />
            </Field>
          </div>
        </Card>

        {/* ---------- 成本 ---------- */}
        <Card>
          <CardHeader
            title={<SectionTitle icon={<Wallet size={14} />} title={t("成本控制")} desc={t("超出日预算会直接熔断，防止误操作烧钱。")} />}
            right={
              <Badge tone={data.pricing.peak ? "amber" : "green"}>
                {data.pricing.peak ? t("当前高峰价") : t("当前空闲价")}
              </Badge>
            }
          />
          <Divider />
          <div className="space-y-4 px-5 py-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={t("每日预算（元）")} hint={t("0 表示不限制（不推荐）")}>
                <Input
                  type="number"
                  min={0}
                  step={1}
                  value={form.daily_budget_cny ?? ""}
                  onChange={(e) => setForm({ ...form, daily_budget_cny: e.target.value })}
                />
              </Field>
              <div className="grid grid-cols-3 gap-2 self-end">
                <div className="rounded-lg border border-line bg-canvas px-2.5 py-2">
                  <div className="text-[10.5px] text-ink-400">{t("今日")}</div>
                  <div className="font-mono text-[13px] text-ink-900">
                    {formatCny(data.budget.today_cny)}
                  </div>
                </div>
                <div className="rounded-lg border border-line bg-canvas px-2.5 py-2">
                  <div className="text-[10.5px] text-ink-400">{t("本月")}</div>
                  <div className="font-mono text-[13px] text-ink-900">
                    {formatCny(data.budget.month_cny)}
                  </div>
                </div>
                <div className="rounded-lg border border-line bg-canvas px-2.5 py-2">
                  <div className="text-[10.5px] text-ink-400">{t("剩余")}</div>
                  <div className="font-mono text-[13px] text-ink-900">
                    {formatCny(data.budget.remaining_cny)}
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="mb-1.5 text-[12px] font-medium text-ink-700">
                {t("DeepSeek 单价（美元 / 百万 tokens，空闲价）")}
              </div>
              <div className="overflow-hidden rounded-lg border border-line">
                <table className="w-full text-[12px]">
                  <thead className="bg-canvas text-ink-500">
                    <tr>
                      <th className="px-3 py-1.5 text-left font-medium">{t("模型")}</th>
                      <th className="px-3 py-1.5 text-right font-medium">{t("缓存命中")}</th>
                      <th className="px-3 py-1.5 text-right font-medium">{t("输入")}</th>
                      <th className="px-3 py-1.5 text-right font-medium">{t("输出")}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {priceRows.map((r) => (
                      <tr key={r.model}>
                        <td className="px-3 py-1.5 font-mono text-[11.5px] text-ink-700">{r.model}</td>
                        <td className="px-3 py-1.5 text-right font-mono text-emerald-600">
                          ${r.hit}
                        </td>
                        <td className="px-3 py-1.5 text-right font-mono text-ink-700">${r.input}</td>
                        <td className="px-3 py-1.5 text-right font-mono text-ink-700">${r.output}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-1.5 text-[11px] text-ink-400">
                {t("高峰时段价格翻倍（北京时间工作日 9-12、14-18 点）。晚上和周末跑批更划算。")}
              </div>
            </div>
          </div>
        </Card>

        {/* ---------- 数据源 ---------- */}
        <Card>
          <CardHeader
            title={<SectionTitle icon={<Database size={14} />} title={t("数据源")} desc={t("OpenAlex 免费 key 可把每日配额从 $0.10（共享）提升到 $1（独占）。")} />}
          />
          <Divider />
          <div className="grid gap-4 px-5 py-4 sm:grid-cols-2">
            <Field label={t("OpenAlex API Key（可选）")}>
              <Input
                type="password"
                autoComplete="off"
                value={form.openalex_api_key ?? ""}
                onChange={(e) => setForm({ ...form, openalex_api_key: e.target.value })}
                placeholder={
                  data.items.openalex_api_key?.configured
                    ? data.items.openalex_api_key.value
                    : t("留空则使用共享配额")
                }
              />
            </Field>
            <Field label={t("OpenAlex 联系邮箱（可选）")}>
              <Input
                value={form.openalex_mailto ?? ""}
                onChange={(e) => setForm({ ...form, openalex_mailto: e.target.value })}
                placeholder="you@example.com"
              />
            </Field>
          </div>
        </Card>

        {/* ---------- 缓存 ---------- */}
        <Card>
          <CardHeader
            title={
              <SectionTitle
                icon={<RefreshCw size={14} />}
                title={t("响应缓存")}
                desc={t("相同 prompt 不再重复请求。开发期能省掉 60% 以上的花费。")}
              />
            }
            right={
              <div className="flex items-center gap-2">
                <Badge tone="brand">
                  {data.cache.entries} {t("条 ·")} {formatBytes(data.cache.bytes)}
                </Badge>
                <Button size="sm" loading={clearCache.isPending} onClick={() => clearCache.mutate()}>
                  <Trash2 size={12} /> {t("清空")}
                </Button>
              </div>
            }
          />
        </Card>

        {/* ---------- 路径 ---------- */}
        <Card>
          <CardHeader title={<SectionTitle icon={<Database size={14} />} title={t("数据位置")} desc={t("都在宿主机的项目目录下，可直接备份。")} />} />
          <Divider />
          <div className="space-y-1.5 px-5 py-4 font-mono text-[11.5px] text-ink-500">
            {paths &&
              Object.entries(paths).map(([k, v]) => (
                <div key={k} className="flex gap-3">
                  <span className="w-20 shrink-0 text-ink-400">{k}</span>
                  <span className="break-all text-ink-700">{v}</span>
                </div>
              ))}
          </div>
        </Card>
      </PageBody>
    </div>
  );
}
