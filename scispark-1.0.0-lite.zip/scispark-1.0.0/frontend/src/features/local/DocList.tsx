import { FileText, Trash2, TriangleAlert } from "lucide-react";
import type { LocalDoc } from "@/lib/api";
import { Badge } from "@/components/ui/feedback";
import { formatBytes } from "@/lib/utils";
import { t } from "@/lib/i18n";

export function DocList({
  docs,
  onRemove,
  onOpenPaper,
}: {
  docs: LocalDoc[];
  onRemove: (id: string) => void;
  onOpenPaper: (paperId: string) => void;
}) {
  if (!docs.length) {
    return (
      <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-12 text-center">
        <div className="text-[13px] font-medium text-ink-700">{t("还没有导入本地论文")}</div>
        <div className="mt-1 text-[12.5px] text-ink-400">
          {t("在上面的目录浏览器里勾选文件，点「导入并抽取观点」")}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {docs.map((d) => {
        const failed = d.status === "failed";
        return (
          <div
            key={d.id}
            className="rounded-xl border border-line bg-surface px-4 py-3 transition-colors hover:border-brand-500/30"
          >
            <div className="flex items-start gap-2">
              <FileText size={14} className="mt-0.5 shrink-0 text-ink-400" />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[13.5px] font-medium text-ink-900">
                    {d.title || d.file_name}
                  </span>
                  <Badge tone={failed ? "red" : "green"}>
                    {failed ? t("失败") : <>{d.meta.views ?? 0} {t("条观点")}</>}
                  </Badge>
                  {d.pages > 0 && <Badge>{d.pages} {t("页")}</Badge>}
                  <Badge>{formatBytes(d.size_bytes)}</Badge>
                </div>

                <div className="mt-0.5 truncate font-mono text-[11px] text-ink-400">
                  {d.rel_path}
                </div>

                {d.meta.summary && (
                  <div className="mt-1.5 text-[12.5px] leading-relaxed text-ink-600">
                    {d.meta.summary}
                  </div>
                )}
                {d.meta.stance && (
                  <div className="mt-1 border-l-2 border-brand-100 pl-2 text-[12px] leading-relaxed text-ink-500">
                    核心立场：{d.meta.stance}
                  </div>
                )}
                {!!d.meta.openings?.length && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {d.meta.openings.slice(0, 3).map((o, i) => (
                      <span
                        key={i}
                        className="rounded-md bg-amber-50 px-1.5 py-0.5 text-[11px] text-amber-700"
                      >
                        可延伸：{o}
                      </span>
                    ))}
                  </div>
                )}
                {failed && d.error && (
                  <div className="mt-1.5 flex items-start gap-1 text-[11.5px] text-red-600">
                    <TriangleAlert size={11} className="mt-0.5 shrink-0" />
                    {d.error}
                  </div>
                )}
              </div>

              <div className="flex shrink-0 items-center gap-1">
                {d.paper_id && (
                  <button
                    onClick={() => onOpenPaper(d.paper_id!)}
                    className="rounded-md px-2 py-1 text-[11.5px] text-ink-500 hover:bg-canvas hover:text-brand-600"
                  >
                    {t("观点")}
                  </button>
                )}
                <button
                  onClick={() => {
                    if (confirm(`${t("移除")}「${d.file_name}」${t("？会同时删除已抽取的观点。")}`)) onRemove(d.id);
                  }}
                  className="rounded-md p-1.5 text-ink-400 hover:bg-red-50 hover:text-red-600"
                  title={t("移除")}
                >
                  <Trash2 size={13} />
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
