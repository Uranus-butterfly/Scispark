import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowUp,
  Check,
  FileText,
  Folder,
  FolderOpen,
  HardDrive,
  Loader2,
  Lock,
  TriangleAlert,
} from "lucide-react";
import { localApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/feedback";
import { cn } from "@/lib/utils";
import { t } from "@/lib/i18n";

/**
 * 文件夹选择器：在浏览器里点选宿主机的目录。
 *
 * 后端把宿主 HOME 只读挂进容器，所以这里显示的路径和 Finder 里完全一致；
 * 选中后写进 app_setting，立即生效。
 */
export function FolderPicker({
  open,
  projectId,
  initialPath,
  onClose,
  onPicked,
  saving,
  error: saveError,
}: {
  open: boolean;
  projectId: string;
  initialPath: string;
  onClose: () => void;
  onPicked: (path: string) => void;
  saving?: boolean;
  error?: string | null;
}) {
  const [cur, setCur] = useState(initialPath);
  const [typed, setTyped] = useState(initialPath);

  // 每次打开都回到当前根目录
  useEffect(() => {
    if (open) {
      setCur(initialPath);
      setTyped(initialPath);
    }
  }, [open, initialPath]);

  const { data, isLoading, error } = useQuery({
    queryKey: ["localPick", projectId, cur],
    queryFn: () => localApi.pick(projectId, cur),
    enabled: open && !!cur,
    retry: false,
  });

  const go = (p: string) => {
    setCur(p);
    setTyped(p);
  };

  // 可进入的目录 + 无权限的目录，按名字混排，避免「看不见但确实存在」造成困惑
  const folders = [
    ...(data?.dirs || []).map((d) => ({ ...d, denied: false })),
    ...(data?.denied || []).map((d) => ({ ...d, papers: 0, denied: true })),
  ].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={t("选择论文所在文件夹")}
      desc={t("在这里点选你放论文的目录（支持 pdf / docx / md / txt）。选好后会记住，下次直接打开。")}
      width="max-w-2xl"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t("取消")}
          </Button>
          <Button
            variant="primary"
            disabled={!data?.exists}
            loading={saving}
            onClick={() => onPicked(cur)}
            title={data?.exists ? "" : t("这个目录不可读")}
          >
            <Check size={14} /> {t("用这个文件夹")}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        {/* 常用位置 */}
        {!!data?.quick?.length && (
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11.5px] text-ink-400">{t("常用：")}</span>
            {data.quick.map((q) => (
              <button
                key={q.path}
                onClick={() => go(q.path)}
                className={cn(
                  "rounded-md border px-2 py-0.5 text-[11.5px] transition-colors",
                  cur === q.path
                    ? "border-brand-200 bg-brand-50 text-brand-700"
                    : "border-line text-ink-600 hover:bg-canvas",
                )}
              >
                {q.label}
              </button>
            ))}
          </div>
        )}

        {/* 路径输入 + 上级 */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => data?.parent && go(data.parent)}
            disabled={!data?.parent}
            className="rounded-lg border border-line p-1.5 text-ink-500 transition-colors hover:bg-canvas disabled:opacity-40"
            title={t("上一级")}
          >
            <ArrowUp size={14} />
          </button>
          <div className="flex min-w-0 flex-1 items-center gap-1.5 rounded-lg border border-line bg-canvas px-2.5 py-1.5">
            <FolderOpen size={13} className="shrink-0 text-ink-400" />
            <input
              value={typed}
              onChange={(e) => setTyped(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && typed.trim()) go(typed.trim());
              }}
              spellCheck={false}
              className="min-w-0 flex-1 bg-transparent font-mono text-[12px] text-ink-800 outline-none"
              placeholder={t("/Users/你/论文")}
            />
          </div>
        </div>

        {/* 目录列表 */}
        <div className="h-[300px] overflow-y-auto rounded-lg border border-line">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 size={16} className="animate-spin text-ink-400" />
            </div>
          ) : error ? (
            <div className="flex items-start gap-2 px-3 py-4 text-[12px] text-amber-700">
              <TriangleAlert size={14} className="mt-0.5 shrink-0" />
              <span>{(error as Error).message || t("无法读取这个目录")}</span>
            </div>
          ) : !data?.exists ? (
            <div className="flex flex-col items-center gap-2 px-4 py-10 text-center">
              <HardDrive size={20} className="text-ink-300" />
              <div className="text-[12.5px] text-ink-500">{t("这个目录不存在或没有读取权限")}</div>
            </div>
          ) : (
            <>
              {folders.map((d) =>
                d.denied ? (
                  <div
                    key={d.path}
                    className="flex items-center gap-2 border-b border-line bg-canvas/50 px-3 py-2 text-[12px] text-ink-400"
                    title={t("macOS 没给 Docker 这个目录的访问权限：系统设置 → 隐私与安全性 → 文件与文件夹")}
                  >
                    <Lock size={14} className="shrink-0" />
                    <span className="min-w-0 flex-1 truncate">{d.name}</span>
                    <span className="text-[11px]">{t("未授权")}</span>
                  </div>
                ) : (
                  <button
                    key={d.path}
                    onClick={() => go(d.path)}
                    className="flex w-full items-center gap-2 border-b border-line px-3 py-2 text-left text-[12.5px] text-ink-700 hover:bg-canvas"
                  >
                    <Folder size={14} className="shrink-0 text-amber-500" />
                    <span className="min-w-0 flex-1 truncate">{d.name}</span>
                    {d.papers > 0 && <Badge tone="green">{d.papers} {t("篇")}</Badge>}
                  </button>
                ),
              )}
              {data.files.map((f) => (
                <div
                  key={f.path}
                  className="flex items-center gap-2 border-b border-line px-3 py-2 text-[12px] text-ink-400 last:border-0"
                >
                  <FileText size={13} className="shrink-0" />
                  <span className="min-w-0 flex-1 truncate">{f.name}</span>
                  <Badge tone="neutral">{f.ext}</Badge>
                </div>
              ))}
              {!folders.length && !data.files.length && (
                <div className="px-3 py-10 text-center text-[12.5px] text-ink-400">
                  {t("这个目录是空的（或者只有不支持的格式）")}
                </div>
              )}
            </>
          )}
        </div>

        {saveError && (
          <div className="flex items-start gap-1.5 rounded-lg border border-red-100 bg-red-50 px-2.5 py-2 text-[11.5px] text-red-700">
            <TriangleAlert size={13} className="mt-0.5 shrink-0" />
            <span className="min-w-0 break-words">{saveError}</span>
          </div>
        )}

        <div className="text-[11.5px] leading-relaxed text-ink-400">
          {t("只读访问 · 论文文件不会被修改或上传到别处，只有你点「导入」的论文正文会发给模型")}
        </div>
      </div>
    </Dialog>
  );
}
