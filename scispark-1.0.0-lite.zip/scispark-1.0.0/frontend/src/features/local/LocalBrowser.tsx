import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowUp,
  ChevronRight,
  FileText,
  Folder,
  FolderOpen,
  FolderSearch,
  HardDrive,
  Loader2,
  Upload,
} from "lucide-react";
import { localApi, type LocalDoc } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/feedback";
import { cn, formatBytes } from "@/lib/utils";
import { t } from "@/lib/i18n";

const EXT_TONE: Record<string, "brand" | "violet" | "green" | "neutral"> = {
  pdf: "brand",
  docx: "violet",
  md: "green",
  txt: "neutral",
};

export function LocalBrowser({
  projectId,
  root,
  docs,
  onImport,
  importing,
  onChangeFolder,
}: {
  projectId: string;
  root: string;
  docs: LocalDoc[];
  onImport: (paths: string[]) => void;
  importing: boolean;
  onChangeFolder: () => void;
}) {
  const [cur, setCur] = useState(root);
  const [picked, setPicked] = useState<Set<string>>(new Set());

  // 根目录变了（用户换了文件夹）就回到根目录
  useEffect(() => {
    setCur(root);
  }, [root]);

  const { data, isLoading, error } = useQuery({
    queryKey: ["localBrowse", projectId, cur],
    queryFn: () => localApi.browse(projectId, cur),
    enabled: !!cur,
    retry: false,
  });

  // 兼容老数据：老记录存的是相对路径，用「文件名 + 大小」兜底匹配
  const imported = new Set<string>();
  for (const d of docs) {
    imported.add(d.rel_path);
    imported.add(`${d.file_name}|${d.size_bytes}`);
  }
  const isDone = (f: { path: string; name: string; size: number }) =>
    imported.has(f.path) || imported.has(`${f.name}|${f.size}`);

  const toggle = (p: string) => {
    const next = new Set(picked);
    next.has(p) ? next.delete(p) : next.add(p);
    setPicked(next);
  };

  // 面包屑：cur 在 root 下面就从 root 开始切，否则显示完整路径
  const inRoot = cur === root || cur.startsWith(root.replace(/\/$/, "") + "/");
  const crumbs = inRoot
    ? cur
        .slice(root.replace(/\/$/, "").length)
        .split("/")
        .filter(Boolean)
        .map((name, i, arr) => ({
          name,
          path: root.replace(/\/$/, "") + "/" + arr.slice(0, i + 1).join("/"),
        }))
    : [];

  return (
    <div className="rounded-xl border border-line bg-surface">
      {/* 路径栏：当前文件夹 + 更换入口 */}
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2.5">
        <span className="flex shrink-0 items-center gap-1 text-[11.5px] text-ink-400">
          <FolderOpen size={13} /> {t("论文文件夹")}
        </span>
        <code
          className="min-w-0 flex-1 truncate rounded bg-canvas px-1.5 py-0.5 font-mono text-[11.5px] text-ink-700"
          title={cur}
        >
          {cur || t("（未选择）")}
        </code>
        <div className="flex shrink-0 items-center gap-1.5">
          {data?.parent && (
            <button
              onClick={() => data.parent && setCur(data.parent)}
              className="rounded p-1 text-ink-400 hover:bg-canvas hover:text-ink-700"
              title={t("上一级")}
            >
              <ArrowUp size={13} />
            </button>
          )}
          <Button size="sm" variant="subtle" onClick={onChangeFolder}>
            <FolderSearch size={13} /> {t("选择文件夹")}
          </Button>
        </div>
      </div>

      {/* 子目录面包屑 */}
      {crumbs.length > 0 && (
        <div className="flex flex-wrap items-center gap-0.5 border-b border-line bg-canvas/40 px-3 py-1.5 text-[11.5px]">
          <button
            onClick={() => setCur(root)}
            className="rounded px-1 py-0.5 text-ink-500 hover:bg-surface hover:text-ink-900"
          >
            {root.split("/").filter(Boolean).pop() || root}
          </button>
          {crumbs.map((c) => (
            <span key={c.path} className="flex items-center gap-0.5">
              <ChevronRight size={10} className="text-ink-300" />
              <button
                onClick={() => setCur(c.path)}
                className="rounded px-1 py-0.5 text-ink-500 hover:bg-surface hover:text-ink-900"
              >
                {c.name}
              </button>
            </span>
          ))}
        </div>
      )}

      {/* 没有可用根目录 */}
      {error ? (
        <div className="flex items-start gap-2 px-4 py-6 text-[12.5px] text-amber-700">
          <HardDrive size={14} className="mt-0.5 shrink-0" />
          <div className="min-w-0">
            <div className="font-medium">{t("读不到这个目录")}</div>
            <div className="mt-1 break-words text-[12px] text-amber-700/90">
              {(error as Error).message}
            </div>
            <Button size="sm" className="mt-2" onClick={onChangeFolder}>
              {t("换一个文件夹")}
            </Button>
          </div>
        </div>
      ) : !data && isLoading ? (
        <div className="flex justify-center py-10">
          <Loader2 size={16} className="animate-spin text-ink-400" />
        </div>
      ) : data && !data.exists ? (
        <div className="flex flex-col items-start gap-2 px-4 py-6">
          <div className="flex items-center gap-1.5 text-[12.5px] font-medium text-ink-800">
            <HardDrive size={14} /> {t("还没选论文文件夹")}
          </div>
          <div className="text-[12px] leading-relaxed text-ink-500">
            {t("当前目录")} <code className="rounded bg-canvas px-1 font-mono text-[11.5px]">{root}</code>{" "}
            不存在。点下面的按钮挑一个你放论文的文件夹。
          </div>
          <Button size="sm" variant="primary" onClick={onChangeFolder}>
            <FolderSearch size={13} /> {t("选择文件夹")}
          </Button>
        </div>
      ) : (
        <div className="max-h-[340px] overflow-y-auto">
          {data?.dirs.map((d) => (
            <button
              key={d.path}
              onClick={() => setCur(d.path)}
              className="flex w-full items-center gap-2 border-b border-line px-3 py-2 text-left text-[12.5px] text-ink-700 hover:bg-canvas"
            >
              <Folder size={13} className="shrink-0 text-amber-500" />
              <span className="min-w-0 flex-1 truncate">{d.name}</span>
              {d.papers > 0 && (
                <span className="font-mono text-[11px] text-ink-400">{d.papers} {t("篇")}</span>
              )}
              <ChevronRight size={12} className="text-ink-300" />
            </button>
          ))}

          {data?.files.map((f) => {
            const done = isDone(f);
            return (
              <label
                key={f.path}
                className={cn(
                  "flex cursor-pointer items-center gap-2 border-b border-line px-3 py-2 text-[12.5px]",
                  done ? "bg-canvas/60 text-ink-400" : "text-ink-700 hover:bg-canvas",
                )}
              >
                <input
                  type="checkbox"
                  disabled={done}
                  checked={picked.has(f.path)}
                  onChange={() => toggle(f.path)}
                  className="accent-indigo-600"
                />
                <FileText size={13} className="shrink-0 text-ink-400" />
                <span className="min-w-0 flex-1 truncate">{f.name}</span>
                <Badge tone={EXT_TONE[f.ext] || "neutral"}>{f.ext}</Badge>
                <span className="w-14 shrink-0 text-right font-mono text-[11px] text-ink-400">
                  {formatBytes(f.size)}
                </span>
                {done && <Badge tone="green">{t("已导入")}</Badge>}
              </label>
            );
          })}

          {!data?.dirs.length && !data?.files.length && (
            <div className="px-3 py-8 text-center text-[12.5px] text-ink-400">
              {t("这个目录里没有可导入的论文（支持 pdf / docx / md / txt）")}
            </div>
          )}
        </div>
      )}

      {/* 操作栏 */}
      <div className="flex items-center justify-between gap-2 border-t border-line px-3 py-2.5">
        <span className="min-w-0 truncate text-[11.5px] text-ink-400" title={cur}>
          {t("已选")} {picked.size} {t("个文件 · 每个文件一次 AI 调用，约 ¥0.02~0.05")}
        </span>
        <Button
          size="sm"
          variant="primary"
          disabled={!picked.size || importing}
          loading={importing}
          onClick={() => {
            onImport([...picked]);
            setPicked(new Set());
          }}
        >
          <Upload size={13} /> {t("导入并抽取观点")}
        </Button>
      </div>
    </div>
  );
}
