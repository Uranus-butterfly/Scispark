import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle2,
  Compass,
  FolderSearch,
  Lightbulb,
  Loader2,
  ListTree,
  TriangleAlert,
} from "lucide-react";
import { graphApi, localApi, projectsApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge, Spinner } from "@/components/ui/feedback";
import { Progress } from "@/components/ui/progress";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { useJob } from "@/hooks/useJob";
import { cn, formatCny } from "@/lib/utils";
import { PaperInsightDrawer } from "@/features/papers/PaperInsightDrawer";
import { FolderPicker } from "./FolderPicker";
import { LocalBrowser } from "./LocalBrowser";
import { DocList } from "./DocList";
import { OutlineView } from "./OutlineView";
import { DiscussionView } from "./DiscussionView";
import { pickName, t } from "@/lib/i18n";

type Tab = "docs" | "outline" | "discussion";

const TABS: { key: Tab; label: string; icon: typeof ListTree }[] = [
  { key: "docs", label: t("已导入"), icon: FolderSearch },
  { key: "outline", label: t("大纲"), icon: ListTree },
  { key: "discussion", label: t("创新点讨论"), icon: Lightbulb },
];

export default function LocalPapersPage() {
  const { projectId = "" } = useParams();
  const qc = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();

  const initialTab = (searchParams.get("tab") as Tab) || "docs";
  const [tab, setTab] = useState<Tab>(
    ["docs", "outline", "discussion"].includes(initialTab) ? initialTab : "docs",
  );
  const [jobId, setJobId] = useState<string | null>(null);
  const [selectedPaper, setSelectedPaper] = useState<string | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [checkingIdea, setCheckingIdea] = useState<string | null>(null);

  // 当前 Tab 同步到 URL，方便刷新/分享
  useEffect(() => {
    const next = new URLSearchParams(searchParams);
    if (tab === "docs") next.delete("tab");
    else next.set("tab", tab);
    if (next.toString() !== searchParams.toString()) {
      setSearchParams(next, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const { data: project } = useQuery({
    queryKey: ["project", projectId],
    queryFn: () => projectsApi.get(projectId),
    enabled: !!projectId,
  });
  const { data: docs } = useQuery({
    queryKey: ["localDocs", projectId],
    queryFn: () => localApi.docs(projectId),
    enabled: !!projectId,
  });
  const { data: rootInfo } = useQuery({
    queryKey: ["localRoot", projectId],
    queryFn: () => localApi.root(projectId),
    enabled: !!projectId,
  });
  const { data: outline } = useQuery({
    queryKey: ["localOutline", projectId],
    queryFn: () => localApi.outline(projectId),
    enabled: !!projectId,
  });
  const { data: discussion } = useQuery({
    queryKey: ["localDiscussion", projectId],
    queryFn: () => localApi.discussion(projectId),
    enabled: !!projectId,
  });

  const refreshAll = () => {
    qc.invalidateQueries({ queryKey: ["localDocs", projectId] });
    qc.invalidateQueries({ queryKey: ["localOutline", projectId] });
    qc.invalidateQueries({ queryKey: ["localDiscussion", projectId] });
    qc.invalidateQueries({ queryKey: ["papers", projectId] });
    qc.invalidateQueries({ queryKey: ["cost"] });
  };

  const { job } = useJob(jobId, () => {
    refreshAll();
    setCheckingIdea(null);
  });

  // 第一次进来、还没选过文件夹时，直接弹出选择器，省得用户找按钮
  useEffect(() => {
    if (rootInfo && !rootInfo.exists) setPickerOpen(true);
  }, [rootInfo]);

  const importDocs = useMutation({
    mutationFn: (relPaths: string[]) => localApi.import(projectId, relPaths),
    onSuccess: (r) => setJobId(r.job_id),
  });
  const buildOutline = useMutation({
    mutationFn: () => localApi.buildOutline(projectId),
    onSuccess: (r) => {
      setJobId(r.job_id);
      setTab("outline");
    },
  });
  const discuss = useMutation({
    mutationFn: () => localApi.discuss(projectId),
    onSuccess: (r) => {
      setJobId(r.job_id);
      setTab("discussion");
    },
  });
  const removeDoc = useMutation({
    mutationFn: (docId: string) => localApi.removeDoc(projectId, docId),
    onSuccess: refreshAll,
  });
  const setRoot = useMutation({
    mutationFn: (path: string) => localApi.setRoot(projectId, path),
    onSuccess: () => {
      setPickerOpen(false);
      qc.invalidateQueries({ queryKey: ["localRoot", projectId] });
      qc.invalidateQueries({ queryKey: ["localBrowse", projectId] });
      qc.invalidateQueries({ queryKey: ["localPick", projectId] });
    },
  });
  const checkNovelty = useMutation({
    mutationFn: (ideaId: string) => graphApi.novelty(projectId, ideaId),
    onSuccess: (r, ideaId) => {
      setCheckingIdea(ideaId);
      setJobId(r.job_id);
    },
  });

  const running = job?.status === "running" || job?.status === "queued";
  const extracted = (docs || []).filter((d) => d.status === "extracted");
  const canOutline = extracted.length > 0;

  return (
    <div className="min-h-full">
      <PageHeader
        title={t("本地论文")}
        desc={t("读你指定文件夹里的论文，抽取观点、整理成跨篇大纲，再一起讨论可能的创新点")}
        actions={
          <>
            <Button
              disabled={!canOutline || running}
              loading={buildOutline.isPending}
              onClick={() => buildOutline.mutate()}
              title={canOutline ? "" : t("先导入并抽取观点")}
            >
              <ListTree size={14} /> {t("生成大纲")}
            </Button>
            <Button
              variant="primary"
              disabled={!outline || running}
              loading={discuss.isPending}
              onClick={() => discuss.mutate()}
              title={outline ? "" : t("先生成大纲")}
            >
              <Lightbulb size={14} /> {t("讨论创新点")}
            </Button>
          </>
        }
      />

      <PageBody className="max-w-5xl space-y-4">
        {project && (
          <div className="text-[12px] text-ink-400">
            {t("项目：")}{pickName(project.name, project.name_en)} · {project.topic}
          </div>
        )}

        {rootInfo ? (
          <LocalBrowser
            projectId={projectId}
            root={rootInfo.root}
            docs={docs || []}
            importing={importDocs.isPending || running}
            onImport={(paths) => importDocs.mutate(paths)}
            onChangeFolder={() => setPickerOpen(true)}
          />
        ) : (
          <div className="flex justify-center rounded-xl border border-line bg-surface py-10">
            <Spinner />
          </div>
        )}

        {/* 任务进度 */}
        {(running || job?.status === "failed" || job?.status === "done") && (
          <div
            className={cn(
              "rounded-xl border px-4 py-3",
              job?.status === "failed"
                ? "border-red-100 bg-red-50"
                : "border-line bg-surface",
            )}
          >
            {running && (
              <>
                <div className="flex items-center justify-between text-[12.5px]">
                  <span className="flex items-center gap-1.5 text-ink-700">
                    <Loader2 size={13} className="animate-spin" />
                    {job?.step || t("处理中…")}
                  </span>
                  <span className="font-mono text-ink-500">
                    {Math.round((job?.progress ?? 0) * 100)}%
                  </span>
                </div>
                <Progress className="mt-2" value={job?.progress ?? 0} />
              </>
            )}
            {job?.status === "failed" && (
              <div className="flex items-start gap-2 text-[12.5px] text-red-700">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <div className="font-medium">{t("处理失败")}</div>
                  <div className="mt-0.5 whitespace-pre-wrap break-words text-[11.5px] text-red-600/90">
                    {(job.error || "").split("\n")[0]}
                  </div>
                </div>
              </div>
            )}
            {job?.status === "done" && (
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-ink-600">
                <span className="flex items-center gap-1 font-medium text-emerald-700">
                  <CheckCircle2 size={13} /> {t("完成")}
                </span>
                {(() => {
                  const r = (job.result || {}) as Record<string, unknown>;
                  if (job.type === "local_import") {
                    return (
                      <>
                        <span>共 {String(r.total ?? 0)} {t("个文件")}</span>
                        <span className="text-ink-900">成功 {String(r.ok ?? 0)}</span>
                        {Number(r.failed ?? 0) > 0 && (
                          <span className="text-amber-600">失败 {String(r.failed)}</span>
                        )}
                      </>
                    );
                  }
                  if (job.type === "local_outline") {
                    return <span>基于 {String(r.docs ?? 0)} {t("篇论文生成")}</span>;
                  }
                  if (job.type === "local_discuss") {
                    return <span>提出 {String(r.ideas ?? 0)} {t("个创新点")}</span>;
                  }
                  if (job.type === "novelty") {
                    return <span>查重完成：{String(r.status ?? "")}</span>;
                  }
                  return null;
                })()}
                <Badge tone="brand">
                  本次花费 {formatCny(Number((job.result as Record<string, unknown>)?.cost_cny ?? 0))}
                </Badge>
              </div>
            )}
          </div>
        )}

        {/* Tabs */}
        <div className="flex items-center gap-1 border-b border-line">
          {TABS.map((t) => {
            const active = tab === t.key;
            const count =
              t.key === "docs" ? docs?.length : t.key === "outline" ? (outline ? 1 : 0) : discussion ? 1 : 0;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={cn(
                  "flex items-center gap-1.5 border-b-2 px-3 py-2 text-[13px] transition-colors",
                  active
                    ? "border-brand-600 font-medium text-brand-700"
                    : "border-transparent text-ink-500 hover:text-ink-900",
                )}
              >
                <t.icon size={13} />
                {t.label}
                {count ? <span className="font-mono text-[11px] text-ink-400">{count}</span> : null}
              </button>
            );
          })}
        </div>

        {!docs ? (
          <div className="flex justify-center py-12">
            <Spinner />
          </div>
        ) : tab === "docs" ? (
          <DocList
            docs={docs}
            onRemove={(id) => removeDoc.mutate(id)}
            onOpenPaper={(pid) => setSelectedPaper(pid)}
          />
        ) : tab === "outline" ? (
          <OutlineView outline={outline ?? null} />
        ) : (
          <DiscussionView
            data={discussion ?? null}
            checkingId={checkingIdea}
            onCheck={(id) => checkNovelty.mutate(id)}
          />
        )}

        {tab !== "docs" && !outline && (
          <div className="flex items-center gap-1.5 text-[11.5px] text-ink-400">
            <Compass size={12} /> {t("提示：大纲和创新点都基于已抽取的观点，观点越多质量越好")}
          </div>
        )}
      </PageBody>

      <PaperInsightDrawer paperId={selectedPaper} onClose={() => setSelectedPaper(null)} />

      <FolderPicker
        open={pickerOpen}
        projectId={projectId}
        initialPath={rootInfo?.root ?? ""}
        saving={setRoot.isPending}
        error={setRoot.error ? (setRoot.error as Error).message : null}
        onClose={() => setPickerOpen(false)}
        onPicked={(path) => setRoot.mutate(path)}
      />
    </div>
  );
}
