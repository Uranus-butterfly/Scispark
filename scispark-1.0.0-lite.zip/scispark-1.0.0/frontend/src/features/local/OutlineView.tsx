import { AlertTriangle, Compass, GitBranch, Layers, Lightbulb } from "lucide-react";
import type { OutlineData } from "@/lib/api";
import { Badge } from "@/components/ui/feedback";
import { t } from "@/lib/i18n";

function SectionTitle({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-800">
      {icon}
      {children}
    </div>
  );
}

export function OutlineView({ outline }: { outline: OutlineData | null }) {
  if (!outline) {
    return (
      <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-12 text-center">
        <div className="text-[13px] font-medium text-ink-700">{t("还没有大纲")}</div>
        <div className="mt-1 text-[12.5px] text-ink-400">
          {t("先导入几篇论文，再点右上角「生成大纲」")}
        </div>
      </div>
    );
  }

  const b = outline.body;

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-line bg-surface px-5 py-4">
        <div className="text-[15px] font-semibold text-ink-900">{b.title || outline.title}</div>
        {b.premise && (
          <div className="mt-1.5 rounded-lg bg-canvas px-3 py-2 text-[12.5px] leading-relaxed text-ink-600">
            <span className="font-medium text-ink-700">{t("共同前提：")}</span>
            {b.premise}
          </div>
        )}
        <div className="mt-2 flex flex-wrap gap-1">
          {outline.docs.map((d) => (
            <Badge key={d} tone="neutral">
              {d}
            </Badge>
          ))}
        </div>
      </div>

      {/* 分层大纲 */}
      <div className="space-y-3">
        {(b.sections || []).map((sec, si) => (
          <div key={si} className="rounded-xl border border-line bg-surface">
            <div className="flex items-center gap-2 border-b border-line px-4 py-2.5">
              <span className="flex h-5 w-5 items-center justify-center rounded bg-brand-50 font-mono text-[11px] text-brand-700">
                {si + 1}
              </span>
              <span className="text-[13.5px] font-semibold text-ink-900">{sec.heading}</span>
              <span className="ml-auto text-[11px] text-ink-400">{sec.points?.length ?? 0} {t("条")}</span>
            </div>
            <div className="divide-y divide-line">
              {(sec.points || []).map((p, pi) => (
                <div key={pi} className="px-4 py-2.5">
                  <div className="flex items-start gap-1.5">
                    <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-brand-500" />
                    <div className="min-w-0">
                      <div className="text-[13px] font-medium leading-relaxed text-ink-900">
                        {p.point}
                      </div>
                      {p.detail && (
                        <div className="mt-0.5 text-[12.5px] leading-relaxed text-ink-600">
                          {p.detail}
                        </div>
                      )}
                      {!!p.sources?.length && (
                        <div className="mt-1 flex flex-wrap gap-1">
                          {p.sources.map((s) => (
                            <span
                              key={s}
                              className="rounded bg-canvas px-1.5 py-0.5 font-mono text-[10.5px] text-ink-500"
                            >
                              {s}
                            </span>
                          ))}
                        </div>
                      )}
                      {p.tension && (
                        <div className="mt-1.5 flex items-start gap-1 rounded-md border border-amber-100 bg-amber-50 px-2 py-1 text-[11.5px] leading-relaxed text-amber-800">
                          <AlertTriangle size={11} className="mt-0.5 shrink-0" />
                          <span>{p.tension}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {b.evolution && (
        <div className="rounded-xl border border-line bg-surface px-4 py-3">
          <SectionTitle icon={<GitBranch size={13} className="text-brand-600" />}>{t("演进脉络")}</SectionTitle>
          <div className="mt-1.5 text-[12.5px] leading-relaxed text-ink-700">{b.evolution}</div>
        </div>
      )}

      <div className="grid gap-3 md:grid-cols-2">
        {!!b.consensus?.length && (
          <div className="rounded-xl border border-line bg-surface px-4 py-3">
            <SectionTitle icon={<Layers size={13} className="text-emerald-600" />}>{t("已形成共识")}</SectionTitle>
            <ul className="mt-1.5 space-y-1">
              {b.consensus.map((c, i) => (
                <li key={i} className="flex gap-1.5 text-[12.5px] leading-relaxed text-ink-700">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-emerald-500" />
                  {c}
                </li>
              ))}
            </ul>
          </div>
        )}
        {!!b.disputes?.length && (
          <div className="rounded-xl border border-line bg-surface px-4 py-3">
            <SectionTitle icon={<AlertTriangle size={13} className="text-amber-600" />}>{t("仍有争议")}</SectionTitle>
            <ul className="mt-1.5 space-y-1">
              {b.disputes.map((c, i) => (
                <li key={i} className="flex gap-1.5 text-[12.5px] leading-relaxed text-ink-700">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-amber-500" />
                  {c}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {!!b.gaps?.length && (
        <div className="rounded-xl border border-brand-100 bg-brand-50/40 px-4 py-3">
          <SectionTitle icon={<Compass size={13} className="text-brand-600" />}>
            研究空白（{b.gaps.length}）
          </SectionTitle>
          <div className="mt-2 space-y-2">
            {b.gaps.map((g, i) => (
              <div key={i} className="rounded-lg border border-line bg-surface px-3 py-2">
                <div className="flex items-start gap-1.5">
                  <Lightbulb size={12} className="mt-0.5 shrink-0 text-amber-500" />
                  <div>
                    <div className="text-[12.5px] font-medium leading-relaxed text-ink-900">{g.gap}</div>
                    {g.why && (
                      <div className="mt-0.5 text-[12px] leading-relaxed text-ink-500">{g.why}</div>
                    )}
                    {!!g.who_noticed?.length && (
                      <div className="mt-1 text-[11px] text-ink-400">
                        提到过但未解决：{g.who_noticed.join("、")}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
