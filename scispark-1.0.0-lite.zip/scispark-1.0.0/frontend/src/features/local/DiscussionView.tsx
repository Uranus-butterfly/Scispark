import { AlertOctagon, ArrowRight, MessageCircleQuestion, SearchCheck, ShieldAlert, Sparkles } from "lucide-react";
import type { DiscussedIdea, DiscussionData } from "@/lib/api";
import { Badge } from "@/components/ui/feedback";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { t } from "@/lib/i18n";

const STATUS_META: Record<string, { label: string; cls: string }> = {
  novel: { label: t("未找到相同工作"), cls: "border-emerald-200 bg-emerald-50 text-emerald-700" },
  partial: { label: t("有相近工作"), cls: "border-amber-200 bg-amber-50 text-amber-700" },
  done: { label: t("已经有人做过"), cls: "border-red-200 bg-red-50 text-red-700" },
  unchecked: { label: t("无法判断"), cls: "border-line bg-canvas text-ink-500" },
};

function NoveltyBlock({
  idea,
  onCheck,
  checking,
}: {
  idea: DiscussedIdea;
  onCheck: (id: string) => void;
  checking: boolean;
}) {
  const check = idea.extra?.check;
  const meta = STATUS_META[check?.status ?? idea.novelty_status ?? "unchecked"];

  if (!check) {
    return (
      <Button size="sm" variant="subtle" loading={checking} onClick={() => onCheck(idea.id)}>
        <SearchCheck size={12} /> {t("查重")}
      </Button>
    );
  }

  return (
    <div className="w-full space-y-1.5">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className={cn("rounded border px-1.5 py-0.5 text-[10.5px] font-medium", meta.cls)}>
          {meta.label}
        </span>
        <span className="text-[11px] text-ink-500">{check.summary}</span>
        <button
          onClick={() => onCheck(idea.id)}
          className="ml-auto text-[10.5px] text-ink-400 hover:text-brand-700 hover:underline"
        >
          {t("重新查")}
        </button>
      </div>
      {!!check.closest?.length && (
        <div className="space-y-1 rounded-lg bg-canvas px-2.5 py-2">
          {check.closest.slice(0, 3).map((c, i) => (
            <div key={i} className="text-[11px] leading-relaxed text-ink-600">
              <span className="font-medium text-ink-800">{c.what_it_does}</span>
              {c.delta && <span className="text-ink-500"> — 差别：{c.delta}</span>}
            </div>
          ))}
        </div>
      )}
      {!!check.suggestions?.length && (
        <div className="text-[11px] leading-relaxed text-ink-500">
          可以这样加强：{check.suggestions.join("；")}
        </div>
      )}
    </div>
  );
}

function Score({ label, value }: { label: string; value: number }) {
  const v = Math.max(1, Math.min(5, Math.round(value || 1)));
  return (
    <div className="flex items-center gap-1">
      <span className="text-[10.5px] text-ink-400">{label}</span>
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((i) => (
          <span
            key={i}
            className={cn(
              "h-1.5 w-1.5 rounded-full",
              i <= v
                ? v >= 4
                  ? "bg-emerald-500"
                  : v >= 3
                    ? "bg-brand-500"
                    : "bg-amber-500"
                : "bg-line",
            )}
          />
        ))}
      </div>
    </div>
  );
}

export function DiscussionView({
  data,
  onCheck,
  checkingId,
}: {
  data: DiscussionData | null;
  onCheck: (ideaId: string) => void;
  checkingId?: string | null;
}) {
  if (!data) {
    return (
      <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-12 text-center">
        <div className="text-[13px] font-medium text-ink-700">{t("还没有讨论")}</div>
        <div className="mt-1 text-[12.5px] text-ink-400">
          {t("先生成大纲，再点右上角「讨论创新点」")}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {data.judgement && (
        <div className="rounded-xl border border-brand-100 bg-brand-50/50 px-4 py-3">
          <div className="flex items-center gap-1.5 text-[12.5px] font-semibold text-brand-700">
            <Sparkles size={13} /> {t("整体判断")}
          </div>
          <div className="mt-1 text-[13px] leading-relaxed text-ink-800">{data.judgement}</div>
        </div>
      )}

      {data.ideas.map((idea, i) => (
        <div key={idea.id} className="rounded-xl border border-line bg-surface">
          <div className="flex items-start gap-2 border-b border-line px-4 py-3">
            <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded bg-brand-600 font-mono text-[11px] text-white">
              {i + 1}
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[14px] font-semibold text-ink-900">{idea.title}</div>
              {idea.one_liner && (
                <div className="mt-0.5 text-[12.5px] leading-relaxed text-ink-600">
                  {idea.one_liner}
                </div>
              )}
            </div>
            <div className="flex shrink-0 flex-col items-end gap-1">
              <Score label={t("新颖")} value={idea.extra?.novelty ?? 0} />
              <Score label={t("可行")} value={idea.feasibility} />
              <Score label={t("影响")} value={idea.impact} />
            </div>
          </div>

          <div className="space-y-2.5 px-4 py-3">
            {idea.gap && (
              <div>
                <div className="text-[11.5px] font-medium text-ink-500">{t("填的空白")}</div>
                <div className="text-[12.5px] leading-relaxed text-ink-800">{idea.gap}</div>
              </div>
            )}
            {idea.why_novel && (
              <div>
                <div className="text-[11.5px] font-medium text-ink-500">{t("为什么新")}</div>
                <div className="text-[12.5px] leading-relaxed text-ink-800">{idea.why_novel}</div>
              </div>
            )}
            {idea.method_sketch && (
              <div>
                <div className="text-[11.5px] font-medium text-ink-500">{t("怎么做")}</div>
                <ol className="mt-0.5 space-y-0.5">
                  {idea.method_sketch.split("\n").filter(Boolean).map((step, si) => (
                    <li key={si} className="flex gap-1.5 text-[12.5px] leading-relaxed text-ink-700">
                      <span className="font-mono text-[11px] text-ink-400">{si + 1}.</span>
                      <span>{step.replace(/^\d+[.、)]\s*/, "")}</span>
                    </li>
                  ))}
                </ol>
              </div>
            )}

            <div className="grid gap-2 sm:grid-cols-2">
              {idea.risks && (
                <div className="rounded-lg border border-red-100 bg-red-50/60 px-2.5 py-2">
                  <div className="flex items-center gap-1 text-[11px] font-medium text-red-700">
                    <ShieldAlert size={11} /> {t("最大风险")}
                  </div>
                  <div className="mt-0.5 text-[12px] leading-relaxed text-red-800/90">{idea.risks}</div>
                </div>
              )}
              {idea.extra?.next_step && (
                <div className="rounded-lg border border-emerald-100 bg-emerald-50/60 px-2.5 py-2">
                  <div className="flex items-center gap-1 text-[11px] font-medium text-emerald-700">
                    <ArrowRight size={11} /> {t("最小验证")}
                  </div>
                  <div className="mt-0.5 text-[12px] leading-relaxed text-emerald-800/90">
                    {idea.extra.next_step}
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {idea.extra?.collision && (
                <Badge tone="amber">可能撞车：{idea.extra.collision}</Badge>
              )}
              {(idea.extra?.evidence || []).map((e) => (
                <Badge key={e} tone="neutral">
                  {e}
                </Badge>
              ))}
              <NoveltyBlock idea={idea} onCheck={onCheck} checking={checkingId === idea.id} />
            </div>
          </div>
        </div>
      ))}

      {!!data.discussion?.length && (
        <div className="rounded-xl border border-line bg-surface px-4 py-3">
          <div className="flex items-center gap-1.5 text-[12.5px] font-semibold text-ink-800">
            <MessageCircleQuestion size={13} className="text-brand-600" /> {t("值得继续讨论")}
          </div>
          <ul className="mt-1.5 space-y-1.5">
            {data.discussion.map((d, i) => (
              <li key={i} className="flex gap-1.5 text-[12.5px] leading-relaxed text-ink-700">
                <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-brand-500" />
                {d}
              </li>
            ))}
          </ul>
        </div>
      )}

      {!!data.counterpoints?.length && (
        <div className="rounded-xl border border-amber-200 bg-amber-50/60 px-4 py-3">
          <div className="flex items-center gap-1.5 text-[12.5px] font-semibold text-amber-800">
            <AlertOctagon size={13} /> {t("反方意见")}
          </div>
          <ul className="mt-1.5 space-y-1.5">
            {data.counterpoints.map((d, i) => (
              <li key={i} className="flex gap-1.5 text-[12.5px] leading-relaxed text-amber-900/90">
                <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-amber-500" />
                {d}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
