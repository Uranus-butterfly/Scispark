import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle2,
  Clock,
  History,
  Loader2,
  Radar,
  Sparkles,
  TriangleAlert,
} from "lucide-react";
import {
  papersApi,
  scanApi,
  type ScanReport,
  type ScanView,
  type ScanWindow,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge, Spinner } from "@/components/ui/feedback";
import { Progress } from "@/components/ui/progress";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { useJob } from "@/hooks/useJob";
import { cn, formatCny } from "@/lib/utils";
import { PaperInsightDrawer } from "@/features/papers/PaperInsightDrawer";
import { t } from "@/lib/i18n";

const WINDOWS: { key: ScanWindow; label: string; hint: string }[] = [
  { key: "week", label: t("近一周"), hint: t("7 天") },
  { key: "month", label: t("近一月"), hint: t("30 天") },
  { key: "quarter", label: t("近三月"), hint: t("90 天") },
  { key: "half_year", label: t("近半年"), hint: t("180 天") },
  { key: "year", label: t("近一年"), hint: t("365 天") },
];

const TREND: Record<string, { label: string; cls: string }> = {
  rising: { label: t("在升温"), cls: "border-emerald-200 bg-emerald-50 text-emerald-700" },
  steady: { label: t("平稳"), cls: "border-line bg-canvas text-ink-500" },
  new: { label: t("刚出现"), cls: "border-amber-200 bg-amber-50 text-amber-700" },
};

function Switch({
  checked,
  onChange,
  disabled,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-50",
        checked ? "bg-brand-600" : "bg-line",
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all",
          checked ? "left-[22px]" : "left-0.5",
        )}
      />
    </button>
  );
}

function ReportView({
  report,
  paperTitle,
  onOpenPaper,
}: {
  report: ScanReport;
  paperTitle: (id: string) => string;
  onOpenPaper: (id: string) => void;
}) {
  const lists: { title: string; items?: string[]; tone: string }[] = [
    { title: t("相比已有积累，新在哪"), items: report.whats_new, tone: "text-brand-700" },
    { title: t("冒出来但没解决的问题"), items: report.open_questions, tone: "text-amber-700" },
    { title: t("接下来值得盯"), items: report.watch_next, tone: "text-emerald-700" },
  ];

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-brand-100 bg-brand-50/40 px-5 py-4">
        <div className="flex items-center gap-1.5 text-[11px] font-medium text-brand-700">
          <Sparkles size={12} /> 这段时间最值得知道的一件事
          {report.window && (
            <span className="ml-1 font-normal text-ink-400">
              {report.window[0]} ~ {report.window[1]}
            </span>
          )}
        </div>
        <div className="mt-1.5 text-[15px] font-semibold leading-relaxed text-ink-900">
          {report.headline}
        </div>
        {report.overview && (
          <div className="mt-1.5 text-[12.5px] leading-relaxed text-ink-600">{report.overview}</div>
        )}
        {report.counts && (
          <div className="mt-2 flex flex-wrap gap-x-3 text-[11px] text-ink-400">
            <span>窗口内 {report.counts.found} {t("篇")}</span>
            <span>新增 {report.counts.new} {t("篇")}</span>
            <span>精读 {report.counts.read} {t("篇")}</span>
          </div>
        )}
      </div>

      {!!report.themes?.length && (
        <div className="space-y-2">
          {report.themes.map((t, i) => {
            const trend = TREND[t.trend ?? "steady"] ?? TREND.steady;
            return (
              <div key={i} className="rounded-xl border border-line bg-surface px-4 py-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[13.5px] font-semibold text-ink-900">{t.name}</span>
                  <span className={cn("rounded border px-1.5 py-0.5 text-[10.5px]", trend.cls)}>
                    {trend.label}
                  </span>
                </div>
                <div className="mt-1 text-[12.5px] leading-relaxed text-ink-700">{t.summary}</div>
                {!!t.paper_ids?.length && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {t.paper_ids.map((pid) => (
                      <button
                        key={pid}
                        onClick={() => onOpenPaper(pid)}
                        className="max-w-[280px] truncate rounded border border-line bg-canvas px-1.5 py-0.5 text-[10.5px] text-ink-600 hover:border-brand-200 hover:text-brand-700"
                        title={paperTitle(pid)}
                      >
                        {paperTitle(pid)}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {!!report.notable?.length && (
        <div className="rounded-xl border border-line bg-surface px-4 py-3">
          <div className="text-[12.5px] font-semibold text-ink-800">{t("值得单独看的")}</div>
          <div className="mt-1.5 space-y-1.5">
            {report.notable.map((n, i) => (
              <div key={i} className="flex gap-2 text-[12px] leading-relaxed">
                <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-brand-500" />
                <div className="min-w-0">
                  <button
                    onClick={() => onOpenPaper(n.paper_id)}
                    className="truncate text-left font-medium text-brand-700 hover:underline"
                  >
                    {paperTitle(n.paper_id)}
                  </button>
                  <span className="text-ink-600"> — {n.why}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-3">
        {lists.map((l) =>
          l.items?.length ? (
            <div key={l.title} className="rounded-xl border border-line bg-surface px-3.5 py-3">
              <div className={cn("text-[11.5px] font-semibold", l.tone)}>{l.title}</div>
              <ul className="mt-1.5 space-y-1">
                {l.items.map((x, i) => (
                  <li key={i} className="flex gap-1.5 text-[11.5px] leading-relaxed text-ink-600">
                    <span className="mt-[6px] h-1 w-1 shrink-0 rounded-full bg-ink-300" />
                    {x}
                  </li>
                ))}
              </ul>
            </div>
          ) : null,
        )}
      </div>
    </div>
  );
}

export default function ScanPage() {
  const { projectId = "" } = useParams();
  const qc = useQueryClient();
  const [window, setWindow] = useState<ScanWindow>("month");
  const [custom, setCustom] = useState<{ from: string; to: string }>({ from: "", to: "" });
  const [useCustom, setUseCustom] = useState(false);
  const [jobId, setJobId] = useState<string | null>(null);
  const [openPaper, setOpenPaper] = useState<string | null>(null);

  const { data } = useQuery({
    queryKey: ["scan", projectId],
    queryFn: () => scanApi.get(projectId),
    enabled: !!projectId,
  });
  const { data: papers } = useQuery({
    queryKey: ["papers", projectId, "scan"],
    queryFn: () => papersApi.list(projectId, { limit: 300 }),
    enabled: !!projectId,
  });

  const titles = useMemo(() => {
    const m = new Map<string, string>();
    for (const p of papers?.items ?? []) m.set(p.id, p.title);
    return m;
  }, [papers]);
  const paperTitle = (id: string) => titles.get(id) || t("（论文）");

  const { job } = useJob(jobId, () => {
    qc.invalidateQueries({ queryKey: ["scan", projectId] });
    qc.invalidateQueries({ queryKey: ["papers", projectId] });
    qc.invalidateQueries({ queryKey: ["cost"] });
  });

  const toggle = useMutation({
    mutationFn: (enabled: boolean) => scanApi.updateTopic(projectId, { enabled }),
    onSuccess: (v) => qc.setQueryData(["scan", projectId], v as ScanView),
  });
  const run = useMutation({
    mutationFn: () =>
      scanApi.run(projectId, {
        window,
        date_from: useCustom ? custom.from || undefined : undefined,
        date_to: useCustom ? custom.to || undefined : undefined,
      }),
    onSuccess: (r) => setJobId(r.job_id),
  });

  const enabled = data?.topic.enabled ?? false;
  const running = job?.status === "running" || job?.status === "queued";
  const report = data?.latest_report ?? null;

  return (
    <div className="min-h-full">
      <PageHeader
        title={t("进展扫描")}
        desc={t("指定一个时间窗，看看这段时间这个方向发生了什么——不是摘要堆叠，是判断")}
        actions={
          <Button
            variant="primary"
            disabled={!enabled || running}
            loading={run.isPending}
            onClick={() => run.mutate()}
            title={enabled ? "" : t("先打开监控开关")}
          >
            <Radar size={14} /> {t("扫描这段时间")}
          </Button>
        }
      />

      <PageBody className="max-w-4xl space-y-4">
        {/* 开关 + 时间窗 */}
        <div
          className={cn(
            "rounded-xl border bg-surface px-4 py-3.5 transition-opacity",
            enabled ? "border-line" : "border-dashed border-line opacity-80",
          )}
        >
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[13.5px] font-semibold text-ink-900">{t("监控这个方向")}</span>
                <Badge tone={enabled ? "green" : "neutral"}>{enabled ? t("已开启") : t("未开启")}</Badge>
              </div>
              <div className="mt-1 text-[12px] leading-relaxed text-ink-500">
                {enabled
                  ? t("关掉之后不会扫描，也不会有任何后台请求。想用的时候再打开。")
                  : t("默认关闭。打开后才能选时间窗扫描——不会在后台常驻跑，也不会偷偷花钱。")}
              </div>
              {data?.topic.query && (
                <div className="mt-1.5 truncate text-[11.5px] text-ink-400" title={data.topic.query}>
                  关注方向：{data.topic.query}
                </div>
              )}
            </div>
            <Switch checked={enabled} onChange={(v) => toggle.mutate(v)} disabled={toggle.isPending} />
          </div>

          <div className="mt-3 border-t border-line pt-3">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="mr-1 text-[11.5px] text-ink-400">{t("时间窗")}</span>
              {WINDOWS.map((w) => (
                <button
                  key={w.key}
                  onClick={() => {
                    setWindow(w.key);
                    setUseCustom(false);
                  }}
                  disabled={!enabled}
                  className={cn(
                    "rounded-md border px-2 py-0.5 text-[11.5px] transition-colors disabled:opacity-50",
                    !useCustom && window === w.key
                      ? "border-brand-200 bg-brand-50 text-brand-700"
                      : "border-line text-ink-500 hover:bg-canvas",
                  )}
                >
                  {w.label}
                </button>
              ))}
              <button
                onClick={() => setUseCustom((v) => !v)}
                disabled={!enabled}
                className={cn(
                  "rounded-md border px-2 py-0.5 text-[11.5px] transition-colors disabled:opacity-50",
                  useCustom
                    ? "border-brand-200 bg-brand-50 text-brand-700"
                    : "border-line text-ink-500 hover:bg-canvas",
                )}
              >
                {t("自定义")}
              </button>
            </div>

            {useCustom && (
              <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11.5px] text-ink-500">
                <input
                  type="date"
                  value={custom.from}
                  onChange={(e) => setCustom((c) => ({ ...c, from: e.target.value }))}
                  className="rounded border border-line bg-canvas px-1.5 py-1 text-[11.5px]"
                />
                <span>{t("至")}</span>
                <input
                  type="date"
                  value={custom.to}
                  onChange={(e) => setCustom((c) => ({ ...c, to: e.target.value }))}
                  className="rounded border border-line bg-canvas px-1.5 py-1 text-[11.5px]"
                />
              </div>
            )}

            {data?.topic.last_scan_at && (
              <div className="mt-2 flex items-center gap-1 text-[11px] text-ink-400">
                <Clock size={10} /> 上次扫描：{data.topic.last_scan_at}
              </div>
            )}
          </div>
        </div>

        {/* 进度 */}
        {(running || job?.status === "failed" || job?.status === "done") && (
          <div
            className={cn(
              "rounded-xl border px-4 py-3",
              job?.status === "failed" ? "border-red-100 bg-red-50" : "border-line bg-surface",
            )}
          >
            {running && (
              <>
                <div className="flex items-center justify-between text-[12.5px]">
                  <span className="flex items-center gap-1.5 text-ink-700">
                    <Loader2 size={13} className="animate-spin" />
                    {job?.step || t("处理中…")}
                  </span>
                  <span className="font-mono text-ink-500">
                    {Math.round((job?.progress ?? 0) * 100)}%
                  </span>
                </div>
                <Progress className="mt-2" value={job?.progress ?? 0} />
              </>
            )}
            {job?.status === "failed" && (
              <div className="flex items-start gap-2 text-[12.5px] text-red-700">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <div className="font-medium">{t("扫描失败")}</div>
                  <div className="mt-0.5 whitespace-pre-wrap break-words text-[11.5px] text-red-600/90">
                    {(job.error || "").split("\n")[0]}
                  </div>
                </div>
              </div>
            )}
            {job?.status === "done" && (
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-ink-600">
                <span className="flex items-center gap-1 font-medium text-emerald-700">
                  <CheckCircle2 size={13} /> {t("扫描完成")}
                </span>
                <span>
                  找到 {String((job.result as Record<string, unknown>)?.found ?? 0)} {t("篇 · 新增")}{" "}
                  {String((job.result as Record<string, unknown>)?.new ?? 0)} {t("篇 · 精读")}{" "}
                  {String((job.result as Record<string, unknown>)?.read ?? 0)} {t("篇")}
                </span>
                <Badge tone="brand">
                  花费 {formatCny(Number((job.result as Record<string, unknown>)?.cost_cny ?? 0))}
                </Badge>
              </div>
            )}
          </div>
        )}

        {/* 报告 */}
        {!data ? (
          <div className="flex justify-center py-16">
            <Spinner />
          </div>
        ) : report ? (
          <ReportView report={report} paperTitle={paperTitle} onOpenPaper={setOpenPaper} />
        ) : (
          <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-14 text-center">
            <Radar size={22} className="mx-auto text-ink-300" />
            <div className="mt-2 text-[13px] font-medium text-ink-700">{t("还没扫描过")}</div>
            <div className="mt-1 text-[12.5px] text-ink-400">
              {t("打开开关 → 选一个时间窗 → 点「扫描这段时间」")}
            </div>
          </div>
        )}

        {/* 历史 */}
        {!!data?.runs.length && (
          <div className="rounded-xl border border-line bg-surface">
            <div className="flex items-center gap-1.5 border-b border-line px-4 py-2.5 text-[12.5px] font-medium text-ink-700">
              <History size={13} className="text-ink-400" /> {t("扫描记录")}
            </div>
            <div className="divide-y divide-line">
              {data.runs.map((r) => (
                <div key={r.id} className="flex items-center gap-3 px-4 py-2 text-[11.5px]">
                  <span className="font-mono text-ink-500">
                    {r.window_start} ~ {r.window_end}
                  </span>
                  <Badge
                    tone={
                      r.status === "done" ? "green" : r.status === "failed" ? "red" : "neutral"
                    }
                  >
                    {r.status === "done" ? t("完成") : r.status === "failed" ? t("失败") : t("进行中")}
                  </Badge>
                  {r.status === "done" && (
                    <span className="text-ink-500">
                      新增 {r.items_new ?? 0} · 精读 {r.items_read ?? 0}
                    </span>
                  )}
                  <span className="ml-auto text-ink-400">{formatCny(r.cost_cny)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </PageBody>

      <PaperInsightDrawer paperId={openPaper} onClose={() => setOpenPaper(null)} />
    </div>
  );
}
