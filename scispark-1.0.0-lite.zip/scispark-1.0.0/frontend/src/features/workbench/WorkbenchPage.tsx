import { Link, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  BookOpenCheck,
  GitBranch,
  Lightbulb,
  MessageSquareQuote,
  Radar,
  Route,
} from "lucide-react";
import { projectsApi } from "@/lib/api";
import { Badge, Spinner } from "@/components/ui/feedback";
import { Button } from "@/components/ui/button";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { pickName, t } from "@/lib/i18n";

const steps = [
  {
    icon: BookOpenCheck,
    title: t("1 · 调研与理解"),
    desc: t("输入研究主题，AI 从 arXiv 与 OpenAlex 检索论文，去重排序后逐篇抽取结构化理解：问题、方法、数据集、发现、局限、核心断言。"),
    status: t("可用"),
    to: "papers",
  },
  {
    icon: GitBranch,
    title: t("2 · 梳理逻辑与找 gap"),
    desc: t("构建引用 / 语义 / 概念三层图，用四种策略发现研究空白：局限聚类、矛盾检测、组合创新、迁移创新。"),
    status: t("可用"),
    to: "graph",
  },
  {
    icon: MessageSquareQuote,
    title: t("3 · 共创收敛"),
    desc: t("对话式推进：发散 → 落地证据 → 假设用例 → 收敛。每一步都长成问题树上的节点，AI 的思考全程可见、可质疑。"),
    status: t("可用"),
    to: "chat",
  },
  {
    icon: Radar,
    title: t("4 · 进展扫描"),
    desc: t("打开开关，选一个时间窗（近一周 / 一月 / 三月 / 自定义），扫描这段时间的新论文，出一份「这段时间发生了什么」的判断。"),
    status: t("可用"),
    to: "scan",
  },
];

export default function WorkbenchPage() {
  const { projectId = "" } = useParams();
  const { data: project, isLoading } = useQuery({
    queryKey: ["project", projectId],
    queryFn: () => projectsApi.get(projectId),
    enabled: !!projectId,
  });

  if (isLoading || !project) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner className="h-5 w-5" />
      </div>
    );
  }

  return (
    <div className="min-h-full">
      <PageHeader
        title={pickName(project.name, project.name_en)}
        desc={project.topic}
        actions={
          <Link to={`/p/${projectId}/papers`}>
            <Button variant="primary">
              <BookOpenCheck size={14} /> {t("开始调研")}
            </Button>
          </Link>
        }
      />

      <PageBody className="max-w-5xl space-y-5">
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: t("论文"), value: project.paper_count, icon: BookOpenCheck },
            { label: t("问题节点"), value: project.rq_count, icon: Route },
            { label: t("创新点"), value: project.idea_count, icon: Lightbulb },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-line bg-surface px-4 py-3.5">
              <div className="flex items-center gap-1.5 text-[11.5px] text-ink-400">
                <s.icon size={12} /> {s.label}
              </div>
              <div className="mt-1 font-mono text-[22px] font-semibold leading-none text-ink-900">
                {s.value}
              </div>
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-line bg-surface">
          <div className="border-b border-line px-5 py-3.5">
            <div className="text-[14px] font-semibold text-ink-900">{t("工作流")}</div>
            <div className="mt-0.5 text-[12.5px] text-ink-500">
              {t("四个阶段串成一条闭环，每一步的产出都是下一步的输入。")}
            </div>
          </div>
          <div className="divide-y divide-line">
            {steps.map((s) => (
              <div key={s.title} className="flex items-start gap-4 px-5 py-4">
                <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-canvas text-ink-500">
                  <s.icon size={15} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[13.5px] font-medium text-ink-900">{s.title}</span>
                    <Badge
                      tone={s.status === t("可用") ? "green" : s.status === t("开发中") ? "brand" : "neutral"}
                    >
                      {s.status}
                    </Badge>
                  </div>
                  <div className="mt-1 text-[12.5px] leading-relaxed text-ink-500">{s.desc}</div>
                </div>
                <Link
                  to={`/p/${projectId}${s.to ? `/${s.to}` : ""}`}
                  className="mt-1 shrink-0 text-ink-400 transition-colors hover:text-brand-600"
                >
                  <ArrowRight size={15} />
                </Link>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-dashed border-line bg-canvas/50 px-5 py-4 text-[12.5px] leading-relaxed text-ink-500">
          <span className="font-medium text-ink-700">{t("四个阶段全部打通。")}</span>{" "}
          {t("建议路径：论文库拉一批论文 → 图谱挖空白 → 拿空白去共创对话里收敛成研究问题 → 在「创新点」里两两对比排个高下 → 生成提案。平时用「进展扫描」盯新论文。")}
        </div>
      </PageBody>
    </div>
  );
}
