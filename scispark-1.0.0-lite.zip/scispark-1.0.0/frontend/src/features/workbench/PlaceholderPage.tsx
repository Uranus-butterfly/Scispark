import { useParams } from "react-router-dom";
import { Construction } from "lucide-react";
import { EmptyState } from "@/components/ui/feedback";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { t } from "@/lib/i18n";

const COPY: Record<string, { title: string; desc: string }> = {
  papers: {
    title: t("论文库"),
    desc: t("检索、去重、排序后的论文会出现在这里，每篇带一张中文结构化卡片。"),
  },
  graph: {
    title: t("论文图谱"),
    desc: t("引用层、语义层、概念层三张图叠加，用来发现研究空白。"),
  },
  scan: {
    title: t("进展扫描"),
    desc: t("指定时间窗，一次性回溯调研这段时间的研究进展。"),
  },
};

export default function PlaceholderPage({ kind }: { kind: "papers" | "graph" | "scan" }) {
  const { projectId } = useParams();
  const c = COPY[kind];
  return (
    <div className="min-h-full">
      <PageHeader title={c.title} desc={c.desc} />
      <PageBody>
        <EmptyState
          icon={<Construction size={22} />}
          title={t("这个模块还没开放")}
          desc={`${t("项目")} ${projectId?.slice(0, 8) ?? ""} · ${c.title} ${t("将在后续阶段接入。")}`}
        />
      </PageBody>
    </div>
  );
}
