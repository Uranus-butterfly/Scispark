import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle2,
  Compass,
  Lightbulb,
  Loader2,
  Network,
  RefreshCw,
  TriangleAlert,
} from "lucide-react";
import { graphApi, type GapItem, type GraphLayer } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge, Spinner } from "@/components/ui/feedback";
import { Progress } from "@/components/ui/progress";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { useJob } from "@/hooks/useJob";
import { cn, formatCny } from "@/lib/utils";
import { PaperInsightDrawer } from "@/features/papers/PaperInsightDrawer";
import { GraphCanvas } from "./GraphCanvas";
import { GapPanel } from "./GapPanel";
import { t } from "@/lib/i18n";

type Tab = "graph" | "gaps";

const LAYERS: { key: GraphLayer; label: string; hint: string }[] = [
  { key: "cites", label: t("直接引用"), hint: t("A 的参考文献里有 B") },
  { key: "coupling", label: t("引用耦合"), hint: t("共同引用同一批工作，说明在同一条技术脉络上") },
  { key: "similar", label: t("语义相近"), hint: t("标题 + 摘要 + 结构化理解的 TF-IDF 余弦") },
  { key: "same_concept", label: t("共享概念"), hint: t("结构化抽取出的概念重叠（按 IDF 加权）") },
];

export default function GraphPage() {
  const { projectId = "" } = useParams();
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>("graph");
  const [layers, setLayers] = useState<GraphLayer[]>(LAYERS.map((l) => l.key));
  const [selected, setSelected] = useState<string | null>(null);
  const [openPaper, setOpenPaper] = useState<string | null>(null);
  const [jobId, setJobId] = useState<string | null>(null);

  const { data: graph, isLoading } = useQuery({
    queryKey: ["graph", projectId, layers],
    queryFn: () => graphApi.get(projectId, layers),
    enabled: !!projectId,
  });
  const { data: gaps } = useQuery({
    queryKey: ["gaps", projectId],
    queryFn: () => graphApi.gaps(projectId),
    enabled: !!projectId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["graph", projectId] });
    qc.invalidateQueries({ queryKey: ["gaps", projectId] });
    qc.invalidateQueries({ queryKey: ["cost"] });
  };
  const { job } = useJob(jobId, () => refresh());

  const build = useMutation({
    mutationFn: () => graphApi.build(projectId, layers),
    onSuccess: (r) => setJobId(r.job_id),
  });
  const mine = useMutation({
    mutationFn: () => graphApi.mineGaps(projectId),
    onSuccess: (r) => {
      setJobId(r.job_id);
      setTab("gaps");
    },
  });
  const removeGap = useMutation({
    mutationFn: (id: string) => graphApi.deleteGap(projectId, id),
    onSuccess: refresh,
  });

  const titles = useMemo(() => {
    const m = new Map<string, string>();
    for (const n of graph?.nodes ?? []) m.set(n.id, n.title);
    return m;
  }, [graph]);

  const node = graph?.nodes.find((n) => n.id === selected) ?? null;
  const running = job?.status === "running" || job?.status === "queued";
  const hasGraph = (graph?.edges.length ?? 0) > 0;

  return (
    <div className="min-h-full">
      <PageHeader
        title={t("论文图谱")}
        desc={t("把论文库连成一张图，再从连接方式里找「没人做过的地方」")}
        actions={
          <>
            <Button
              disabled={running}
              loading={build.isPending}
              onClick={() => build.mutate()}
              title={t("重新计算三层关系（不花 LLM 费用）")}
            >
              <RefreshCw size={14} /> {hasGraph ? t("重建图谱") : t("构建图谱")}
            </Button>
            <Button
              variant="primary"
              disabled={running || !hasGraph}
              loading={mine.isPending}
              onClick={() => mine.mutate()}
              title={hasGraph ? t("从图谱里挖研究空白") : t("先构建图谱")}
            >
              <Lightbulb size={14} /> {t("挖空白")}
            </Button>
          </>
        }
      />

      <PageBody className="max-w-6xl space-y-4">
        {/* 统计 */}
        {graph && (
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-ink-500">
            <span className="flex items-center gap-1">
              <Network size={12} /> {graph.stats.papers} {t("篇论文")}
            </span>
            <span>{graph.stats.edges} {t("条连线")}</span>
            <span className={graph.stats.isolated > graph.stats.papers / 3 ? "text-amber-600" : ""}>
              {graph.stats.isolated} {t("篇孤立")}
            </span>
            {graph.stats.built_at && <span>构建于 {graph.stats.built_at}</span>}
          </div>
        )}

        {/* 任务进度 */}
        {(running || job?.status === "failed" || job?.status === "done") && (
          <div
            className={cn(
              "rounded-xl border px-4 py-3",
              job?.status === "failed" ? "border-red-100 bg-red-50" : "border-line bg-surface",
            )}
          >
            {running && (
              <>
                <div className="flex items-center justify-between text-[12.5px]">
                  <span className="flex items-center gap-1.5 text-ink-700">
                    <Loader2 size={13} className="animate-spin" />
                    {job?.step || t("处理中…")}
                  </span>
                  <span className="font-mono text-ink-500">
                    {Math.round((job?.progress ?? 0) * 100)}%
                  </span>
                </div>
                <Progress className="mt-2" value={job?.progress ?? 0} />
              </>
            )}
            {job?.status === "failed" && (
              <div className="flex items-start gap-2 text-[12.5px] text-red-700">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <div className="font-medium">{t("失败")}</div>
                  <div className="mt-0.5 whitespace-pre-wrap break-words text-[11.5px] text-red-600/90">
                    {(job.error || "").split("\n")[0]}
                  </div>
                </div>
              </div>
            )}
            {job?.status === "done" && (
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-ink-600">
                <span className="flex items-center gap-1 font-medium text-emerald-700">
                  <CheckCircle2 size={13} /> {t("完成")}
                </span>
                {job.type === "graph_build" && (
                  <span>
                    {String((job.result as Record<string, unknown>)?.nodes ?? 0)} {t("个节点 ·")}{" "}
                    {String((job.result as Record<string, unknown>)?.edges ?? 0)} {t("条边")}
                  </span>
                )}
                {job.type === "gap_mine" && (
                  <span>
                    挖出 {String((job.result as Record<string, unknown>)?.gaps ?? 0)} {t("条，其中真空白")}{" "}
                    {String((job.result as Record<string, unknown>)?.real_gap ?? 0)} {t("条")}
                  </span>
                )}
                <Badge tone="brand">
                  花费 {formatCny(Number((job.result as Record<string, unknown>)?.cost_cny ?? 0))}
                </Badge>
              </div>
            )}
          </div>
        )}

        {/* Tabs */}
        <div className="flex items-center gap-1 border-b border-line">
          {(
            [
              { key: "graph" as Tab, label: t("关系图"), icon: Network, count: graph?.stats.edges ?? 0 },
              { key: "gaps" as Tab, label: t("研究空白"), icon: Lightbulb, count: gaps?.length ?? 0 },
            ]
          ).map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "flex items-center gap-1.5 border-b-2 px-3 py-2 text-[13px] transition-colors",
                tab === t.key
                  ? "border-brand-600 font-medium text-brand-700"
                  : "border-transparent text-ink-500 hover:text-ink-900",
              )}
            >
              <t.icon size={13} />
              {t.label}
              {t.count ? <span className="font-mono text-[11px] text-ink-400">{t.count}</span> : null}
            </button>
          ))}
        </div>

        {tab === "graph" ? (
          isLoading ? (
            <div className="flex justify-center py-16">
              <Spinner />
            </div>
          ) : !hasGraph ? (
            <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-14 text-center">
              <Network size={22} className="mx-auto text-ink-300" />
              <div className="mt-2 text-[13px] font-medium text-ink-700">{t("还没有图谱")}</div>
              <div className="mt-1 text-[12.5px] text-ink-400">
                {t("点右上角「构建图谱」。三层关系全部本地计算，不花 API 费用。")}
              </div>
            </div>
          ) : (
            <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
              <div className="space-y-2">
                <GraphCanvas data={graph!} selectedId={selected} onSelect={setSelected} />
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11.5px] text-ink-400">{t("显示：")}</span>
                  {LAYERS.map((l) => {
                    const on = layers.includes(l.key);
                    const n = graph?.stats.raw_by_rel?.[l.key] ?? 0;
                    return (
                      <button
                        key={l.key}
                        title={l.hint}
                        onClick={() =>
                          setLayers((cur) =>
                            cur.includes(l.key)
                              ? cur.filter((x) => x !== l.key)
                              : [...cur, l.key],
                          )
                        }
                        className={cn(
                          "rounded-md border px-2 py-0.5 text-[11.5px] transition-colors",
                          on
                            ? "border-brand-200 bg-brand-50 text-brand-700"
                            : "border-line text-ink-400 hover:bg-canvas",
                        )}
                      >
                        {l.label}
                        <span className="ml-1 font-mono text-[10px] opacity-60">{n}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 选中节点详情 */}
              <div className="rounded-xl border border-line bg-surface p-3.5">
                {node ? (
                  <div className="space-y-2">
                    <div className="text-[13px] font-semibold leading-snug text-ink-900">
                      {node.title}
                    </div>
                    <div className="flex flex-wrap items-center gap-2 text-[11.5px] text-ink-500">
                      {node.year && <span>{node.year}</span>}
                      <span>{node.source}</span>
                      <span>被引 {node.citations}</span>
                      <span>连边 {node.degree}</span>
                    </div>
                    {node.problem && (
                      <div className="rounded-lg bg-canvas px-2.5 py-2 text-[11.5px] leading-relaxed text-ink-600">
                        {node.problem}
                      </div>
                    )}
                    {!!node.concepts.length && (
                      <div className="flex flex-wrap gap-1">
                        {node.concepts.map((c) => (
                          <span
                            key={c}
                            className="rounded bg-brand-50 px-1.5 py-0.5 text-[10.5px] text-brand-700"
                          >
                            {c}
                          </span>
                        ))}
                      </div>
                    )}
                    <Button size="sm" onClick={() => setOpenPaper(node.id)}>
                      {t("打开论文详情")}
                    </Button>
                  </div>
                ) : (
                  <div className="py-8 text-center text-[12px] leading-relaxed text-ink-400">
                    <Compass size={18} className="mx-auto mb-2 text-ink-300" />
                    {t("点一个节点看详情")}
                    <br />
                    {t("拖拽平移 · 滚轮缩放")}
                  </div>
                )}
              </div>
            </div>
          )
        ) : (
          <GapPanel
            gaps={(gaps ?? []) as GapItem[]}
            titles={titles}
            onDelete={(id) => removeGap.mutate(id)}
            onOpenPaper={(pid) => setOpenPaper(pid)}
          />
        )}
      </PageBody>

      <PaperInsightDrawer paperId={openPaper} onClose={() => setOpenPaper(null)} />
    </div>
  );
}
