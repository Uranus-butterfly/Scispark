import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Maximize2, Minus, Plus, Search, ZoomIn } from "lucide-react";
import type { GraphData, GraphNode, GraphLayer } from "@/lib/api";
import { cn } from "@/lib/utils";
import { forceLayout } from "./layout";
import { t } from "@/lib/i18n";

const LAYER_META: Record<GraphLayer, { label: string; color: string; width: number; dash?: string }> = {
  cites: { label: t("直接引用"), color: "#f59e0b", width: 1.8 },
  coupling: { label: t("引用耦合"), color: "#8b5cf6", width: 1.4 },
  similar: { label: t("语义相近"), color: "#cbd5e1", width: 1 },
  same_concept: { label: t("共享概念"), color: "#10b981", width: 1.2, dash: "3 3" },
};

const SOURCE_COLOR: Record<string, string> = {
  arxiv: "#6366f1",
  openalex: "#0ea5e9",
  local: "#10b981",
  s2: "#f97316",
};

const W = 900;
const H = 560;
const MIN_K = 0.5;
const MAX_K = 6;
const MAG = 1.8; // 放大镜倍数（再大就只能看见一个点了，反而看不出上下文）
const LENS_R = 104;

export function GraphCanvas({
  data,
  selectedId,
  onSelect,
}: {
  data: GraphData;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
}) {
  const [hover, setHover] = useState<string | null>(null);
  const [view, setView] = useState({ k: 1, x: 0, y: 0 });
  const [lens, setLens] = useState<{ x: number; y: number } | null>(null);
  const [lensOn, setLensOn] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ x: number; y: number; vx: number; vy: number; moved: boolean } | null>(null);

  const pos = useMemo(
    () =>
      forceLayout(
        data.nodes.map((n) => ({ id: n.id, weight: n.degree })),
        data.edges.map((e) => ({ source: e.source, target: e.target })),
        { width: W, height: H },
      ),
    [data.nodes, data.edges],
  );

  const focus = hover ?? selectedId;
  const neighbors = useMemo(() => {
    if (!focus) return null;
    const s = new Set<string>([focus]);
    for (const e of data.edges) {
      if (e.source === focus) s.add(e.target);
      if (e.target === focus) s.add(e.source);
    }
    return s;
  }, [focus, data.edges]);

  const radius = (n: GraphNode) => Math.min(16, 5 + Math.sqrt(n.degree) * 2.4);

  // 只给度数最高的十几个节点常驻标签；放大到一定程度就全显示
  const labelled = useMemo(() => {
    const top = [...data.nodes].sort((a, b) => b.degree - a.degree).slice(0, 12);
    return new Set(top.filter((n) => n.degree > 0).map((n) => n.id));
  }, [data.nodes]);
  const showAllLabels = view.k >= 1.4;

  const isolated = useMemo(() => data.nodes.filter((n) => n.degree === 0), [data.nodes]);
  const bandH = isolated.length ? (isolated.length > 10 ? 74 : 48) : 0;

  /** 客户端坐标 → 画布坐标（viewBox 空间） */
  const toCanvas = useCallback((clientX: number, clientY: number) => {
    const rect = wrapRef.current?.getBoundingClientRect();
    if (!rect) return { x: 0, y: 0 };
    return {
      x: ((clientX - rect.left) / rect.width) * W,
      y: ((clientY - rect.top) / rect.height) * H,
    };
  }, []);

  const zoomTo = useCallback((target: number, cx: number, cy: number) => {
    setView((v) => {
      const k = Math.max(MIN_K, Math.min(MAX_K, target));
      const ratio = k / v.k;
      return { k, x: cx - (cx - v.x) * ratio, y: cy - (cy - v.y) * ratio };
    });
  }, []);

  const zoomAt = useCallback(
    (factor: number, cx: number, cy: number) => {
      setView((v) => {
        const k = Math.max(MIN_K, Math.min(MAX_K, v.k * factor));
        const ratio = k / v.k;
        return { k, x: cx - (cx - v.x) * ratio, y: cy - (cy - v.y) * ratio };
      });
    },
    [],
  );

  // 百分比可以直接输入
  const [zoomText, setZoomText] = useState<string | null>(null);
  const applyZoomText = () => {
    if (zoomText === null) return;
    const n = parseFloat(zoomText.replace("%", "").trim());
    if (Number.isFinite(n) && n > 0) zoomTo(n / 100, W / 2, H / 2);
    setZoomText(null);
  };

  // 关键：用原生监听器 + passive:false 才能 preventDefault。
  // React 的 onWheel 是 passive 的，拦不住浏览器缩放——用户滚轮想放大图，
  // 结果整个页面被放大了，这就是之前的毛病。
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();
      const p = toCanvas(e.clientX, e.clientY);
      zoomAt(e.deltaY < 0 ? 1.12 : 0.89, p.x, p.y);
    };
    // 触控板双指缩放会带 ctrlKey，同样拦掉，避免浏览器整页缩放
    const onGesture = (e: Event) => e.preventDefault();

    el.addEventListener("wheel", onWheel, { passive: false });
    el.addEventListener("gesturestart", onGesture as EventListener);
    el.addEventListener("gesturechange", onGesture as EventListener);
    return () => {
      el.removeEventListener("wheel", onWheel);
      el.removeEventListener("gesturestart", onGesture as EventListener);
      el.removeEventListener("gesturechange", onGesture as EventListener);
    };
  }, [toCanvas, zoomAt]);

  const fit = () => {
    const pts = data.nodes.map((n) => pos.get(n.id)).filter(Boolean) as { x: number; y: number }[];
    if (!pts.length) return setView({ k: 1, x: 0, y: 0 });
    const minX = Math.min(...pts.map((p) => p.x));
    const maxX = Math.max(...pts.map((p) => p.x));
    const minY = Math.min(...pts.map((p) => p.y));
    const maxY = Math.max(...pts.map((p) => p.y));
    const pad = 40;
    const k = Math.max(
      MIN_K,
      Math.min(MAX_K, Math.min((W - pad * 2) / (maxX - minX || 1), (H - pad * 2) / (maxY - minY || 1))),
    );
    setView({
      k,
      x: W / 2 - ((minX + maxX) / 2) * k,
      y: H / 2 - ((minY + maxY) / 2) * k,
    });
  };

  /** 图内容（画两遍：主视图 + 放大镜） */
  const content = (interactive: boolean, forceLabels = false) => (
    <>
      {bandH > 0 && (
        <g>
          <line x1={20} y1={H - bandH} x2={W - 20} y2={H - bandH} stroke="#e6e8ec" strokeDasharray="4 4" />
          <text x={24} y={H - bandH + 13} style={{ fontSize: 9, fill: "#94a3b8" }}>
            未连入任何脉络（{isolated.length} {t("篇）")}
          </text>
        </g>
      )}

      {data.edges.map((e) => {
        const a = pos.get(e.source);
        const b = pos.get(e.target);
        if (!a || !b) return null;
        const meta = LAYER_META[e.rel] ?? LAYER_META.similar;
        const dim = neighbors ? !(neighbors.has(e.source) && neighbors.has(e.target)) : false;
        const active = focus ? e.source === focus || e.target === focus : false;
        return (
          <line
            key={`${e.source}-${e.target}-${e.rel}`}
            x1={a.x}
            y1={a.y}
            x2={b.x}
            y2={b.y}
            stroke={meta.color}
            strokeWidth={active ? meta.width * 1.9 : meta.width}
            strokeDasharray={meta.dash}
            strokeOpacity={dim ? 0.12 : active ? 0.95 : 0.6}
          />
        );
      })}

      {data.nodes.map((n) => {
        const p = pos.get(n.id);
        if (!p) return null;
        const r = radius(n);
        const dim = neighbors ? !neighbors.has(n.id) : false;
        const isSel = selectedId === n.id;
        return (
          <g
            key={n.id}
            transform={`translate(${p.x},${p.y})`}
            opacity={dim ? 0.25 : 1}
            onMouseEnter={interactive ? () => setHover(n.id) : undefined}
            onMouseLeave={interactive ? () => setHover(null) : undefined}
            onClick={
              interactive
                ? (ev) => {
                    ev.stopPropagation();
                    if (drag.current?.moved) return;
                    onSelect(isSel ? null : n.id);
                  }
                : undefined
            }
            style={{ cursor: interactive ? "pointer" : "default" }}
          >
            {isSel && <circle r={r + 5} fill="none" stroke="#4f46e5" strokeWidth={1.5} />}
            <circle r={r} fill={SOURCE_COLOR[n.source] ?? "#94a3b8"} fillOpacity={0.9} stroke="#fff" strokeWidth={1.2} />
            {(forceLabels || labelled.has(n.id) || showAllLabels || isSel || hover === n.id) && (
              <text
                y={r + 11}
                textAnchor="middle"
                className="pointer-events-none"
                style={{ fontSize: 9, fill: "#334155" }}
              >
                {n.title.length > 34 ? `${n.title.slice(0, 33)}…` : n.title}
              </text>
            )}
            <title>
              {n.title}
              {`\n${n.year || "—"} · ${n.source} ${t("· 被引")} ${n.citations} ${t("· 连边")} ${n.degree}`}
            </title>
          </g>
        );
      })}
    </>
  );

  // 拖拽 / 缩放的手势只挂在 svg 上：之前挂在整层容器上，
  // setPointerCapture 会把后续的 click 也劫持到容器，导致工具条按钮点不动。
  const gesture = {
    onPointerDown: (e: React.PointerEvent<SVGSVGElement>) => {
      drag.current = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y, moved: false };
      (e.currentTarget as Element).setPointerCapture?.(e.pointerId);
    },
    onPointerMove: (e: React.PointerEvent<SVGSVGElement>) => {
      const d = drag.current;
      if (d) {
        const rect = e.currentTarget.getBoundingClientRect();
        const dx = ((e.clientX - d.x) / rect.width) * W;
        const dy = ((e.clientY - d.y) / rect.height) * H;
        if (Math.abs(dx) > 2 || Math.abs(dy) > 2) d.moved = true;
        setView((v) => ({ ...v, x: d.vx + dx, y: d.vy + dy }));
        setLens(null);
        return;
      }
      if (lensOn) setLens(toCanvas(e.clientX, e.clientY));
    },
    onPointerUp: () => {
      // 延迟清空，避免随后的 click 又把节点选中了
      setTimeout(() => {
        drag.current = null;
      }, 0);
    },
    onPointerLeave: () => {
      drag.current = null;
      setHover(null);
      setLens(null);
    },
    onMouseMove: (e: React.MouseEvent<SVGSVGElement>) => {
      if (drag.current) return;
      if (lensOn) setLens(toCanvas(e.clientX, e.clientY));
    },
  };

  return (
    <div
      ref={wrapRef}
      className="relative overflow-hidden rounded-xl border border-line bg-surface"
      style={{ touchAction: "none", overscrollBehavior: "contain" }}
    >
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="block w-full cursor-grab active:cursor-grabbing"
        style={{ aspectRatio: `${W} / ${H}` }}
        {...gesture}
        onClick={(e) => {
          // 点空白处取消选中（点节点时事件目标不是 svg 本身）
          if (e.target === e.currentTarget) onSelect(null);
        }}
        onDoubleClick={(e) => {
          if (e.target === e.currentTarget) zoomAt(1.6, W / 2, H / 2);
        }}
      >
        <g transform={`translate(${view.x},${view.y}) scale(${view.k})`}>{content(true)}</g>

        {/* 放大镜：以光标为中心再放大一次，画的是同一份内容 */}
        {lens && (
          <g pointerEvents="none">
            <defs>
              <clipPath id="mm-lens">
                <circle cx={lens.x} cy={lens.y} r={LENS_R} />
              </clipPath>
            </defs>
            <circle cx={lens.x} cy={lens.y} r={LENS_R} fill="#ffffff" />
            <g clipPath="url(#mm-lens)">
              <g transform={`translate(${lens.x},${lens.y}) scale(${MAG}) translate(${-lens.x},${-lens.y})`}>
                <g transform={`translate(${view.x},${view.y}) scale(${view.k})`}>{content(false, true)}</g>
              </g>
            </g>
            <circle cx={lens.x} cy={lens.y} r={LENS_R} fill="none" stroke="#4f46e5" strokeWidth={2} />
            <circle cx={lens.x} cy={lens.y} r={2} fill="#4f46e5" />
          </g>
        )}
      </svg>

      {/* 图例：放左上角，避开底部的「孤立论文」带 */}
      <div className="pointer-events-none absolute left-3 top-2 flex max-w-[calc(100%-260px)] flex-wrap items-center gap-x-3 gap-y-1 rounded-md bg-surface/85 px-1.5 py-1 text-[10.5px] text-ink-500">
        {(Object.keys(LAYER_META) as GraphLayer[]).map((k) => (
          <span key={k} className="flex items-center gap-1">
            <span className="inline-block h-[2px] w-4 rounded" style={{ background: LAYER_META[k].color }} />
            {LAYER_META[k].label}
          </span>
        ))}
        <span className="ml-1 flex items-center gap-1">
          <span className="inline-block h-2 w-2 rounded-full bg-brand-500" /> arXiv
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block h-2 w-2 rounded-full bg-sky-500" /> OpenAlex
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block h-2 w-2 rounded-full bg-emerald-500" /> {t("本地")}
        </span>
      </div>

      {/* 缩放工具条 */}
      <div className="absolute right-3 top-2 flex items-center gap-1 rounded-lg border border-line bg-surface/95 p-0.5 shadow-sm">
        <button
          onClick={() => setLensOn((v) => !v)}
          className={cn(
            "flex items-center gap-1 rounded px-1.5 py-1 text-[11px] transition-colors",
            lensOn ? "bg-brand-50 text-brand-700" : "text-ink-500 hover:bg-canvas",
          )}
          title={t("放大镜：鼠标移到图上，局部放大（不改变整体视图）")}
        >
          {lensOn ? <ZoomIn size={13} /> : <Search size={13} />}
          放大镜
        </button>
        <span className="mx-0.5 h-4 w-px bg-line" />
        <button
          onClick={() => zoomAt(0.8, W / 2, H / 2)}
          className="rounded p-1 text-ink-500 hover:bg-canvas"
          title={t("缩小")}
        >
          <Minus size={13} />
        </button>
        <input
          value={zoomText ?? `${Math.round(view.k * 100)}%`}
          onChange={(e) => setZoomText(e.target.value)}
          onFocus={(e) => {
            setZoomText(String(Math.round(view.k * 100)));
            e.currentTarget.select();
          }}
          onBlur={applyZoomText}
          onKeyDown={(e) => {
            if (e.key === "Enter") (e.currentTarget as HTMLInputElement).blur();
            if (e.key === "Escape") setZoomText(null);
          }}
          title={t("可以直接输入缩放比例，回车生效")}
          className="w-11 rounded border border-transparent bg-transparent text-center font-mono text-[10.5px] text-ink-600 outline-none hover:border-line focus:border-brand-300 focus:bg-white"
        />
        <button
          onClick={() => zoomAt(1.25, W / 2, H / 2)}
          className="rounded p-1 text-ink-500 hover:bg-canvas"
          title={t("放大")}
        >
          <Plus size={13} />
        </button>
        <button
          onClick={fit}
          className="rounded p-1 text-ink-500 hover:bg-canvas"
          title={t("适应窗口")}
        >
          <Maximize2 size={12} />
        </button>
      </div>
    </div>
  );
}
