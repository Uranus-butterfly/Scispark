/**
 * 力导向布局（Fruchterman–Reingold 简化版）+ 孤立节点单独排布。
 *
 * 为什么不引第三方库：只有几十到几百个节点，O(n²) 的斥力迭代足够快，
 * 而且布局结果要可复现——同一个图每次打开位置一致，用户才不会迷路。
 * 所以随机数用固定种子，初始位置按索引放在圆周上。
 *
 * 为什么孤立节点不参与力模拟：它们之间只有斥力、没有引力，会一路被推到
 * 画布外圈，把有边的部分挤成一个小点（试过，很难看）。这里改成
 * 「只对连通部分做力模拟，孤立论文在底部排成一条带」，语义也更清楚：
 * 这些是还没连进任何脉络的论文。
 */

export interface LayoutInput {
  id: string;
  /** 节点权重（度） */
  weight: number;
}

export interface LayoutEdge {
  source: string;
  target: string;
}

export interface Point {
  x: number;
  y: number;
}

/** 固定种子的伪随机，保证布局可复现 */
function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function simulate(
  nodes: LayoutInput[],
  edges: [number, number][],
  box: { x: number; y: number; w: number; h: number },
  iterations: number,
  rand: () => number,
): Point[] {
  const n = nodes.length;
  const pos: Point[] = new Array(n);
  const cx = box.x + box.w / 2;
  const cy = box.y + box.h / 2;

  nodes.forEach((_, i) => {
    const a = (i / Math.max(1, n)) * Math.PI * 2 + rand() * 0.5;
    const r = Math.min(box.w, box.h) * (0.12 + rand() * 0.2);
    pos[i] = { x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r };
  });

  if (n < 2) return pos;

  const k = Math.sqrt((box.w * box.h) / n);
  const maxR = Math.min(box.w, box.h) * 0.46;
  const disp: Point[] = new Array(n);

  for (let it = 0; it < iterations; it++) {
    const temp = (Math.min(box.w, box.h) / 8) * (1 - it / iterations) + 0.5;
    for (let i = 0; i < n; i++) disp[i] = { x: 0, y: 0 };

    // 斥力
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        let dx = pos[i].x - pos[j].x;
        let dy = pos[i].y - pos[j].y;
        let d2 = dx * dx + dy * dy;
        if (d2 < 1e-4) {
          dx = (rand() - 0.5) * 2;
          dy = (rand() - 0.5) * 2;
          d2 = 1;
        }
        const d = Math.sqrt(d2);
        const f = (k * k) / d;
        const ux = (dx / d) * f;
        const uy = (dy / d) * f;
        disp[i].x += ux;
        disp[i].y += uy;
        disp[j].x -= ux;
        disp[j].y -= uy;
      }
    }

    // 引力（沿边）
    for (const [a, b] of edges) {
      const dx = pos[a].x - pos[b].x;
      const dy = pos[a].y - pos[b].y;
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      const f = (d * d) / k;
      const ux = (dx / d) * f;
      const uy = (dy / d) * f;
      disp[a].x -= ux;
      disp[a].y -= uy;
      disp[b].x += ux;
      disp[b].y += uy;
    }

    // 不加向心力：连通图里斥力和引力本身就会达到平衡（单边节点稳定在
    // k·n^(1/3) 附近），加了向心力反而会把主体压成一小坨。
    // 孤立节点已经被排除在模拟之外，不存在「无限飞散」的问题。

    for (let i = 0; i < n; i++) {
      const d = Math.sqrt(disp[i].x ** 2 + disp[i].y ** 2) || 1;
      const step = Math.min(d, temp) / d;
      pos[i].x += disp[i].x * step;
      pos[i].y += disp[i].y * step;

      // 圆形软边界：互不相连的连通块之间只有斥力，会一路漂到很远，
      // 把整体包围盒撑大、主体被压成一小坨。限制最大半径即可，
      // 用圆形而不是方形是为了避免节点被压到边缘排成一条直线。
      const rx = pos[i].x - cx;
      const ry = pos[i].y - cy;
      const r = Math.sqrt(rx * rx + ry * ry);
      if (r > maxR) {
        pos[i].x = cx + (rx / r) * maxR;
        pos[i].y = cy + (ry / r) * maxR;
      }
    }
  }
  return pos;
}

export function forceLayout(
  nodes: LayoutInput[],
  edges: LayoutEdge[],
  opts: { width?: number; height?: number; iterations?: number; seed?: number } = {},
): Map<string, Point> {
  const W = opts.width ?? 900;
  const H = opts.height ?? 560;
  const iterations = opts.iterations ?? 320;
  const rand = mulberry32(opts.seed ?? 42);
  const pad = 34;

  const degree = new Map<string, number>();
  for (const n of nodes) degree.set(n.id, 0);
  for (const e of edges) {
    if (degree.has(e.source)) degree.set(e.source, (degree.get(e.source) ?? 0) + 1);
    if (degree.has(e.target)) degree.set(e.target, (degree.get(e.target) ?? 0) + 1);
  }

  const connected = nodes.filter((n) => (degree.get(n.id) ?? 0) > 0);
  const isolated = nodes.filter((n) => (degree.get(n.id) ?? 0) === 0);

  const out = new Map<string, Point>();

  // 孤立论文在底部占一条带（一行或两行）
  const bandH = isolated.length ? (isolated.length > 10 ? 74 : 48) : 0;
  const mainH = H - bandH;

  if (connected.length) {
    const idx = new Map<string, number>();
    connected.forEach((n, i) => idx.set(n.id, i));
    const pairs = edges
      .map((e) => [idx.get(e.source), idx.get(e.target)] as const)
      .filter((p): p is readonly [number, number] => p[0] !== undefined && p[1] !== undefined)
      .map((p) => [p[0], p[1]] as [number, number]);

    const pos = simulate(
      connected,
      pairs,
      { x: pad, y: pad, w: W - pad * 2, h: mainH - pad * 2 },
      iterations,
      rand,
    );

    // 归一化到主区域，保证撑满而不是挤在中间
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    for (const p of pos) {
      minX = Math.min(minX, p.x);
      maxX = Math.max(maxX, p.x);
      minY = Math.min(minY, p.y);
      maxY = Math.max(maxY, p.y);
    }
    const spanX = maxX - minX || 1;
    const spanY = maxY - minY || 1;
    const scale = Math.min((W - pad * 2) / spanX, (mainH - pad * 2) / spanY);
    const offX = pad + ((W - pad * 2) - spanX * scale) / 2;
    const offY = pad + ((mainH - pad * 2) - spanY * scale) / 2;
    connected.forEach((n, i) => {
      out.set(n.id, {
        x: offX + (pos[i].x - minX) * scale,
        y: offY + (pos[i].y - minY) * scale,
      });
    });
  }

  if (isolated.length) {
    const perRow = Math.ceil(isolated.length / (bandH > 60 ? 2 : 1));
    const gap = (W - pad * 2) / perRow;
    isolated.forEach((n, i) => {
      const row = Math.floor(i / perRow);
      const col = i % perRow;
      out.set(n.id, {
        x: pad + gap * (col + 0.5),
        y: mainH + 18 + row * 34,
      });
    });
  }

  return out;
}
