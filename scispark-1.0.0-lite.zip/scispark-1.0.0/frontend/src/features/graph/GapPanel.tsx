import { useState } from "react";
import { ChevronDown, ChevronRight, Quote, Trash2, TriangleAlert } from "lucide-react";
import type { GapItem } from "@/lib/api";
import { Badge } from "@/components/ui/feedback";
import { cn } from "@/lib/utils";
import { t } from "@/lib/i18n";

const STRATEGY: Record<GapItem["strategy"], { label: string; hint: string; tone: "brand" | "violet" | "green" | "amber" }> = {
  limitation_cluster: {
    label: t("局限聚类"),
    hint: t("多篇论文反复提到同一类局限，且没人给出可行解法"),
    tone: "amber",
  },
  contradiction: {
    label: t("结论冲突"),
    hint: t("两篇论文的结论互相打架，没人解释为什么"),
    tone: "violet",
  },
  combination: {
    label: t("概念组合"),
    hint: t("两个各自成熟的方向，从未在同一篇工作里出现"),
    tone: "brand",
  },
  transfer: {
    label: t("方法迁移"),
    hint: t("把 A 论文的方法搬到 B 论文的问题上"),
    tone: "green",
  },
};

const VERDICT: Record<string, { label: string; cls: string }> = {
  real_gap: { label: t("真空白"), cls: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  weak: { label: t("证据不足"), cls: "bg-amber-50 text-amber-700 border-amber-200" },
  solved: { label: t("已有人做"), cls: "bg-slate-100 text-slate-500 border-slate-200" },
};

export function GapPanel({
  gaps,
  titles,
  onDelete,
  onOpenPaper,
}: {
  gaps: GapItem[];
  titles: Map<string, string>;
  onDelete: (id: string) => void;
  onOpenPaper: (paperId: string) => void;
}) {
  const [open, setOpen] = useState<Set<string>>(new Set());
  const [showSolved, setShowSolved] = useState(false);

  const toggle = (id: string) => {
    const next = new Set(open);
    next.has(id) ? next.delete(id) : next.add(id);
    setOpen(next);
  };

  if (!gaps.length) {
    return (
      <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-12 text-center">
        <div className="text-[13px] font-medium text-ink-700">{t("还没挖过研究空白")}</div>
        <div className="mt-1 text-[12.5px] text-ink-400">
          {t("点右上角「挖空白」：先从论文库里找候选信号，再让 AI 判断哪些是真的没被填上")}
        </div>
      </div>
    );
  }

  const visible = gaps.filter((g) => showSolved || g.verdict !== "solved");
  const hidden = gaps.length - visible.length;

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3 text-[11.5px] text-ink-500">
        <span>共 {gaps.length} {t("条")}</span>
        <span className="text-emerald-700">
          真空白 {gaps.filter((g) => g.verdict === "real_gap").length}
        </span>
        <span className="text-amber-600">
          证据不足 {gaps.filter((g) => g.verdict === "weak").length}
        </span>
        <span>{t("已有人做")} {gaps.filter((g) => g.verdict === "solved").length}</span>
        <button
          onClick={() => setShowSolved((v) => !v)}
          className="ml-auto rounded border border-line px-2 py-0.5 text-[11px] hover:bg-canvas"
        >
          {showSolved ? t("隐藏") : `${t("显示")}「${t("已有人做")}」${hidden ? `（${hidden}）` : ""}`}
        </button>
      </div>

      {visible.map((g) => {
        const meta = STRATEGY[g.strategy] ?? STRATEGY.combination;
        const v = VERDICT[g.verdict ?? "weak"] ?? VERDICT.weak;
        const expanded = open.has(g.id);
        return (
          <div key={g.id} className="rounded-xl border border-line bg-surface">
            <div className="flex items-start gap-2.5 px-4 py-3">
              <div className="mt-0.5 flex shrink-0 flex-col items-center gap-1">
                <span
                  className="flex h-8 w-8 items-center justify-center rounded-lg font-mono text-[11px] font-semibold"
                  style={{
                    background:
                      g.verdict === "real_gap"
                        ? "#ecfdf5"
                        : g.verdict === "solved"
                          ? "#f1f5f9"
                          : "#fffbeb",
                    color:
                      g.verdict === "real_gap"
                        ? "#047857"
                        : g.verdict === "solved"
                          ? "#64748b"
                          : "#b45309",
                  }}
                >
                  {Math.round((g.strength || 0) * 100)}
                </span>
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <Badge tone={meta.tone}>{meta.label}</Badge>
                  <span className={cn("rounded border px-1.5 py-0.5 text-[10.5px]", v.cls)}>
                    {v.label}
                  </span>
                  {g.paper_count > 0 && (
                    <span className="text-[10.5px] text-ink-400">{g.paper_count} {t("篇支撑")}</span>
                  )}
                </div>
                <div className="mt-1.5 text-[14px] font-semibold text-ink-900">{g.title}</div>
                <div className="mt-1 text-[12.5px] leading-relaxed text-ink-700">{g.statement}</div>

                {expanded && (
                  <div className="mt-2 space-y-2">
                    {g.detail && (
                      <div className="rounded-lg bg-canvas px-3 py-2 text-[12px] leading-relaxed text-ink-700">
                        {g.detail}
                      </div>
                    )}
                    {!!g.support.length && (
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-medium text-ink-500">{t("证据")}</div>
                        {g.support.map((s, i) => (
                          <div key={i} className="flex gap-1.5 text-[11.5px] text-ink-600">
                            <Quote size={11} className="mt-1 shrink-0 text-ink-300" />
                            <div className="min-w-0">
                              <button
                                onClick={() => s.paper_id && onOpenPaper(s.paper_id)}
                                className="truncate text-left text-brand-700 hover:underline"
                              >
                                {s.paper_id ? titles.get(s.paper_id) || t("（论文）") : t("（论文）")}
                              </button>
                              {s.note && <span className="ml-1 text-ink-400">· {s.note}</span>}
                              <div className="mt-0.5 line-clamp-3 text-ink-600">{s.quote}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex shrink-0 items-center gap-0.5">
                <button
                  onClick={() => toggle(g.id)}
                  className="rounded p-1.5 text-ink-400 hover:bg-canvas hover:text-ink-700"
                  title={expanded ? t("收起") : t("展开证据")}
                >
                  {expanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                </button>
                <button
                  onClick={() => onDelete(g.id)}
                  className="rounded p-1.5 text-ink-300 hover:bg-red-50 hover:text-red-600"
                  title={t("删除")}
                >
                  <Trash2 size={13} />
                </button>
              </div>
            </div>
          </div>
        );
      })}

      <div className="flex items-start gap-1.5 text-[11px] leading-relaxed text-ink-400">
        <TriangleAlert size={11} className="mt-0.5 shrink-0" />
        {t("空白是「机器挖 + AI 判」的结果，仍然会漏也会错。判断一条空白值不值得做，最终还得看你自己对领域的理解。")}
      </div>
    </div>
  );
}
