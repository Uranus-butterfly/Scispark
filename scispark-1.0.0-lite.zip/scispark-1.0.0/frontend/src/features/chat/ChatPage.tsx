import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowUp,
  BrainCircuit,
  Check,
  Copy,
  GitBranch,
  Loader2,
  MessageSquarePlus,
  Send,
  Sparkles,
  TriangleAlert,
} from "lucide-react";
import {
  chatApi,
  papersApi,
  type ChatMessage,
  type ChatState,
  type RqNode,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge, Spinner } from "@/components/ui/feedback";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { cn } from "@/lib/utils";
import { PaperInsightDrawer } from "@/features/papers/PaperInsightDrawer";
import { NodeDetail, RqTree, buildTree } from "./RqTree";
import { t } from "@/lib/i18n";

const STATE_META: Record<ChatState, { label: string; cls: string; hint: string }> = {
  diverging: {
    label: t("发散"),
    cls: "border-brand-200 bg-brand-50 text-brand-700",
    hint: t("先把可能性摊开，别急着收敛"),
  },
  narrowing: {
    label: t("收敛"),
    cls: "border-violet-200 bg-violet-50 text-violet-700",
    hint: t("用排除法砍掉不做的部分"),
  },
  converging: {
    label: t("定稿"),
    cls: "border-amber-200 bg-amber-50 text-amber-700",
    hint: t("确认数据、基线、评测能不能落地"),
  },
  done: {
    label: t("已定"),
    cls: "border-emerald-200 bg-emerald-50 text-emerald-700",
    hint: t("可以写 proposal 了"),
  },
};

function AssistantBubble({
  m,
  paperTitle,
  onOpenPaper,
  onPickSuggestion,
}: {
  m: ChatMessage;
  paperTitle: (id: string) => string;
  onOpenPaper: (id: string) => void;
  onPickSuggestion: (text: string) => void;
}) {
  const [showThoughts, setShowThoughts] = useState(false);
  const th = m.meta?.thoughts;
  const hasThoughts = !!(th?.text || th?.reasoning || th?.plan || th?.criticism);

  return (
    <div className="flex gap-2.5">
      <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-brand-500 to-violet-500 text-white">
        <Sparkles size={12} strokeWidth={2.2} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="whitespace-pre-wrap text-[13.5px] leading-[1.75] text-ink-800">
          {m.content}
        </div>

        {!!m.meta?.papers?.length && (
          <div className="mt-1.5 flex flex-wrap gap-1">
            {m.meta.papers.map((pid) => (
              <button
                key={pid}
                onClick={() => onOpenPaper(pid)}
                className="max-w-[260px] truncate rounded border border-line bg-canvas px-1.5 py-0.5 text-[10.5px] text-ink-600 hover:border-brand-200 hover:text-brand-700"
                title={paperTitle(pid)}
              >
                {paperTitle(pid)}
              </button>
            ))}
          </div>
        )}

        {hasThoughts && (
          <div className="mt-2">
            <button
              onClick={() => setShowThoughts((v) => !v)}
              className="flex items-center gap-1 text-[11px] text-ink-400 hover:text-brand-700"
            >
              <BrainCircuit size={11} />
              {showThoughts ? t("收起 AI 思考") : t("看 AI 当时在想什么")}
            </button>
            {showThoughts && (
              <div className="mt-1.5 space-y-1.5 rounded-lg border border-line bg-canvas px-2.5 py-2">
                {(
                  [
                    [t("在想什么"), th?.text],
                    [t("为什么"), th?.reasoning],
                    [t("打算怎么引导"), th?.plan],
                    [t("可能哪里不对"), th?.criticism],
                  ] as [string, string | undefined][]
                ).map(([label, value]) =>
                  value ? (
                    <div key={label}>
                      <div className="text-[10.5px] font-medium text-ink-400">{label}</div>
                      <div className="text-[11.5px] leading-relaxed text-ink-700">{value}</div>
                    </div>
                  ) : null,
                )}
              </div>
            )}
          </div>
        )}

        {!!m.meta?.suggestions?.length && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {m.meta.suggestions.map((s) => (
              <button
                key={s}
                onClick={() => onPickSuggestion(s)}
                className="rounded-full border border-line px-2 py-0.5 text-[11px] text-ink-500 hover:border-brand-200 hover:bg-brand-50 hover:text-brand-700"
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function ChatPage() {
  const { projectId = "" } = useParams();
  const qc = useQueryClient();
  const [draft, setDraft] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [openPaper, setOpenPaper] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: conv, isLoading } = useQuery({
    queryKey: ["chat", projectId],
    queryFn: () => chatApi.latest(projectId),
    enabled: !!projectId,
  });
  const { data: papers } = useQuery({
    queryKey: ["papers", projectId, "chat"],
    queryFn: () => papersApi.list(projectId, { limit: 300 }),
    enabled: !!projectId,
  });

  const titles = useMemo(() => {
    const m = new Map<string, string>();
    for (const p of papers?.items ?? []) m.set(p.id, p.title);
    return m;
  }, [papers]);
  const paperTitle = (id: string) => titles.get(id) || t("（论文）");

  const nodes: RqNode[] = conv?.tree ?? [];
  const focusNode = nodes.find((n) => n.id === selected) ?? null;

  // 新对话时默认选中根节点
  useEffect(() => {
    if (!selected && nodes.length) setSelected(nodes[0].id);
  }, [nodes, selected]);

  // 新消息滚到底
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [conv?.messages.length, pending]);

  const start = useMutation({
    mutationFn: () => chatApi.start(projectId),
    onMutate: () => {
      setPending(true);
      setError(null);
    },
    onSuccess: () => {
      setSelected(null);
      qc.invalidateQueries({ queryKey: ["chat", projectId] });
      qc.invalidateQueries({ queryKey: ["cost"] });
    },
    onError: (e) => setError((e as Error).message),
    onSettled: () => setPending(false),
  });

  const send = useMutation({
    mutationFn: (text: string) => chatApi.turn(projectId, conv!.id, text),
    onMutate: () => {
      setPending(true);
      setError(null);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["chat", projectId] });
      qc.invalidateQueries({ queryKey: ["cost"] });
    },
    onError: (e) => setError((e as Error).message),
    onSettled: () => setPending(false),
  });

  const submit = () => {
    const text = draft.trim();
    if (!text || pending || !conv) return;
    setDraft("");
    send.mutate(text);
  };

  const state = STATE_META[(conv?.state ?? "diverging") as ChatState];

  /** 把问题树导成 Markdown，方便贴进文档/交给别的工具 */
  const exportTree = async () => {
    if (!conv) return;
    const lines: string[] = [`# ${conv.title}`, "", `> ${t("阶段：")}${state.label}`, ""];
    const walk = (list: ReturnType<typeof buildTree>, depth: number) => {
      for (const b of list) {
        lines.push(`${"  ".repeat(depth)}- **${b.node.title}**`);
        if (b.node.body) lines.push(`${"  ".repeat(depth + 1)}${b.node.body}`);
        for (const pid of b.node.papers) {
          lines.push(`${"  ".repeat(depth + 1)}${t("- 证据：")}${paperTitle(pid)}`);
        }
        walk(b.children, depth + 1);
      }
    };
    walk(buildTree(nodes), 0);
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setError(t("复制失败，浏览器可能禁用了剪贴板权限"));
    }
  };

  return (
    <div className="flex h-full flex-col">
      <PageHeader
        title={t("共创对话")}
        desc={t("把模糊方向聊成一个能动手做的问题；右边这棵树是你走过的路")}
        actions={
          <>
            {conv && (
              <span className={cn("rounded-md border px-2 py-1 text-[11.5px]", state.cls)}>
                {state.label} · {state.hint}
              </span>
            )}
            {conv && nodes.length > 1 && (
              <Button size="sm" onClick={exportTree} title={t("把问题树复制成 Markdown")}>
                {copied ? <Check size={13} /> : <Copy size={13} />}
                {copied ? t("已复制") : t("导出")}
              </Button>
            )}
            <Button
              size="sm"
              disabled={pending}
              onClick={() => {
                if (conv && !window.confirm(t("重新开始会新建一段对话，旧的仍然保留在数据库里。继续？"))) return;
                start.mutate();
              }}
              loading={start.isPending}
            >
              <MessageSquarePlus size={13} /> {conv ? t("重新开始") : t("开始对话")}
            </Button>
          </>
        }
      />

      {!conv && !isLoading ? (
        <PageBody className="flex flex-1 items-center justify-center">
          <div className="max-w-md text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-violet-500 text-white shadow-sm">
              <GitBranch size={20} />
            </div>
            <div className="mt-3 text-[15px] font-semibold text-ink-900">{t("从一个方向开始")}</div>
            <div className="mt-1.5 text-[12.5px] leading-relaxed text-ink-500">
              {t("我会基于项目主题问你几个问题，边聊边把问题树长出来。")}
              <br />
              {t("树上每个节点都挂着「我为什么这么想」，你可以随时点开质疑我。")}
            </div>
            <Button
              variant="primary"
              className="mt-4"
              loading={start.isPending}
              onClick={() => start.mutate()}
            >
              <Sparkles size={14} /> {t("开始")}
            </Button>
            {error && (
              <div className="mt-3 flex items-start gap-1.5 text-left text-[11.5px] text-red-600">
                <TriangleAlert size={12} className="mt-0.5 shrink-0" />
                {error}
              </div>
            )}
          </div>
        </PageBody>
      ) : (
        <div className="flex min-h-0 flex-1">
          {/* 对话 */}
          <div className="flex min-w-0 flex-1 flex-col">
            <div ref={scrollRef} className="min-h-0 flex-1 space-y-5 overflow-y-auto px-7 py-5">
              {isLoading && (
                <div className="flex justify-center py-10">
                  <Spinner />
                </div>
              )}
              {conv?.messages.map((m) =>
                m.role === "user" ? (
                  <div key={m.id} className="flex justify-end">
                    <div className="max-w-[78%] whitespace-pre-wrap rounded-2xl rounded-br-md bg-brand-600 px-3.5 py-2 text-[13px] leading-relaxed text-white">
                      {m.content}
                    </div>
                  </div>
                ) : (
                  <AssistantBubble
                    key={m.id}
                    m={m}
                    paperTitle={paperTitle}
                    onOpenPaper={setOpenPaper}
                    onPickSuggestion={(s) => setDraft(s)}
                  />
                ),
              )}

              {pending && (
                <div className="flex items-center gap-2 text-[12.5px] text-ink-400">
                  <Loader2 size={13} className="animate-spin" /> {t("正在想…")}
                </div>
              )}

              {error && (
                <div className="flex items-start gap-1.5 rounded-lg border border-red-100 bg-red-50 px-3 py-2 text-[11.5px] text-red-700">
                  <TriangleAlert size={12} className="mt-0.5 shrink-0" />
                  <span className="min-w-0 break-words">{error}</span>
                </div>
              )}
            </div>

            {/* 输入 */}
            <div className="border-t border-line bg-surface px-5 py-3">
              <div className="flex items-end gap-2">
                <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      submit();
                    }
                  }}
                  rows={2}
                  disabled={pending || !conv}
                  placeholder={t("说说你的想法，或者直接说「我觉得这个不现实」…（Enter 发送，Shift+Enter 换行）")}
                  className="max-h-40 min-h-[52px] flex-1 resize-y rounded-lg border border-line bg-canvas px-3 py-2 text-[13px] leading-relaxed text-ink-800 outline-none placeholder:text-ink-400 focus:border-brand-300"
                />
                <Button
                  variant="primary"
                  className="h-[52px] w-[52px] px-0"
                  disabled={!draft.trim() || pending || !conv}
                  loading={pending}
                  onClick={submit}
                  title={t("发送")}
                >
                  <Send size={16} />
                </Button>
              </div>
              <div className="mt-1 flex items-center justify-between text-[10.5px] text-ink-400">
                <span>{t("每轮一次模型调用，约 ¥0.01~0.03")}</span>
                {conv && <span>本段对话已花 ¥{conv.cost_cny.toFixed(3)}</span>}
              </div>
            </div>
          </div>

          {/* 问题树 */}
          <aside className="flex w-[380px] shrink-0 flex-col border-l border-line bg-surface">
            <div className="flex items-center justify-between border-b border-line px-3 py-2">
              <span className="flex items-center gap-1.5 text-[12px] font-medium text-ink-700">
                <GitBranch size={13} className="text-brand-600" /> {t("问题树")}
              </span>
              <Badge tone="neutral">{nodes.length} {t("个节点")}</Badge>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto p-2">
              <RqTree nodes={nodes} selected={selected} onSelect={setSelected} />
            </div>
            <div className="flex h-[42%] flex-col border-t border-line">
              <div className="flex items-center gap-1.5 border-b border-line px-3 py-1.5 text-[11px] text-ink-500">
                <ArrowUp size={11} /> {t("节点详情")}
              </div>
              <div className="min-h-0 flex-1 overflow-y-auto">
                <NodeDetail node={focusNode} onOpenPaper={setOpenPaper} paperTitle={paperTitle} />
              </div>
            </div>
          </aside>
        </div>
      )}

      <PaperInsightDrawer paperId={openPaper} onClose={() => setOpenPaper(null)} />
    </div>
  );
}
