import { useMemo } from "react";
import { CornerDownRight } from "lucide-react";
import type { RqNode } from "@/lib/api";
import { cn } from "@/lib/utils";
import { t } from "@/lib/i18n";

const TYPE_META: Record<
  RqNode["node_type"],
  { label: string; dot: string; text: string; ring: string }
> = {
  rq: { label: t("问题"), dot: "bg-brand-500", text: "text-ink-900", ring: "ring-brand-400" },
  hypothesis: { label: t("假设"), dot: "bg-violet-500", text: "text-ink-900", ring: "ring-violet-400" },
  narrowing: { label: t("排除"), dot: "bg-slate-400", text: "text-ink-600", ring: "ring-slate-400" },
  use_case: { label: t("场景"), dot: "bg-sky-500", text: "text-ink-800", ring: "ring-sky-400" },
  idea: { label: t("做法"), dot: "bg-emerald-500", text: "text-ink-800", ring: "ring-emerald-400" },
};

interface Branch {
  node: RqNode;
  children: Branch[];
}

export function buildTree(nodes: RqNode[]): Branch[] {
  const byId = new Map<string, Branch>();
  for (const n of nodes) byId.set(n.id, { node: n, children: [] });
  const roots: Branch[] = [];
  for (const n of nodes) {
    const b = byId.get(n.id)!;
    const parent = n.parent_id ? byId.get(n.parent_id) : null;
    if (parent) parent.children.push(b);
    else roots.push(b);
  }
  // 同层按创建时间排，保证稳定
  const sort = (list: Branch[]) => {
    list.sort((a, b) => a.node.created_at.localeCompare(b.node.created_at));
    list.forEach((b) => sort(b.children));
  };
  sort(roots);
  return roots;
}

function NodeRow({
  branch,
  selected,
  onSelect,
  isRoot,
}: {
  branch: Branch;
  selected: string | null;
  onSelect: (id: string) => void;
  isRoot?: boolean;
}) {
  const { node, children } = branch;
  const meta = TYPE_META[node.node_type] ?? TYPE_META.rq;
  const active = selected === node.id;

  return (
    <li className="relative">
      <button
        onClick={() => onSelect(node.id)}
        className={cn(
          "group flex w-full items-start gap-1.5 rounded-lg px-2 py-1.5 text-left transition-colors",
          active ? "bg-brand-50 ring-1 " + meta.ring : "hover:bg-canvas",
        )}
      >
        <span
          className={cn(
            "mt-[6px] h-1.5 w-1.5 shrink-0 rounded-full",
            meta.dot,
            node.status === "pruned" && "opacity-30",
          )}
        />
        <span className="min-w-0 flex-1">
          <span
            className={cn(
              "block text-[12px] leading-snug",
              isRoot ? "font-semibold" : "font-medium",
              meta.text,
              node.status === "pruned" && "line-through opacity-60",
            )}
          >
            {node.title}
          </span>
          <span className="mt-0.5 flex items-center gap-1.5 text-[10px] text-ink-400">
            <span>{meta.label}</span>
            {node.author === "user" && <span>{t("· 你")}</span>}
            {node.papers.length > 0 && <span>· {node.papers.length} {t("篇")}</span>}
          </span>
        </span>
      </button>

      {children.length > 0 && (
        <ul className="ml-[7px] mt-0.5 space-y-0.5 border-l border-line pl-2.5">
          {children.map((c) => (
            <NodeRow key={c.node.id} branch={c} selected={selected} onSelect={onSelect} />
          ))}
        </ul>
      )}
    </li>
  );
}

export function RqTree({
  nodes,
  selected,
  onSelect,
}: {
  nodes: RqNode[];
  selected: string | null;
  onSelect: (id: string) => void;
}) {
  const branches = useMemo(() => buildTree(nodes), [nodes]);

  if (!branches.length) {
    return (
      <div className="px-3 py-8 text-center text-[12px] text-ink-400">
        {t("问题树还空着")}
        <br />
        {t("聊几句就会长出来")}
      </div>
    );
  }

  return (
    <ul className="space-y-1">
      {branches.map((b, i) => (
        <NodeRow
          key={b.node.id}
          branch={b}
          selected={selected}
          onSelect={onSelect}
          isRoot={i === 0 && b.node.depth === 0}
        />
      ))}
    </ul>
  );
}

export function NodeDetail({
  node,
  onOpenPaper,
  paperTitle,
}: {
  node: RqNode | null;
  onOpenPaper: (id: string) => void;
  paperTitle: (id: string) => string;
}) {
  if (!node) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-2 px-4 text-center">
        <CornerDownRight size={16} className="text-ink-300" />
        <div className="text-[12px] leading-relaxed text-ink-400">
          {t("点树上的节点")}
          <br />
          {t("看它为什么存在、挂着哪些证据")}
        </div>
      </div>
    );
  }

  const th = node.thoughts || {};
  const rows: [string, string | undefined][] = [
    [t("在想什么"), th.text],
    [t("为什么"), th.reasoning],
    [t("打算怎么引导"), th.plan],
    [t("可能哪里不对"), th.criticism],
  ];

  return (
    <div className="space-y-2.5 p-3">
      <div>
        <div className="text-[13px] font-semibold leading-snug text-ink-900">{node.title}</div>
        {node.body && (
          <div className="mt-1 text-[12px] leading-relaxed text-ink-600">{node.body}</div>
        )}
      </div>

      {rows.some(([, v]) => v) && (
        <div className="space-y-1.5 rounded-lg bg-canvas px-2.5 py-2">
          {rows.map(([label, value]) =>
            value ? (
              <div key={label}>
                <div className="text-[10.5px] font-medium text-ink-400">{label}</div>
                <div className="text-[11.5px] leading-relaxed text-ink-700">{value}</div>
              </div>
            ) : null,
          )}
        </div>
      )}

      {!!node.papers.length && (
        <div className="space-y-1">
          <div className="text-[10.5px] font-medium text-ink-400">{t("关联证据")}</div>
          {node.papers.map((pid) => (
            <button
              key={pid}
              onClick={() => onOpenPaper(pid)}
              className="block w-full truncate rounded px-1.5 py-1 text-left text-[11.5px] text-brand-700 hover:bg-brand-50"
              title={paperTitle(pid)}
            >
              {paperTitle(pid)}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
