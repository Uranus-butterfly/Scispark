import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle2,
  Copy,
  Download,
  FileText,
  Loader2,
  Swords,
  TriangleAlert,
  Trophy,
} from "lucide-react";
import { ideasApi, type IdeaDetail, type IdeaRow } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge, Spinner } from "@/components/ui/feedback";
import { Progress } from "@/components/ui/progress";
import { Dialog } from "@/components/ui/dialog";
import { PageBody, PageHeader } from "@/components/layout/PageHeader";
import { useJob } from "@/hooks/useJob";
import { cn, formatCny } from "@/lib/utils";
import { t } from "@/lib/i18n";

const NOVELTY: Record<string, { label: string; tone: "green" | "amber" | "red" | "neutral" }> = {
  novel: { label: t("未找到相同工作"), tone: "green" },
  partial: { label: t("有相近工作"), tone: "amber" },
  done: { label: t("已有人做过"), tone: "red" },
  unchecked: { label: t("未查重"), tone: "neutral" },
};

/** 极简 Markdown 渲染：只处理标题、列表、粗体和段落，够看提案 */
function Markdown({ text }: { text: string }) {
  const blocks = text.split("\n");
  return (
    <div className="space-y-1.5 text-[12.5px] leading-[1.85] text-ink-800">
      {blocks.map((line, i) => {
        const t = line.trim();
        if (!t) return <div key={i} className="h-1" />;
        if (t.startsWith("### ")) {
          return (
            <div key={i} className="pt-1 text-[13px] font-semibold text-ink-900">
              {t.slice(4)}
            </div>
          );
        }
        if (t.startsWith("## ")) {
          return (
            <div key={i} className="pt-2 text-[13.5px] font-semibold text-brand-700">
              {t.slice(3)}
            </div>
          );
        }
        if (t.startsWith("# ")) {
          return (
            <div key={i} className="text-[16px] font-semibold text-ink-900">
              {t.slice(2)}
            </div>
          );
        }
        if (/^[-*]\s/.test(t)) {
          return (
            <div key={i} className="flex gap-1.5 pl-1">
              <span className="mt-[9px] h-1 w-1 shrink-0 rounded-full bg-ink-400" />
              <span>{t.slice(2)}</span>
            </div>
          );
        }
        if (/^\d+[.、]\s/.test(t)) {
          return (
            <div key={i} className="flex gap-1.5 pl-1">
              <span className="shrink-0 font-mono text-[11px] text-ink-400">
                {t.match(/^\d+/)?.[0]}.
              </span>
              <span>{t.replace(/^\d+[.、]\s*/, "")}</span>
            </div>
          );
        }
        return <p key={i}>{t}</p>;
      })}
    </div>
  );
}

function IdeaDrawer({
  projectId,
  ideaId,
  onClose,
  onProposal,
  proposalRunning,
}: {
  projectId: string;
  ideaId: string | null;
  onClose: () => void;
  onProposal: (id: string) => void;
  proposalRunning: boolean;
}) {
  const [copied, setCopied] = useState(false);
  const { data } = useQuery({
    queryKey: ["idea", projectId, ideaId],
    queryFn: () => ideasApi.get(projectId, ideaId!),
    enabled: !!ideaId,
  });

  useEffect(() => setCopied(false), [ideaId]);

  const copy = async () => {
    if (!data?.proposal_md) return;
    await navigator.clipboard.writeText(data.proposal_md);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const download = () => {
    if (!data?.proposal_md) return;
    const blob = new Blob([data.proposal_md], { type: "text/markdown;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${data.title.slice(0, 40)}.md`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const idea: IdeaDetail | undefined = data;

  return (
    <Dialog
      open={!!ideaId}
      onClose={onClose}
      title={idea?.title ?? t("加载中…")}
      desc={idea?.one_liner ?? undefined}
      width="max-w-3xl"
      footer={
        idea ? (
          <>
            <span className="mr-auto text-[11px] text-ink-400">
              Elo {idea.elo.toFixed(0)} · {idea.wins} {t("胜")} {idea.losses} {t("负")}
            </span>
            {idea.proposal_md && (
              <>
                <Button size="sm" onClick={copy}>
                  {copied ? <CheckCircle2 size={13} /> : <Copy size={13} />}
                  {copied ? t("已复制") : t("复制")}
                </Button>
                <Button size="sm" onClick={download}>
                  <Download size={13} /> {t("下载 .md")}
                </Button>
              </>
            )}
            <Button
              size="sm"
              variant="primary"
              loading={proposalRunning}
              onClick={() => onProposal(idea.id)}
            >
              <FileText size={13} /> {idea.proposal_md ? t("重新生成提案") : t("生成研究提案")}
            </Button>
          </>
        ) : null
      }
    >
      {!idea ? (
        <div className="flex justify-center py-10">
          <Spinner />
        </div>
      ) : (
        <div className="max-h-[62vh] space-y-3 overflow-y-auto pr-1">
          <div className="grid gap-2 sm:grid-cols-2">
            {idea.gap && (
              <div className="rounded-lg bg-canvas px-3 py-2">
                <div className="text-[10.5px] font-medium text-ink-400">{t("填的空白")}</div>
                <div className="text-[12px] leading-relaxed text-ink-700">{idea.gap}</div>
              </div>
            )}
            {idea.why_novel && (
              <div className="rounded-lg bg-canvas px-3 py-2">
                <div className="text-[10.5px] font-medium text-ink-400">{t("为什么新")}</div>
                <div className="text-[12px] leading-relaxed text-ink-700">{idea.why_novel}</div>
              </div>
            )}
          </div>

          {idea.method_sketch && (
            <div>
              <div className="text-[11px] font-medium text-ink-500">{t("怎么做")}</div>
              <ol className="mt-1 space-y-0.5">
                {idea.method_sketch
                  .split("\n")
                  .filter(Boolean)
                  .map((s, i) => (
                    <li key={i} className="flex gap-1.5 text-[12px] leading-relaxed text-ink-700">
                      <span className="font-mono text-[11px] text-ink-400">{i + 1}.</span>
                      {s.replace(/^\d+[.、)]\s*/, "")}
                    </li>
                  ))}
              </ol>
            </div>
          )}

          {idea.risks && (
            <div className="rounded-lg border border-red-100 bg-red-50/60 px-3 py-2">
              <div className="text-[10.5px] font-medium text-red-700">{t("最大风险")}</div>
              <div className="text-[12px] leading-relaxed text-red-800/90">{idea.risks}</div>
            </div>
          )}

          {idea.novelty_report?.check && (
            <div className="rounded-lg border border-line px-3 py-2">
              <div className="text-[10.5px] font-medium text-ink-400">{t("查重结论")}</div>
              <div className="text-[12px] leading-relaxed text-ink-700">
                {idea.novelty_report.check.summary}
              </div>
            </div>
          )}

          {!!idea.evidence.length && (
            <div>
              <div className="text-[11px] font-medium text-ink-500">{t("证据论文")}</div>
              <div className="mt-1 space-y-0.5">
                {idea.evidence.map((e) => (
                  <div key={e.id} className="truncate text-[11.5px] text-ink-600">
                    · {e.title}
                  </div>
                ))}
              </div>
            </div>
          )}

          {!!idea.comparisons.length && (
            <div>
              <div className="text-[11px] font-medium text-ink-500">{t("对比记录")}</div>
              <div className="mt-1 space-y-1">
                {idea.comparisons.slice(0, 4).map((c, i) => (
                  <div key={i} className="rounded bg-canvas px-2.5 py-1.5 text-[11px] leading-relaxed text-ink-600">
                    <span className="font-mono text-[10px] text-ink-400">第{c.round} {t("场")}</span>{" "}
                    {c.rationale}
                  </div>
                ))}
              </div>
            </div>
          )}

          {idea.proposal_md && (
            <div className="rounded-lg border border-line px-3.5 py-3">
              <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-medium text-brand-700">
                <FileText size={11} /> {t("研究提案")}
              </div>
              <Markdown text={idea.proposal_md} />
            </div>
          )}
        </div>
      )}
    </Dialog>
  );
}

export default function IdeasPage() {
  const { projectId = "" } = useParams();
  const qc = useQueryClient();
  const [jobId, setJobId] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [proposalFor, setProposalFor] = useState<string | null>(null);

  const { data: ideas, isLoading } = useQuery({
    queryKey: ["ideas", projectId],
    queryFn: () => ideasApi.list(projectId),
    enabled: !!projectId,
  });

  const { job } = useJob(jobId, () => {
    qc.invalidateQueries({ queryKey: ["ideas", projectId] });
    qc.invalidateQueries({ queryKey: ["idea", projectId] });
    qc.invalidateQueries({ queryKey: ["cost"] });
    setProposalFor(null);
  });

  const tournament = useMutation({
    mutationFn: () => ideasApi.tournament(projectId, 1),
    onSuccess: (r) => setJobId(r.job_id),
  });
  const proposal = useMutation({
    mutationFn: (id: string) => ideasApi.proposal(projectId, id),
    onSuccess: (r, id) => {
      setProposalFor(id);
      setJobId(r.job_id);
    },
  });

  const running = job?.status === "running" || job?.status === "queued";
  const maxElo = Math.max(1600, ...(ideas ?? []).map((i) => i.elo));

  return (
    <div className="min-h-full">
      <PageHeader
        title={t("创新点")}
        desc={t("两两对比排出高下——比直接打分管用，因为「只能留一个，你留哪个」是个真问题")}
        actions={
          <Button
            variant="primary"
            disabled={running || (ideas?.length ?? 0) < 2}
            loading={tournament.isPending}
            onClick={() => tournament.mutate()}
            title={(ideas?.length ?? 0) < 2 ? t("至少要有 2 个想法") : ""}
          >
            <Swords size={14} /> {t("跑一轮对比")}
          </Button>
        }
      />

      <PageBody className="max-w-4xl space-y-4">
        {(running || job?.status === "failed" || job?.status === "done") && (
          <div
            className={cn(
              "rounded-xl border px-4 py-3",
              job?.status === "failed" ? "border-red-100 bg-red-50" : "border-line bg-surface",
            )}
          >
            {running && (
              <>
                <div className="flex items-center justify-between text-[12.5px]">
                  <span className="flex items-center gap-1.5 text-ink-700">
                    <Loader2 size={13} className="animate-spin" />
                    {job?.step || t("处理中…")}
                  </span>
                  <span className="font-mono text-ink-500">
                    {Math.round((job?.progress ?? 0) * 100)}%
                  </span>
                </div>
                <Progress className="mt-2" value={job?.progress ?? 0} />
              </>
            )}
            {job?.status === "failed" && (
              <div className="flex items-start gap-2 text-[12.5px] text-red-700">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <span className="min-w-0 break-words">
                  {(job.error || "").split("\n")[0]}
                </span>
              </div>
            )}
            {job?.status === "done" && (
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-ink-600">
                <span className="flex items-center gap-1 font-medium text-emerald-700">
                  <CheckCircle2 size={13} /> {t("完成")}
                </span>
                {job.type === "idea_tournament" && (
                  <span>
                    比了 {String((job.result as Record<string, unknown>)?.matches ?? 0)} {t("场 ·")}{" "}
                    {String((job.result as Record<string, unknown>)?.ideas ?? 0)} {t("个想法")}
                  </span>
                )}
                {job.type === "idea_proposal" && (
                  <span>
                    提案 {String((job.result as Record<string, unknown>)?.chars ?? 0)} {t("字")}
                  </span>
                )}
                <Badge tone="brand">
                  花费 {formatCny(Number((job.result as Record<string, unknown>)?.cost_cny ?? 0))}
                </Badge>
              </div>
            )}
          </div>
        )}

        {isLoading ? (
          <div className="flex justify-center py-16">
            <Spinner />
          </div>
        ) : !ideas?.length ? (
          <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-14 text-center">
            <Trophy size={22} className="mx-auto text-ink-300" />
            <div className="mt-2 text-[13px] font-medium text-ink-700">{t("还没有想法")}</div>
            <div className="mt-1 text-[12.5px] text-ink-400">
              {t("去「本地论文 → 创新点讨论」生成一批，或者用「论文图谱 → 研究空白」挖出来再讨论")}
            </div>
          </div>
        ) : (
          <div className="overflow-hidden rounded-xl border border-line bg-surface">
            <div className="flex items-center gap-3 border-b border-line px-4 py-2 text-[11px] text-ink-400">
              <span className="w-6 text-center">#</span>
              <span className="flex-1">{t("想法")}</span>
              <span className="w-28 text-right">Elo</span>
              <span className="w-16 text-right">{t("战绩")}</span>
              <span className="w-24 text-right">{t("查重")}</span>
            </div>
            <div className="divide-y divide-line">
              {(ideas as IdeaRow[]).map((idea, i) => {
                const nov = NOVELTY[idea.novelty_status] ?? NOVELTY.unchecked;
                const pct = Math.max(4, Math.min(100, ((idea.elo - 1300) / (maxElo - 1300)) * 100));
                return (
                  <button
                    key={idea.id}
                    onClick={() => setOpenId(idea.id)}
                    className="flex w-full items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-canvas"
                  >
                    <span
                      className={cn(
                        "w-6 shrink-0 text-center font-mono text-[12px]",
                        i === 0 ? "font-semibold text-amber-600" : "text-ink-400",
                      )}
                    >
                      {i === 0 ? <Trophy size={13} className="inline" /> : i + 1}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-medium text-ink-900">
                        {idea.title}
                      </span>
                      {idea.one_liner && (
                        <span className="mt-0.5 block truncate text-[11.5px] text-ink-500">
                          {idea.one_liner}
                        </span>
                      )}
                    </span>
                    <span className="w-28 shrink-0">
                      <span className="block text-right font-mono text-[12px] text-ink-700">
                        {idea.elo.toFixed(0)}
                      </span>
                      <span className="mt-0.5 block h-1 w-full overflow-hidden rounded-full bg-line">
                        <span
                          className="block h-full rounded-full bg-brand-500"
                          style={{ width: `${pct}%` }}
                        />
                      </span>
                    </span>
                    <span className="w-16 shrink-0 text-right font-mono text-[11px] text-ink-500">
                      {idea.wins}-{idea.losses}
                    </span>
                    <span className="w-24 shrink-0 text-right">
                      <Badge tone={nov.tone}>{nov.label}</Badge>
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div className="text-[11px] leading-relaxed text-ink-400">
          对比是盲评：每场随机决定谁先出现，避免总是偏向 A。Elo 初始 1500，赢了加分、输了扣分，
          分差越大赢得越多说明越意外。
        </div>
      </PageBody>

      <IdeaDrawer
        projectId={projectId}
        ideaId={openId}
        onClose={() => setOpenId(null)}
        onProposal={(id) => proposal.mutate(id)}
        proposalRunning={proposal.isPending || (running && proposalFor === openId)}
      />
    </div>
  );
}
