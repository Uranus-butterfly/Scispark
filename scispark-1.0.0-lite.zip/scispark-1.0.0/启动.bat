@echo off
chcp 65001 >nul
title SciSpark
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo 没找到 Python。
  echo 请先安装 Python 3.10 以上：https://www.python.org/downloads/
  echo 安装时记得勾选 "Add python.exe to PATH"，装完再双击本文件。
  echo.
  pause
  exit /b 1
)

python tools\launcher.py %*
if errorlevel 1 (
  echo.
  pause
)
