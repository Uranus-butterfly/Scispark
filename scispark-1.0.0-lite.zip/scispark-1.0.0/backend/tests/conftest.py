"""测试前置：把数据目录指到临时目录，避免污染真实数据。"""

from __future__ import annotations

import os
import tempfile

_TMP = tempfile.mkdtemp(prefix="scispark-test-")
os.environ["DATA_DIR"] = _TMP
os.environ["DB_PATH"] = os.path.join(_TMP, "test.db")
os.environ["LOCAL_PAPERS_DIR"] = os.path.join(_TMP, "papers")
os.environ["LLM_MODE"] = "mock"
os.environ["DAILY_BUDGET_CNY"] = "5"

import pytest  # noqa: E402

from app.db import init_db  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _db():
    init_db()
    yield


@pytest.fixture()
def project_id() -> str:
    from app.db import execute, new_id

    pid = new_id()
    execute(
        "INSERT INTO project(id, name, topic) VALUES (?,?,?)",
        (pid, "测试项目", "检索增强生成的评测"),
    )
    return pid
