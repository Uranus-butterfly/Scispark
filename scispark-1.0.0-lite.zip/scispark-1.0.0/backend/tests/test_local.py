"""本地论文读取：目录扫描、章节切分、双栏排序、路径安全。"""

from pathlib import Path

import pytest

from app.config import settings
from app.services import host_fs
from app.sources import local_reader

PAPER = """Neural Retrieval for Question Answering

Abstract
We study retrieval methods for open-domain QA and propose a new dense retriever.

1 Introduction
Retrieval augmented generation has become a standard approach. However existing
retrievers struggle with multi-hop questions and long documents.

2 Related Work
Prior work on sparse retrieval uses BM25. Dense retrieval uses dual encoders.

3 Method
We propose a two-stage retriever that first filters with BM25 then reranks with a
cross encoder. The reranker is trained with a contrastive objective.

4 Experiments
We evaluate on Natural Questions and TriviaQA. Our method improves exact match by
2.1 points over the strongest baseline.

5 Limitations
Our approach requires a large reranking model, which increases latency. We did not
evaluate on non-English languages.

References
[1] Some paper. 2020.
[2] Another paper. 2021.
"""


def test_split_sections():
    secs = local_reader.split_sections(PAPER)
    names = [n for n, _ in secs]
    assert "Introduction" in names
    assert "Method" in names
    assert "Limitations" in names
    # 参考文献之后不应保留
    assert not any("References" in n for n in names)
    method = dict(secs)["Method"]
    assert "cross encoder" in method


def test_split_sections_fallback():
    secs = local_reader.split_sections("just some text without headings " * 20)
    assert len(secs) == 1
    assert secs[0][0] == "正文"


def test_scan_dir(tmp_path):
    (tmp_path / "a.pdf").write_bytes(b"%PDF-1.4 fake")
    (tmp_path / "b.md").write_text("# hi", encoding="utf-8")
    (tmp_path / "c.png").write_bytes(b"x")
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "d.txt").write_text("text", encoding="utf-8")

    files = local_reader.scan_dir(tmp_path)
    names = {f.name for f in files}
    assert names == {"a.pdf", "b.md", "d.txt"}


def test_scan_dir_missing():
    assert local_reader.scan_dir(Path("/nonexistent/xyz")) == []


def test_order_pdf_blocks_two_columns():
    # 页宽 600，左栏 x=50..280，右栏 x=320..550
    blocks = [
        (50, 100, 280, 120, "left-1", 0, 0),
        (50, 130, 280, 150, "left-2", 1, 0),
        (320, 100, 550, 120, "right-1", 2, 0),
        (320, 130, 550, 150, "right-2", 3, 0),
    ]
    out = local_reader._order_pdf_blocks(blocks, 600)
    assert out.split("\n") == ["left-1", "left-2", "right-1", "right-2"]


def test_order_pdf_blocks_single_column():
    blocks = [
        (70, 100, 290, 120, "para-1", 0, 0),
        (70, 130, 290, 150, "para-2", 1, 0),
        (70, 160, 290, 180, "para-3", 2, 0),
    ]
    out = local_reader._order_pdf_blocks(blocks, 612)
    assert out.split("\n") == ["para-1", "para-2", "para-3"]


def test_clean_removes_hyphen_breaks():
    assert local_reader._clean("informa-\ntion retrieval") == "information retrieval"


def test_norm_collapses_dotdot():
    assert host_fs.norm("/Users/me/../me/papers/") == "/Users/me/papers"
    assert host_fs.norm("/") == "/"


def test_to_container_native_passthrough():
    # 没有挂载时（本地直跑）宿主路径就是真实路径
    assert host_fs.to_container("/tmp/abc") == Path("/tmp/abc")


def test_host_mount_mapping(tmp_path, monkeypatch):
    """配了 HOST_HOME_DIR / HOST_MOUNT 后，宿主路径要能映射进挂载点，越界要报错。"""
    monkeypatch.setattr(settings, "host_home_dir", str(tmp_path))
    monkeypatch.setattr(settings, "host_mount", str(tmp_path))

    assert host_fs.to_container(str(tmp_path)) == tmp_path
    assert host_fs.to_container(f"{tmp_path}/论文") == tmp_path / "论文"
    # 反向
    assert host_fs.to_host(tmp_path / "论文") == f"{tmp_path}/论文"
    # 越界
    with pytest.raises(ValueError):
        host_fs.to_container("/etc/passwd")
    # 上级在挂载根处截止，防止一直点到 /
    assert host_fs.parent_of(str(tmp_path)) is None


def test_browse_lists_dirs_and_papers(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "host_home_dir", str(tmp_path))
    monkeypatch.setattr(settings, "host_mount", str(tmp_path))

    root = tmp_path / "papers"
    (root / "sub").mkdir(parents=True)
    (root / "a.pdf").write_bytes(b"%PDF-1.4")
    (root / "sub" / "b.md").write_text("# b", encoding="utf-8")
    (root / "ignore.png").write_bytes(b"x")

    data = host_fs.browse(str(root))
    assert data["exists"] is True
    assert [d["name"] for d in data["dirs"]] == ["sub"]
    assert data["dirs"][0]["papers"] == 1
    assert [f["name"] for f in data["files"]] == ["a.pdf"]
    assert data["files"][0]["path"] == f"{root}/a.pdf"


def test_browse_missing_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "host_home_dir", str(tmp_path))
    monkeypatch.setattr(settings, "host_mount", str(tmp_path))
    data = host_fs.browse(str(tmp_path / "nope"))
    assert data["exists"] is False
