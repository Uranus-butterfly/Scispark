"""调研批次：分组、命名、删除。"""

from __future__ import annotations

import ast
import inspect
from pathlib import Path

from app.services import batches, ingest


def _mk_paper(project_id: str, batch_id: str | None, title: str = "T") -> str:
    from app.db import execute, new_id

    pid = new_id()
    execute(
        "INSERT INTO paper(id, project_id, source, source_id, title, title_norm, batch_id)"
        " VALUES (?,?,?,?,?,?,?)",
        (pid, project_id, "arxiv", pid, title, title.lower(), batch_id),
    )
    return pid


# ----------------------------------------------------------------------
# 回归：rerank 的调用参数必须和签名一致
# ----------------------------------------------------------------------
def test_rerank_accepts_venue_prefs():
    """曾经踩过：调用处传了 venue_prefs，但函数签名没加，一调研就 TypeError。"""
    params = inspect.signature(ingest.rerank).parameters
    assert "venue_prefs" in params


def test_all_rerank_calls_use_valid_kwargs():
    """静态检查 ingest.py 里所有 rerank(...) 调用的关键字参数都在签名里。

    比单个 test_rerank_accepts_venue_prefs 更通用：以后再加参数忘了同步签名，
    这里也会挂。
    """
    allowed = set(inspect.signature(ingest.rerank).parameters)
    src = Path(inspect.getfile(ingest)).read_text(encoding="utf-8")
    tree = ast.parse(src)

    checked = 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        fn = node.func
        if not (isinstance(fn, ast.Name) and fn.id == "rerank"):
            continue
        checked += 1
        for kw in node.keywords:
            if kw.arg is None:  # **kwargs
                continue
            assert kw.arg in allowed, f"rerank() 没有参数 {kw.arg}，调用处却传了"
    assert checked >= 1, "没找到 rerank 调用，检查是不是被改名了"


# ----------------------------------------------------------------------
# 批次本身
# ----------------------------------------------------------------------
def test_auto_label_uses_query():
    assert batches.auto_label("retrieval augmented generation") == "retrieval augmented generation"
    long = "a" * 100
    assert len(batches.auto_label(long)) <= batches.LABEL_MAX
    assert batches.auto_label("   ") == "未命名调研"


def test_create_and_list(project_id):
    b1 = batches.create(project_id, query_text="第一个方向")
    b2 = batches.create(project_id, label="我自己起的名字", query_text="第二个方向")
    _mk_paper(project_id, b1, "P1")
    _mk_paper(project_id, b1, "P2")
    _mk_paper(project_id, b2, "P3")
    batches.finish(b1, 2, 0.12)

    items = batches.list_for(project_id)
    by_id = {i["id"]: i for i in items if i["id"]}
    assert by_id[b1]["label"] == "第一个方向"      # 没给名字就用查询文本
    assert by_id[b2]["label"] == "我自己起的名字"
    assert by_id[b1]["paper_count"] == 2
    assert by_id[b1]["inserted"] == 2
    assert abs(by_id[b1]["cost_cny"] - 0.12) < 1e-9


def test_loose_papers_get_own_group(project_id):
    """本地导入的论文没有批次，应该单独成一组而不是消失。"""
    _mk_paper(project_id, None, "本地论文")
    items = batches.list_for(project_id)
    loose = [i for i in items if i["loose"]]
    assert len(loose) == 1
    assert loose[0]["paper_count"] >= 1
    assert loose[0]["id"] is None


def test_rename(project_id):
    bid = batches.create(project_id, query_text="旧名字")
    batches.rename(project_id, bid, "新名字")
    items = {i["id"]: i for i in batches.list_for(project_id) if i["id"]}
    assert items[bid]["label"] == "新名字"


def test_rename_rejects_empty(project_id):
    bid = batches.create(project_id, query_text="x")
    try:
        batches.rename(project_id, bid, "   ")
    except ValueError:
        return
    raise AssertionError("空名字应该被拒绝")


def test_remove_deletes_its_papers(project_id):
    bid = batches.create(project_id, query_text="要删的")
    other = batches.create(project_id, query_text="要留的")
    _mk_paper(project_id, bid, "A")
    _mk_paper(project_id, other, "B")

    out = batches.remove(project_id, bid)
    assert out["deleted_papers"] == 1

    ids = [i["id"] for i in batches.list_for(project_id) if i["id"]]
    assert bid not in ids
    assert other in ids
