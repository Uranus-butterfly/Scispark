"""期刊偏好：排序权重的纯逻辑测试（不联网、不调 LLM）。"""

from __future__ import annotations

from app.services.ingest import is_preprint, venue_multiplier
from app.sources.base import PaperRecord


def rec(venue: str = "", source: str = "openalex", citations: int = 0) -> PaperRecord:
    return PaperRecord(
        source=source,
        source_id="x",
        title="t",
        venue=venue,
        citation_count=citations,
    )


def test_preferred_venue_boosts():
    prefs = {"preferred": ["Nature"], "journals_only": False, "min_citations": 0}
    assert venue_multiplier(rec("Nature"), prefs) > venue_multiplier(rec("Random Journal"), prefs)
    assert venue_multiplier(rec("Nature Communications"), prefs) > 1.0


def test_venue_match_is_case_insensitive():
    prefs = {"preferred": ["nature"], "journals_only": False, "min_citations": 0}
    assert venue_multiplier(rec("NATURE"), prefs) > 1.0


def test_no_prefs_means_no_change():
    prefs = {"preferred": [], "journals_only": False, "min_citations": 0}
    assert venue_multiplier(rec("Anywhere", citations=0), prefs) == 1.0


def test_min_citations_downweights_but_keeps():
    prefs = {"preferred": [], "journals_only": False, "min_citations": 50}
    low = venue_multiplier(rec(citations=2), prefs)
    high = venue_multiplier(rec(citations=100), prefs)
    assert low < high
    assert low > 0  # 不删，只降权


def test_journals_only_downweights_preprint():
    prefs = {"preferred": [], "journals_only": True, "min_citations": 0}
    assert venue_multiplier(rec("", source="arxiv"), prefs) < venue_multiplier(
        rec("Journal of Testing"), prefs
    )


def test_is_preprint():
    assert is_preprint(rec("", source="arxiv"))
    assert is_preprint(rec("bioRxiv"))
    assert is_preprint(rec(""))
    assert not is_preprint(rec("Journal of Machine Learning Research"))
