"""去重、归一、粗排。"""

from app.sources.base import PaperRecord
from app.sources.normalize import (
    BM25,
    coarse_rank,
    dedupe,
    normalize_arxiv_id,
    normalize_doi,
    normalize_title,
    parse_date,
    reconstruct_abstract,
    tokenize,
)


def test_normalize_title():
    assert normalize_title("RAG: A  Survey!") == "rag a survey"
    assert normalize_title("  Deep   Learning  ") == "deep learning"
    assert normalize_title("Attention Is All You Need v3") == "attention is all you need"
    assert normalize_title("$\\mathcal{O}(n^2)$ Complexity") == "complexity"


def test_normalize_identifiers():
    assert normalize_doi("https://doi.org/10.1234/ABC") == "10.1234/abc"
    assert normalize_doi("doi:10.1234/abc") == "10.1234/abc"
    assert normalize_arxiv_id("http://arxiv.org/abs/2401.00001v2") == "2401.00001"
    assert normalize_arxiv_id("arXiv:2401.00001") == "2401.00001"


def test_parse_date():
    assert parse_date("2024-03-15T10:00:00Z") == "2024-03-15"
    assert parse_date("2024-03-15") == "2024-03-15"
    assert parse_date("2024-03") == "2024-03-01"
    assert parse_date("") == ""


def test_reconstruct_abstract():
    inv = {"hello": [0], "world": [1], "again": [2]}
    assert reconstruct_abstract(inv) == "hello world again"
    assert reconstruct_abstract(None) == ""


def _rec(**kw) -> PaperRecord:
    base = dict(source="arxiv", source_id="x", title="T")
    base.update(kw)
    return PaperRecord(**base)


def test_dedupe_by_arxiv_id():
    a = _rec(source_id="2401.1", arxiv_id="2401.1", title="Paper A", abstract="short")
    b = _rec(source="openalex", source_id="W1", arxiv_id="2401.1", title="Paper A", abstract="a much longer abstract here")
    out = dedupe([a, b])
    assert len(out) == 1
    assert out[0].abstract == "a much longer abstract here"
    assert out[0].raw.get("merged_from")


def test_dedupe_by_fuzzy_title():
    a = _rec(title="Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks")
    b = _rec(source="openalex", source_id="W2", title="Retrieval Augmented Generation for Knowledge Intensive NLP Tasks.")
    out = dedupe([a, b])
    assert len(out) == 1


def test_dedupe_keeps_distinct():
    a = _rec(title="Graph Neural Networks for Molecules")
    b = _rec(source="openalex", source_id="W3", title="Retrieval Augmented Generation for QA")
    assert len(dedupe([a, b])) == 2


def test_dedupe_survives_record_replacement():
    """回归：主记录被替换后，旧对象上的索引键必须重定向，否则后续记录会命中僵尸对象。"""
    a = _rec(source_id="x1", arxiv_id="1111.1", title="Paper A", abstract="short", doi="10.1/a")
    b = _rec(
        source="openalex", source_id="W1", arxiv_id="1111.1", title="Paper A",
        abstract="a much longer abstract " * 5, citation_count=100,
    )
    c = _rec(source="openalex", source_id="W2", doi="10.1/a", title="Paper A (journal version)")
    out = dedupe([a, b, c])
    assert len(out) == 1
    assert out[0].citation_count == 100
    assert "longer abstract" in out[0].abstract


def test_bm25_prefers_matching_doc():
    docs = [tokenize("retrieval augmented generation evaluation"),
            tokenize("protein folding molecular dynamics")]
    bm = BM25().fit(docs)
    assert bm.score(["retrieval"], 0) > bm.score(["retrieval"], 1)


def test_coarse_rank_orders_by_relevance():
    good = _rec(title="Retrieval Augmented Generation Evaluation", abstract="faithfulness citation accuracy")
    bad = _rec(source="openalex", source_id="W9", title="Protein Folding", abstract="molecular dynamics")
    ranked = coarse_rank([bad, good], ["retrieval", "augmented", "generation", "evaluation"])
    assert ranked[0][0].title.startswith("Retrieval")
