"""设置存取与脱敏。"""

from app.services import settings_store


def test_secret_masked():
    settings_store.set_many({"deepseek_api_key": "sk-1234567890abcdef"})
    view = settings_store.public_view()
    item = view["deepseek_api_key"]
    assert item["configured"] is True
    assert item["secret"] is True
    assert "sk-1" in item["value"]
    assert "1234567890abcdef" not in item["value"]


def test_whitelist_blocks_unknown_keys():
    settings_store.set_many({"rm_rf": "/", "deepseek_api_key": "sk-x"})
    from app.db import query

    assert not query("SELECT 1 FROM app_setting WHERE key = 'rm_rf'")


def test_bool_and_float_coercion():
    settings_store.set_many({"cache_enabled": "0", "daily_budget_cny": "12.5"})
    assert settings_store.get_bool("cache_enabled", True) is False
    assert settings_store.get_float("daily_budget_cny") == 12.5


def test_effective_model_fallback():
    settings_store.set_many({"model_flash": "deepseek-flash", "model_pro": "deepseek-v4-pro"})
    assert settings_store.effective_model("flash") == "deepseek-flash"
    assert settings_store.effective_model("pro") == "deepseek-v4-pro"


def test_temporary_override_does_not_persist():
    """「测试连接」用临时覆盖，不应写库。"""
    settings_store.set_many({"deepseek_api_key": "sk-saved"})
    with settings_store.temporary({"deepseek_api_key": "sk-typed-but-unsaved"}):
        assert settings_store.effective_api_key() == "sk-typed-but-unsaved"
    assert settings_store.effective_api_key() == "sk-saved"


def test_temporary_ignores_empty_and_unknown():
    settings_store.set_many({"deepseek_api_key": "sk-saved"})
    with settings_store.temporary({"deepseek_api_key": "   ", "bogus_key": "x"}):
        assert settings_store.effective_api_key() == "sk-saved"
        assert settings_store.get("bogus_key") == ""


def test_temporary_nested_restores_outer():
    settings_store.set_many({"model_flash": "m0"})
    with settings_store.temporary({"model_flash": "m1"}):
        assert settings_store.get("model_flash") == "m1"
        with settings_store.temporary({"model_flash": "m2"}):
            assert settings_store.get("model_flash") == "m2"
        assert settings_store.get("model_flash") == "m1"
    assert settings_store.get("model_flash") == "m0"
