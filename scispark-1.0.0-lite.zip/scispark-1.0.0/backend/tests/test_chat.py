"""共创对话：状态机与纯逻辑测试（不调 LLM）。"""

from __future__ import annotations

from app.services import chat


# ----------------------------------------------------------------------
# 状态机：每轮最多前进一步，允许后退一步
# ----------------------------------------------------------------------
def test_state_cannot_skip_phases():
    # 发散阶段直接宣布定稿，只允许推进到 narrowing
    assert chat.next_state("diverging", "converging") == "narrowing"
    assert chat.next_state("diverging", "done") == "narrowing"


def test_state_advances_one_step():
    assert chat.next_state("diverging", "narrowing") == "narrowing"
    assert chat.next_state("narrowing", "converging") == "converging"
    assert chat.next_state("converging", "done") == "done"


def test_state_can_go_back_one_step():
    assert chat.next_state("converging", "narrowing") == "narrowing"


def test_state_stays_when_no_change():
    assert chat.next_state("narrowing", "narrowing") == "narrowing"


def test_state_ignores_garbage():
    assert chat.next_state("narrowing", None) == "narrowing"
    assert chat.next_state("narrowing", "whatever") == "narrowing"


def test_state_handles_bad_current():
    assert chat.next_state("", "narrowing") == "diverging"


# ----------------------------------------------------------------------
# 节点类型白名单
# ----------------------------------------------------------------------
def test_node_types_whitelist():
    assert "rq" in chat.NODE_TYPES
    assert "hypothesis" in chat.NODE_TYPES
    assert "garbage" not in chat.NODE_TYPES


def test_states_order():
    assert chat.STATES == ["diverging", "narrowing", "converging", "done"]


# ----------------------------------------------------------------------
# 脑图与对话共用 rq_node，靠 conversation.mode 区分
# ----------------------------------------------------------------------
def test_mindmap_uses_same_node_types():
    from app.services import mindmap

    assert mindmap.NODE_TYPES == chat.NODE_TYPES


def test_auto_layout_is_stable():
    """脑图自动布局：同一份数据两次结果一致（否则每次刷新节点会跳）。"""
    from app.services import mindmap  # noqa: F401  # 布局在前端，这里只校验节点类型集合

    assert "idea" in chat.NODE_TYPES
