"""数据库基础：建表、项目、FTS5 检索。"""

from app.db import (
    execute,
    fts_delete_paper,
    fts_index_paper,
    fts_search,
    new_id,
    query,
    query_one,
)


def test_schema_tables_exist():
    names = {r["name"] for r in query("SELECT name FROM sqlite_master WHERE type='table'")}
    for t in (
        "project", "paper", "paper_insight", "paper_relation", "concept",
        "paper_concept", "claim", "rq_node", "idea", "idea_evidence",
        "idea_comparison", "conversation", "message", "watch_topic",
        "scan_run", "llm_call_log", "job", "notification", "fetch_log",
    ):
        assert t in names, f"缺少表 {t}"


def test_fts5_available():
    # 能查询即说明 FTS5 编译进来了
    assert query("SELECT count(*) AS c FROM paper_fts")[0]["c"] == 0


def test_insert_and_search_paper(project_id):
    pid = new_id()
    execute(
        "INSERT INTO paper(id, project_id, source, source_id, title, title_norm,"
        " abstract, tldr, year, citation_count, status)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (
            pid, project_id, "arxiv", "2401.00001",
            "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks",
            "retrieval augmented generation for knowledge intensive nlp tasks",
            "We explore a general-purpose fine-tuning recipe for retrieval-augmented generation.",
            "RAG combines a parametric and non-parametric memory.",
            2020, 5000, "new",
        ),
    )
    fts_index_paper(pid)

    hits = fts_search("retrieval augmented generation", limit=10)
    assert any(h["paper_id"] == pid for h in hits)
    assert hits[0]["score"] > 0

    # 无关词不应命中
    assert not any(h["paper_id"] == pid for h in fts_search("protein folding", limit=10))

    fts_delete_paper(pid)
    assert not any(h["paper_id"] == pid for h in fts_search("retrieval augmented", limit=10))


def test_project_cascade_delete(project_id):
    before = query_one("SELECT COUNT(*) AS c FROM project WHERE id = ?", (project_id,))
    assert before["c"] == 1
    execute("DELETE FROM project WHERE id = ?", (project_id,))
    after = query_one("SELECT COUNT(*) AS c FROM paper WHERE project_id = ?", (project_id,))
    assert after["c"] == 0


def test_unique_title_dedup(project_id):
    import sqlite3

    rows = [
        (new_id(), project_id, "arxiv", "a1", "Same Title", "same title"),
        (new_id(), project_id, "openalex", "a2", "Same Title", "same title"),
    ]
    execute(
        "INSERT INTO paper(id, project_id, source, source_id, title, title_norm)"
        " VALUES (?,?,?,?,?,?)",
        rows[0],
    )
    try:
        execute(
            "INSERT INTO paper(id, project_id, source, source_id, title, title_norm)"
            " VALUES (?,?,?,?,?,?)",
            rows[1],
        )
        raise AssertionError("同标题应被唯一索引拦截")
    except sqlite3.IntegrityError:
        pass
