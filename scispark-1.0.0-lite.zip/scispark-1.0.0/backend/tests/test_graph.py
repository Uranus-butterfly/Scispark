"""图谱三层边 + Gap 候选的纯函数测试（不碰数据库、不花 LLM）。"""

from __future__ import annotations

from app.services import gaps, graph


def _p(pid: str, title: str, **kw) -> dict:
    base = {
        "id": pid,
        "title": title,
        "abstract": "",
        "tldr": "",
        "source": "arxiv",
        "source_id": f"src-{pid}",
        "year": "2024",
        "citations": 0,
        "problem": "",
        "method": "",
        "findings": [],
        "refs": set(),
        "concepts": set(),
    }
    base.update(kw)
    return base


# ----------------------------------------------------------------------
# 第 1 层：引用耦合
# ----------------------------------------------------------------------
def test_citation_edges_detects_shared_references():
    a = _p("a", "A", refs={"W1", "W2", "W3", "W4"})
    b = _p("b", "B", refs={"W1", "W2", "W3", "W5"})  # 共享 3 篇
    c = _p("c", "C", refs={"W9", "W8"})  # 无关
    edges = graph.citation_edges([a, b, c])
    assert ("a", "b") in edges
    rel, w = edges[("a", "b")]
    assert rel == "coupling"
    assert 0.4 < w < 0.7  # 3 / (4+4-3) = 0.6
    assert not any("c" in k for k in edges)


def test_citation_edges_direct_citation_wins():
    a = _p("a", "A", source_id="W100", refs={"W100"})
    b = _p("b", "B", source_id="W100", refs=set())
    edges = graph.citation_edges([a, b])
    assert edges[("a", "b")][0] == "cites"


def test_citation_edges_needs_more_than_one_shared_ref():
    # 只共同引用一篇热门工作不足以说明相关（COUPLING_MIN_SHARED=2 挡掉）
    papers = [_p(f"p{i}", f"P{i}", refs={"HOT"}) for i in range(5)]
    assert graph.citation_edges(papers) == {}


# ----------------------------------------------------------------------
# 第 2 层：语义相似
# ----------------------------------------------------------------------
def test_semantic_edges_groups_similar_titles():
    a = _p("a", "Retrieval augmented generation for question answering")
    b = _p("b", "Retrieval augmented generation for open domain question answering")
    c = _p("c", "Protein folding with diffusion models")
    edges = graph.semantic_edges([a, b, c])
    assert ("a", "b") in edges
    assert edges[("a", "b")][0] == "similar"
    assert ("a", "c") not in edges


def test_tokenize_drops_stopwords():
    toks = graph.tokenize("The retrieval model is based on the BM25 baseline")
    assert "retrieval" in toks
    assert "the" not in toks
    assert "bm25" in toks


# ----------------------------------------------------------------------
# 第 3 层：概念共现
# ----------------------------------------------------------------------
def test_concept_edges_needs_two_shared():
    a = _p("a", "A", concepts={"rag", "evaluation"})
    b = _p("b", "B", concepts={"rag", "evaluation", "llm"})
    c = _p("c", "C", concepts={"rag", "vision"})
    edges = graph.concept_edges([a, b, c])
    assert ("a", "b") in edges
    assert edges[("a", "b")][0] == "same_concept"
    assert ("a", "c") not in edges  # 只共享 1 个


# ----------------------------------------------------------------------
# 合并优先级
# ----------------------------------------------------------------------
def test_merge_prefers_citation_over_similar():
    e1 = {("a", "b"): ("cites", 1.0)}
    e2 = {("a", "b"): ("similar", 0.9)}
    merged = graph._merge(e1, e2)
    assert merged[("a", "b")][0] == "cites"


# ----------------------------------------------------------------------
# Gap 候选
# ----------------------------------------------------------------------
def test_limitation_clustering_pure_logic():
    """两条不同论文、措辞相近的局限应该聚成一簇。"""
    items = [
        {"tokens": set(graph.tokenize("requires large reranking model increases latency"))},
        {"tokens": set(graph.tokenize("large reranking model increases latency significantly"))},
        {"tokens": set(graph.tokenize("only evaluated english datasets"))},
    ]
    clusters = []
    for it in items:
        for cl in clusters:
            if gaps._jac(it["tokens"], cl["rep"]) >= 0.26:
                cl["items"].append(it)
                break
        else:
            clusters.append({"rep": it["tokens"], "items": [it]})
    assert len(clusters) == 2
    assert len(clusters[0]["items"]) == 2


def test_negation_detection():
    assert gaps._NEG.search("this approach fails on long documents")
    assert gaps._NEG.search("limited to English")
    assert not gaps._NEG.search("our method improves accuracy by 3 points")
