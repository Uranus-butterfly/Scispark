"""进展扫描：时间窗解析（不联网、不调 LLM）。"""

from __future__ import annotations

from datetime import date

from app.services import scan


def test_window_month():
    start, end = scan.resolve_window("month", today=date(2026, 11, 2))
    assert end == "2026-11-02"
    assert start == "2026-10-03"


def test_window_week_and_quarter():
    assert scan.resolve_window("week", today=date(2026, 11, 2))[0] == "2026-10-26"
    assert scan.resolve_window("quarter", today=date(2026, 11, 2))[0] == "2026-08-04"


def test_window_defaults_to_month():
    start, _ = scan.resolve_window(None, today=date(2026, 11, 2))
    assert start == "2026-10-03"


def test_explicit_dates_win():
    start, end = scan.resolve_window(
        "week", date_from="2026-09-01", date_to="2026-09-30", today=date(2026, 11, 2)
    )
    assert (start, end) == ("2026-09-01", "2026-09-30")


def test_unknown_window_falls_back_to_month():
    start, _ = scan.resolve_window("decade", today=date(2026, 11, 2))
    assert start == "2026-10-03"


def test_windows_are_ordered():
    keys = ["week", "month", "quarter", "half_year", "year"]
    days = [scan.WINDOWS[k] for k in keys]
    assert days == sorted(days)


# ----------------------------------------------------------------------
# Elo
# ----------------------------------------------------------------------
def test_elo_expected_score_symmetric():
    from app.services.ideas import expected_score

    assert abs(expected_score(1500, 1500) - 0.5) < 1e-9
    assert expected_score(1700, 1500) > 0.5
    assert abs(expected_score(1700, 1500) + expected_score(1500, 1700) - 1.0) < 1e-9


def test_elo_update_zero_sum():
    from app.services.ideas import update_elo

    na, nb = update_elo(1500, 1500, 1.0)
    assert na > 1500 > nb
    assert abs((na - 1500) + (nb - 1500)) < 0.11  # 四舍五入误差内守恒


def test_elo_upset_gains_more():
    from app.services.ideas import update_elo

    # 弱者赢：涨得多；强者赢：涨得少
    upset, _ = update_elo(1400, 1600, 1.0)
    favorite, _ = update_elo(1600, 1400, 1.0)
    assert (upset - 1400) > (favorite - 1600)


def test_elo_draw_moves_toward_each_other():
    from app.services.ideas import update_elo

    na, nb = update_elo(1400, 1600, 0.5)
    assert na > 1400 and nb < 1600
