"""定价与峰谷判断。"""

from datetime import datetime, timezone

from app.llm import pricing


def test_peak_windows():
    # 2026-11-02 是周一
    mon = datetime(2026, 11, 2, tzinfo=timezone.utc)
    assert pricing.is_peak(mon.replace(hour=2)) is True
    assert pricing.is_peak(mon.replace(hour=7)) is True
    assert pricing.is_peak(mon.replace(hour=0)) is False
    assert pricing.is_peak(mon.replace(hour=5)) is False
    assert pricing.is_peak(mon.replace(hour=10)) is False
    assert pricing.is_peak(mon.replace(hour=23)) is False


def test_weekend_always_offpeak():
    sat = datetime(2026, 11, 7, 2, tzinfo=timezone.utc)
    assert sat.weekday() == 5
    assert pricing.is_peak(sat) is False


def test_peak_price_doubles():
    mon_peak = datetime(2026, 11, 2, 2, tzinfo=timezone.utc)
    mon_off = datetime(2026, 11, 2, 12, tzinfo=timezone.utc)
    hit_p, in_p, out_p = pricing.unit_prices("deepseek-flash", mon_peak)
    hit_o, in_o, out_o = pricing.unit_prices("deepseek-flash", mon_off)
    assert in_p == in_o * 2
    assert out_p == out_o * 2
    assert hit_p == hit_o * 2


def test_cost_matches_hand_calc():
    off = datetime(2026, 11, 2, 12, tzinfo=timezone.utc)
    # flash 空闲：输入 $0.15/M，输出 $0.60/M
    usd = pricing.cost_usd("deepseek-flash", 1_000_000, 1_000_000, 0, at=off)
    assert abs(usd - (0.15 + 0.60)) < 1e-9
    # 缓存命中部分按 $0.003/M
    usd2 = pricing.cost_usd("deepseek-flash", 1_000_000, 0, 1_000_000, at=off)
    assert abs(usd2 - 0.003) < 1e-9


def test_alias_normalization():
    assert pricing.normalize_model("deepseek-chat") == "deepseek-flash"
    assert pricing.normalize_model("deepseek-reasoner") == "deepseek-v4-pro"
    assert pricing.normalize_model("deepseek-flash") == "deepseek-flash"
