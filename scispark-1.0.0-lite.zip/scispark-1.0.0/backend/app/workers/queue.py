"""轻量任务队列。

不做 Celery/Redis：单进程 asyncio + job 表即可。
前端通过 GET /api/jobs/{id} 轮询进度。
"""

from __future__ import annotations

import asyncio
import logging
import traceback
from typing import Awaitable, Callable

from ..db import execute, new_id, now, query_one

log = logging.getLogger(__name__)

Handler = Callable[[str, dict], Awaitable[dict | None]]
_tasks: set[asyncio.Task] = set()


def create_job(job_type: str, project_id: str | None, payload: dict) -> str:
    job_id = new_id()
    import json

    execute(
        "INSERT INTO job(id, project_id, type, payload_json, status, created_at)"
        " VALUES (?,?,?,?,?,?)",
        (job_id, project_id, job_type, json.dumps(payload, ensure_ascii=False), "queued", now()),
    )
    return job_id


def progress(job_id: str, pct: float, step: str | None = None) -> None:
    if step is None:
        execute("UPDATE job SET progress = ? WHERE id = ?", (max(0.0, min(1.0, pct)), job_id))
    else:
        execute(
            "UPDATE job SET progress = ?, step = ? WHERE id = ?",
            (max(0.0, min(1.0, pct)), step, job_id),
        )


def get_job(job_id: str) -> dict | None:
    import json

    row = query_one("SELECT * FROM job WHERE id = ?", (job_id,))
    if row is None:
        return None
    d = dict(row)
    try:
        d["result"] = json.loads(d["result_json"]) if d.get("result_json") else None
    except (json.JSONDecodeError, TypeError):
        d["result"] = None
    d.pop("result_json", None)
    d.pop("payload_json", None)
    return d


async def _run(job_id: str, handler: Handler, payload: dict) -> None:
    import json

    execute(
        "UPDATE job SET status='running', started_at=?, attempts=attempts+1 WHERE id=?",
        (now(), job_id),
    )
    try:
        result = await handler(job_id, payload)
        execute(
            "UPDATE job SET status='done', progress=1.0, finished_at=?, result_json=? WHERE id=?",
            (now(), json.dumps(result or {}, ensure_ascii=False), job_id),
        )
    except asyncio.CancelledError:
        execute("UPDATE job SET status='cancelled', finished_at=? WHERE id=?", (now(), job_id))
        raise
    except Exception as e:  # noqa: BLE001
        log.exception("任务失败 %s", job_id)
        execute(
            "UPDATE job SET status='failed', finished_at=?, error=? WHERE id=?",
            (now(), f"{type(e).__name__}: {e}\n{traceback.format_exc()[-1200:]}", job_id),
        )


def submit(job_type: str, project_id: str | None, payload: dict, handler: Handler) -> str:
    """建 job 记录并异步执行，立即返回 job_id。

    必须在事件循环内调用（异步路由或 lifespan 里）。
    """
    job_id = create_job(job_type, project_id, payload)
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError as e:
        execute(
            "UPDATE job SET status='failed', error=?, finished_at=? WHERE id=?",
            ("提交任务时没有运行中的事件循环", now(), job_id),
        )
        raise RuntimeError("submit() 必须在异步上下文中调用") from e
    task = loop.create_task(_run(job_id, handler, payload))
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)
    return job_id
