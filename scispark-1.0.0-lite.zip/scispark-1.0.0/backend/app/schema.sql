-- SciSpark 数据库 schema
-- SQLite 3.35+ (FTS5, JSON1)
-- 所有时间字段统一为 ISO8601 文本（UTC 或本地，由应用层决定，默认本地）

-- 用 DELETE 而非 WAL：macOS Docker Desktop 的 bind mount 文件系统对 WAL 需要的
-- -shm 共享内存映射支持不良，且宿主 Spotlight 索引会以读写方式打开 db 文件、
-- 与 SQLite 抢锁。WAL→DELETE 的切换需要独占锁，被外部打开挡住就报
-- database is locked；反过来，库本身若已是 DELETE，这条 PRAGMA 是 no-op，
-- 不需要独占锁，外部索引再怎么开也影响不到写操作。
PRAGMA journal_mode = DELETE;
PRAGMA foreign_keys = ON;
PRAGMA synchronous = NORMAL;

-- ============================================================
-- 元信息
-- ============================================================
CREATE TABLE IF NOT EXISTS schema_version (
  version     INTEGER PRIMARY KEY,
  applied_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  note        TEXT
);

-- 键值配置（API key、模型名、预算等；敏感项由应用层加密/掩码）
CREATE TABLE IF NOT EXISTS app_setting (
  key         TEXT PRIMARY KEY,
  value       TEXT,
  is_secret   INTEGER NOT NULL DEFAULT 0,
  updated_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ============================================================
-- 项目
-- ============================================================
CREATE TABLE IF NOT EXISTS project (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  topic         TEXT NOT NULL,              -- 研究主题（中文可）
  description   TEXT,
  status        TEXT NOT NULL DEFAULT 'active',   -- active | archived
  settings_json TEXT NOT NULL DEFAULT '{}',       -- 项目级覆盖配置
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- ============================================================
-- 论文
-- ============================================================
CREATE TABLE IF NOT EXISTS paper (
  id              TEXT PRIMARY KEY,                 -- 内部 id（uuid 或 source:id）
  project_id      TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  source          TEXT NOT NULL,                    -- arxiv | openalex | s2 | manual
  source_id       TEXT NOT NULL,                    -- 该源内的 id
  doi             TEXT,
  arxiv_id        TEXT,
  title           TEXT NOT NULL,
  title_norm      TEXT NOT NULL,                    -- 归一化标题（去标点/版本号/小写）
  abstract        TEXT,
  tldr            TEXT,
  tldr_source     TEXT,                             -- s2 | llm
  authors_json    TEXT NOT NULL DEFAULT '[]',
  year            INTEGER,
  venue           TEXT,
  url             TEXT,
  pdf_url         TEXT,
  citation_count  INTEGER NOT NULL DEFAULT 0,
  published_at    TEXT,                             -- ISO date
  fetched_at      TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  relevance       REAL,                             -- 0..1 精排分
  relevance_reason TEXT,                            -- 中文一句话理由
  status          TEXT NOT NULL DEFAULT 'new',      -- new|ranked|understood|failed|archived
  raw_json        TEXT,
  UNIQUE (project_id, source, source_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_paper_dedup ON paper(project_id, title_norm);
CREATE INDEX IF NOT EXISTS ix_paper_pub   ON paper(project_id, published_at DESC);
CREATE INDEX IF NOT EXISTS ix_paper_status ON paper(project_id, status);
CREATE INDEX IF NOT EXISTS ix_paper_arxiv ON paper(arxiv_id);

-- FTS5 独立表（不走触发器，由应用层维护，见 db.fts_*）
CREATE VIRTUAL TABLE IF NOT EXISTS paper_fts USING fts5(
  paper_id UNINDEXED,
  title,
  abstract,
  tldr,
  insight,
  tokenize = "unicode61 remove_diacritics 2"
);

-- 结构化理解（可版本化重跑）
CREATE TABLE IF NOT EXISTS paper_insight (
  id              TEXT PRIMARY KEY,
  paper_id        TEXT NOT NULL REFERENCES paper(id) ON DELETE CASCADE,
  schema_version  INTEGER NOT NULL DEFAULT 1,
  model           TEXT,
  problem         TEXT,
  method          TEXT,
  datasets_json   TEXT NOT NULL DEFAULT '[]',
  findings_json   TEXT NOT NULL DEFAULT '[]',
  limitations_json TEXT NOT NULL DEFAULT '[]',
  key_claims_json TEXT NOT NULL DEFAULT '[]',
  concepts_json   TEXT NOT NULL DEFAULT '[]',
  novelty_note    TEXT,
  quality         REAL,
  tokens_in       INTEGER NOT NULL DEFAULT 0,
  tokens_out      INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  UNIQUE (paper_id, schema_version)
);

-- 论文间关系
CREATE TABLE IF NOT EXISTS paper_relation (
  src_id    TEXT NOT NULL REFERENCES paper(id) ON DELETE CASCADE,
  dst_id    TEXT NOT NULL REFERENCES paper(id) ON DELETE CASCADE,
  rel       TEXT NOT NULL,                 -- cites | cited_by | similar | same_concept
  weight    REAL NOT NULL DEFAULT 1.0,
  source    TEXT,                          -- openalex | s2 | tfidf | concept
  evidence  TEXT,
  PRIMARY KEY (src_id, dst_id, rel)
);
CREATE INDEX IF NOT EXISTS ix_rel_dst ON paper_relation(dst_id, rel);

-- ============================================================
-- 概念与断言
-- ============================================================
CREATE TABLE IF NOT EXISTS concept (
  id            TEXT PRIMARY KEY,
  project_id    TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  name_norm     TEXT NOT NULL,
  aliases_json  TEXT NOT NULL DEFAULT '[]',
  description   TEXT,
  paper_count   INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  UNIQUE (project_id, name_norm)
);
CREATE INDEX IF NOT EXISTS ix_concept_project ON concept(project_id);

CREATE TABLE IF NOT EXISTS paper_concept (
  paper_id    TEXT NOT NULL REFERENCES paper(id) ON DELETE CASCADE,
  concept_id  TEXT NOT NULL REFERENCES concept(id) ON DELETE CASCADE,
  role        TEXT,                        -- problem | uses | proposes | evaluates
  weight      REAL NOT NULL DEFAULT 1.0,
  PRIMARY KEY (paper_id, concept_id)
);
CREATE INDEX IF NOT EXISTS ix_pc_concept ON paper_concept(concept_id);

CREATE TABLE IF NOT EXISTS claim (
  id            TEXT PRIMARY KEY,
  paper_id      TEXT NOT NULL REFERENCES paper(id) ON DELETE CASCADE,
  text          TEXT NOT NULL,
  claim_type    TEXT NOT NULL,             -- finding | limitation | assumption | result
  polarity      INTEGER NOT NULL DEFAULT 1,  -- 1 正面 / -1 负面 / 0 中性
  quote         TEXT,                      -- 原文句子，供人工核对
  concept_ids_json TEXT NOT NULL DEFAULT '[]',
  confidence    REAL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_claim_paper ON claim(paper_id, claim_type);

-- ============================================================
-- 研究问题树（CoQuest 核心）
-- ============================================================
CREATE TABLE IF NOT EXISTS rq_node (
  id                TEXT PRIMARY KEY,
  project_id        TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  parent_id         TEXT REFERENCES rq_node(id) ON DELETE CASCADE,
  root_id           TEXT,                  -- 根节点 id，便于整棵树查询
  path              TEXT NOT NULL DEFAULT '',   -- 物化路径 /a/b/c
  depth             INTEGER NOT NULL DEFAULT 0,
  node_type         TEXT NOT NULL,         -- rq | hypothesis | use_case | narrowing | idea | note
  title             TEXT NOT NULL,
  body              TEXT,
  author            TEXT NOT NULL DEFAULT 'ai',   -- ai | user
  user_edited       INTEGER NOT NULL DEFAULT 0,
  status            TEXT NOT NULL DEFAULT 'open', -- open|explored|pruned|merged|final
  ai_thoughts_json  TEXT,                  -- {text,reasoning,plan,criticism,speak}
  ai_suggestions_json TEXT NOT NULL DEFAULT '[]',
  paper_filter_json TEXT NOT NULL DEFAULT '[]',   -- 关联论文 id 列表
  score             REAL,
  sort_order        INTEGER NOT NULL DEFAULT 0,
  conversation_id   TEXT,
  idea_id           TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_rq_tree ON rq_node(project_id, root_id, path);

-- ============================================================
-- 创新点
-- ============================================================
CREATE TABLE IF NOT EXISTS idea (
  id                TEXT PRIMARY KEY,
  project_id        TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  rq_node_id        TEXT REFERENCES rq_node(id) ON DELETE SET NULL,
  parent_idea_id    TEXT REFERENCES idea(id) ON DELETE SET NULL,
  generation        INTEGER NOT NULL DEFAULT 0,
  strategy          TEXT,                  -- limitation_cluster|contradiction|combination|transfer|assumption|user
  title             TEXT NOT NULL,
  one_liner         TEXT,
  problem           TEXT,
  gap               TEXT,
  method_sketch     TEXT,
  why_novel         TEXT,
  risks             TEXT,
  feasibility       REAL,
  impact            REAL,
  elo               REAL NOT NULL DEFAULT 1500,
  matches           INTEGER NOT NULL DEFAULT 0,
  wins              REAL NOT NULL DEFAULT 0,
  losses            REAL NOT NULL DEFAULT 0,
  novelty_status    TEXT NOT NULL DEFAULT 'unchecked', -- unchecked|novel|partial|done
  novelty_report_json TEXT,
  status            TEXT NOT NULL DEFAULT 'draft',     -- draft|candidate|finalist|archived
  created_by        TEXT NOT NULL DEFAULT 'ai',
  created_at        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_idea_elo ON idea(project_id, elo DESC);

CREATE TABLE IF NOT EXISTS idea_evidence (
  idea_id   TEXT NOT NULL REFERENCES idea(id) ON DELETE CASCADE,
  paper_id  TEXT NOT NULL REFERENCES paper(id) ON DELETE CASCADE,
  rel       TEXT NOT NULL,                 -- supports|contradicts|inspires|overlaps
  quote     TEXT,
  PRIMARY KEY (idea_id, paper_id, rel)
);

CREATE TABLE IF NOT EXISTS idea_comparison (
  id          TEXT PRIMARY KEY,
  project_id  TEXT NOT NULL,
  round       INTEGER NOT NULL,
  idea_a      TEXT NOT NULL,
  idea_b      TEXT NOT NULL,
  winner      TEXT,                        -- a | b | tie
  judge_model TEXT,
  rubric_json TEXT,
  rationale   TEXT,
  swapped     INTEGER NOT NULL DEFAULT 0,  -- 是否为换位复核
  elo_a_before REAL, elo_a_after REAL,
  elo_b_before REAL, elo_b_after REAL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  UNIQUE (round, idea_a, idea_b, swapped)
);

-- ============================================================
-- 对话
-- ============================================================
CREATE TABLE IF NOT EXISTS conversation (
  id          TEXT PRIMARY KEY,
  project_id  TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  rq_node_id  TEXT,
  title       TEXT,
  mode        TEXT NOT NULL DEFAULT 'divergent',  -- FSM 当前状态
  state_json  TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_conv_project ON conversation(project_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS message (
  id              TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL REFERENCES conversation(id) ON DELETE CASCADE,
  role            TEXT NOT NULL,           -- user | assistant | system
  content         TEXT,
  content_json    TEXT,                    -- cards / canvas_ops / thoughts
  model           TEXT,
  tokens_in       INTEGER NOT NULL DEFAULT 0,
  tokens_out      INTEGER NOT NULL DEFAULT 0,
  cost_cny        REAL NOT NULL DEFAULT 0,
  latency_ms      INTEGER,
  created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_msg ON message(conversation_id, created_at);

-- ============================================================
-- 监控主题与扫描（按需触发）
-- ============================================================
CREATE TABLE IF NOT EXISTS watch_topic (
  id              TEXT PRIMARY KEY,
  project_id      TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  query           TEXT NOT NULL,                -- 自然语言主题（中文可）
  keywords_json   TEXT NOT NULL DEFAULT '[]',   -- 英文关注词
  exclude_json    TEXT NOT NULL DEFAULT '[]',
  sources_json    TEXT NOT NULL DEFAULT '["arxiv","openalex"]',
  arxiv_cats_json TEXT NOT NULL DEFAULT '[]',   -- ["cs.CL","cs.AI"]
  enabled         INTEGER NOT NULL DEFAULT 0,   -- 主开关，默认关
  auto_patrol     INTEGER NOT NULL DEFAULT 0,   -- 自动巡检，默认关
  patrol_freq     TEXT NOT NULL DEFAULT 'weekly',
  last_scan_at    TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS scan_run (
  id            TEXT PRIMARY KEY,
  project_id    TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  watch_topic_id TEXT REFERENCES watch_topic(id) ON DELETE CASCADE,
  window_start  TEXT NOT NULL,              -- ISO date
  window_end    TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'queued',  -- queued|fetching|ranking|reading|reporting|done|failed
  progress      REAL NOT NULL DEFAULT 0,
  step          TEXT,
  items_found   INTEGER NOT NULL DEFAULT 0,
  items_new     INTEGER NOT NULL DEFAULT 0,
  items_read    INTEGER NOT NULL DEFAULT 0,
  report_path   TEXT,
  cost_cny      REAL NOT NULL DEFAULT 0,
  error         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  finished_at   TEXT
);
CREATE INDEX IF NOT EXISTS ix_scan ON scan_run(project_id, created_at DESC);

-- ============================================================
-- 任务、成本、通知
-- ============================================================
CREATE TABLE IF NOT EXISTS job (
  id            TEXT PRIMARY KEY,
  project_id    TEXT,
  type          TEXT NOT NULL,
  payload_json  TEXT,
  status        TEXT NOT NULL DEFAULT 'queued', -- queued|running|done|failed|cancelled
  progress      REAL NOT NULL DEFAULT 0,
  step          TEXT,
  result_json   TEXT,
  error         TEXT,
  attempts      INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  started_at    TEXT,
  finished_at   TEXT
);
CREATE INDEX IF NOT EXISTS ix_job_status ON job(status, created_at DESC);

CREATE TABLE IF NOT EXISTS llm_call_log (
  id            TEXT PRIMARY KEY,
  project_id    TEXT,
  job_id        TEXT,
  purpose       TEXT NOT NULL,             -- understand|rerank|gap|idea|novelty|elo|chat|translate
  model         TEXT,
  prompt_hash   TEXT,
  input_tokens  INTEGER NOT NULL DEFAULT 0,
  cached_tokens INTEGER NOT NULL DEFAULT 0,
  output_tokens INTEGER NOT NULL DEFAULT 0,
  cost_cny      REAL NOT NULL DEFAULT 0,
  latency_ms    INTEGER,
  cache_hit     INTEGER NOT NULL DEFAULT 0,
  ok            INTEGER NOT NULL DEFAULT 1,
  error         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_llm_cost ON llm_call_log(created_at);

CREATE TABLE IF NOT EXISTS notification (
  id            TEXT PRIMARY KEY,
  project_id    TEXT,
  kind          TEXT NOT NULL,             -- scan_done|job_failed|budget
  title         TEXT NOT NULL,
  body          TEXT,
  payload_json  TEXT,
  read          INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_notif ON notification(read, created_at DESC);

-- ============================================================
-- 本地论文（用户指定文件夹）
-- ============================================================
CREATE TABLE IF NOT EXISTS local_doc (
  id            TEXT PRIMARY KEY,
  project_id    TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  rel_path      TEXT NOT NULL,              -- 相对挂载根目录
  abs_path      TEXT NOT NULL,
  file_name     TEXT NOT NULL,
  ext           TEXT,
  size_bytes    INTEGER NOT NULL DEFAULT 0,
  sha256        TEXT NOT NULL,
  pages         INTEGER NOT NULL DEFAULT 0,
  chars         INTEGER NOT NULL DEFAULT 0,
  title         TEXT,
  paper_id      TEXT REFERENCES paper(id) ON DELETE SET NULL,
  status        TEXT NOT NULL DEFAULT 'new',  -- new|extracted|failed
  error         TEXT,
  sections_json TEXT NOT NULL DEFAULT '[]',
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  UNIQUE (project_id, sha256)
);
CREATE INDEX IF NOT EXISTS ix_local_doc ON local_doc(project_id, status);

-- 跨论文大纲（每次生成一条，可回看历史）
CREATE TABLE IF NOT EXISTS outline (
  id            TEXT PRIMARY KEY,
  project_id    TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  kind          TEXT NOT NULL DEFAULT 'outline',   -- outline | discussion
  title         TEXT,
  body_json     TEXT NOT NULL DEFAULT '{}',
  source_docs_json TEXT NOT NULL DEFAULT '[]',
  model         TEXT,
  cost_cny      REAL NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_outline ON outline(project_id, created_at DESC);

-- ============================================================
-- 来源取数留痕
-- ============================================================
CREATE TABLE IF NOT EXISTS fetch_log (
  id            TEXT PRIMARY KEY,
  project_id    TEXT,
  watch_topic_id TEXT,
  scan_run_id   TEXT,
  source        TEXT NOT NULL,
  query         TEXT,
  started_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  finished_at   TEXT,
  status        TEXT,
  http_status   INTEGER,
  items_found   INTEGER NOT NULL DEFAULT 0,
  items_new     INTEGER NOT NULL DEFAULT 0,
  cost_usd      REAL NOT NULL DEFAULT 0,
  error         TEXT
);

-- ============================================================
-- P2 图谱与 Gap
-- ============================================================
-- 图谱边统一放 paper_relation，rel 取值：
--   cites        直接引用（A 的参考文献里出现 B）
--   coupling     引用耦合（A、B 共同引用同一批工作，说明同一条技术脉络）
--   similar      语义相似（TF-IDF 余弦）
--   same_concept 共享概念（数量 / 权重）

-- 研究空白：由四种策略挖出来，每条都要能追到具体证据
CREATE TABLE IF NOT EXISTS gap (
  id              TEXT PRIMARY KEY,
  project_id      TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  strategy        TEXT NOT NULL,           -- limitation_cluster | contradiction | combination | transfer
  title           TEXT NOT NULL,
  statement       TEXT NOT NULL,           -- 一句话说清「缺什么」
  detail          TEXT,                    -- 展开：为什么是空白、怎么验证
  support_json    TEXT NOT NULL DEFAULT '[]',  -- [{paper_id, claim_id, quote, note}]
  concept_ids_json TEXT NOT NULL DEFAULT '[]',
  paper_count     INTEGER NOT NULL DEFAULT 0,  -- 支撑这个 gap 的论文数
  strength        REAL NOT NULL DEFAULT 0.5,   -- 证据强度 0~1
  verdict         TEXT,                    -- ai 判断：real_gap | weak | solved
  created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_gap ON gap(project_id, strategy, created_at DESC);

-- 图谱构建留痕（哪一层什么时候建的、花了多少）
CREATE TABLE IF NOT EXISTS graph_run (
  id          TEXT PRIMARY KEY,
  project_id  TEXT NOT NULL,
  layers_json TEXT NOT NULL DEFAULT '[]',
  nodes       INTEGER NOT NULL DEFAULT 0,
  edges_json  TEXT NOT NULL DEFAULT '{}',
  cost_cny    REAL NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- P3 共创对话
CREATE INDEX IF NOT EXISTS ix_rq_node_conv ON rq_node(conversation_id, depth);
CREATE INDEX IF NOT EXISTS ix_rq_node_project ON rq_node(project_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_message_conv ON message(conversation_id, created_at);
CREATE INDEX IF NOT EXISTS ix_conversation_project ON conversation(project_id, updated_at DESC);

-- ============================================================
-- 调研批次：同一项目里每调研一个方向，就开一个新批次
-- 论文通过 paper.batch_id 归到批次下，界面上可以按批次分开看
-- ============================================================
CREATE TABLE IF NOT EXISTS search_batch (
  id          TEXT PRIMARY KEY,
  project_id  TEXT NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  label       TEXT NOT NULL,           -- 用户看到的块名（默认取查询前 30 字，可改）
  query       TEXT NOT NULL DEFAULT '',-- 实际用的检索主题
  date_from   TEXT,                    -- 这次调研限定的时间范围（可空）
  date_to     TEXT,
  inserted    INTEGER NOT NULL DEFAULT 0,  -- 这一批新入库多少篇
  cost_cny    REAL NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS ix_batch ON search_batch(project_id, created_at DESC);
-- 注意：paper.batch_id 是 _EXTRA_COLUMNS 补的列，索引放到 db.py 的 _ensure_columns 里建，
-- 否则老库启动时这里会因「no such column」整段 executescript 失败
