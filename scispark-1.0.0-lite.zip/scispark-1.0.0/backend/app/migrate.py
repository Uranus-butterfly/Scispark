"""建表 / 迁移 / 重建索引。

用法（容器内）：
    python -m app.migrate            # 建表 + 补迁移
    python -m app.migrate --rebuild-fts
    python -m app.migrate --stats
"""

from __future__ import annotations

import sys

from .db import db_stats, fts_rebuild, get_conn, init_db
from .config import settings


def main() -> int:
    args = set(sys.argv[1:])
    settings.ensure_dirs()
    init_db()
    print(f"✓ 数据库就绪: {settings.db_file}")

    if "--rebuild-fts" in args:
        n = fts_rebuild()
        print(f"✓ 重建 FTS 索引: {n} 篇")

    if "--stats" in args or not args:
        s = db_stats()
        print(f"✓ 文件大小: {s['db_bytes'] / 1024:.1f} KB")
        nonempty = {k: v for k, v in s["tables"].items() if v > 0}
        print(f"✓ 非空表: {nonempty or '（全部为空）'}")

    # 自检：FTS5 是否可用
    try:
        get_conn().execute("SELECT count(*) FROM paper_fts").fetchone()
        print("✓ FTS5 可用")
    except Exception as e:  # noqa: BLE001
        print(f"✗ FTS5 不可用: {e}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
