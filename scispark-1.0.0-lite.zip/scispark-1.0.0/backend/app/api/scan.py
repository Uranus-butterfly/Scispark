"""进展扫描：开关 + 时间窗 + 简报。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..db import query_one
from ..services import scan as scan_service

router = APIRouter(prefix="/api/projects/{project_id}/scan", tags=["scan"])


class TopicBody(BaseModel):
    enabled: bool | None = None
    query: str | None = None


class ScanBody(BaseModel):
    window: str | None = Field(default="month", description="week|month|quarter|half_year|year")
    date_from: str | None = None
    date_to: str | None = None
    max_read: int = Field(default=20, ge=5, le=40)


def _check_project(project_id: str) -> None:
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")


@router.get("")
def get_scan(project_id: str):
    _check_project(project_id)
    return scan_service.topic_view(project_id)


@router.put("/topic")
def update_topic(project_id: str, body: TopicBody):
    _check_project(project_id)
    return scan_service.update_topic(
        project_id, enabled=body.enabled, query_text=body.query
    )


@router.post("/run")
async def run_scan(project_id: str, body: ScanBody | None = None):
    _check_project(project_id)
    body = body or ScanBody()
    try:
        job_id = scan_service.start_scan(
            project_id,
            window=body.window,
            date_from=body.date_from,
            date_to=body.date_to,
            max_read=body.max_read,
        )
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    return {"job_id": job_id}


@router.get("/report/{run_id}")
def get_report(project_id: str, run_id: str):
    _check_project(project_id)
    row = query_one(
        "SELECT * FROM scan_run WHERE id = ? AND project_id = ?", (run_id, project_id)
    )
    if row is None:
        raise HTTPException(404, "扫描记录不存在")
    return scan_service._parse_report(row["report_json"])
