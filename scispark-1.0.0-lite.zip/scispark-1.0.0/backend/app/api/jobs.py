"""任务进度查询。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ..workers.queue import get_job
from ..db import query

router = APIRouter(prefix="/api/jobs", tags=["jobs"])


@router.get("/{job_id}")
def job_status(job_id: str):
    job = get_job(job_id)
    if job is None:
        raise HTTPException(404, "任务不存在")
    return job


@router.get("")
def list_jobs(project_id: str | None = None, limit: int = 20):
    if project_id:
        rows = query(
            "SELECT id, type, status, progress, step, error, created_at, finished_at"
            " FROM job WHERE project_id = ? ORDER BY created_at DESC LIMIT ?",
            (project_id, min(limit, 100)),
        )
    else:
        rows = query(
            "SELECT id, type, status, progress, step, error, created_at, finished_at"
            " FROM job ORDER BY created_at DESC LIMIT ?",
            (min(limit, 100),),
        )
    return [dict(r) for r in rows]
