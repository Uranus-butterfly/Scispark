"""论文库：列表、详情、触发调研与理解。"""

from __future__ import annotations

import json

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..db import execute, fts_search, query, query_one, row_to_dict
from ..services import batches as batch_service
from ..services import ingest as ingest_service

router = APIRouter(prefix="/api", tags=["papers"])


class IngestBody(BaseModel):
    query: str | None = None
    max_papers: int = Field(default=60, ge=5, le=300)
    understand: bool = True
    date_from: str | None = None
    date_to: str | None = None
    # 这一批叫什么（留空就用检索主题当名字）
    batch_label: str | None = Field(default=None, max_length=40)


class BatchRenameBody(BaseModel):
    label: str = Field(min_length=1, max_length=40)


class UnderstandBody(BaseModel):
    limit: int | None = Field(default=None, ge=1, le=500)
    paper_ids: list[str] | None = None


class VenuePrefsBody(BaseModel):
    preferred: list[str] = Field(default_factory=list, max_length=20)
    journals_only: bool = False
    min_citations: int = Field(default=0, ge=0, le=10000)



def _insight_brief(paper_id: str) -> dict | None:
    row = query_one(
        "SELECT problem, method, limitations_json, concepts_json, quality"
        " FROM paper_insight WHERE paper_id = ? ORDER BY schema_version DESC LIMIT 1",
        (paper_id,),
    )
    if row is None:
        return None
    return {
        "problem": row["problem"],
        "method": row["method"],
        "limitations": json.loads(row["limitations_json"] or "[]"),
        "concepts": json.loads(row["concepts_json"] or "[]"),
        "quality": row["quality"],
    }


def _match_batch(batch_id: str | None, want: str) -> bool:
    if want == "__none__":
        return not batch_id
    return batch_id == want


@router.get("/projects/{project_id}/papers")
def list_papers(
    project_id: str,
    q: str | None = None,
    status: str | None = None,
    venue: str | None = None,
    batch: str | None = None,
    sort: str = "relevance",
    limit: int = 60,
    offset: int = 0,
):
    """列表。q 存在时走 FTS5 检索，否则按 sort 排序。

    batch 传批次 id 只看那一批；传 `__none__` 只看没批次的（本地导入 / 早期数据）。
    """
    limit = max(1, min(limit, 300))

    if q:
        hits = fts_search(q, limit=limit, project_id=project_id)
        ids = [h["paper_id"] for h in hits]
        if not ids:
            return {"total": 0, "items": []}
        ph = ",".join("?" * len(ids))
        rows = query(f"SELECT * FROM paper WHERE id IN ({ph})", ids)
        if batch:
            rows = [r for r in rows if _match_batch(r["batch_id"], batch)]
        order = {pid: i for i, pid in enumerate(ids)}
        rows = sorted(rows, key=lambda r: order.get(r["id"], 999))
        total = len(rows)
    else:
        where = ["project_id = ?"]
        params: list = [project_id]
        if status:
            where.append("status = ?")
            params.append(status)
        if venue:
            if venue == "__none__":
                where.append("(venue IS NULL OR venue = '')")
            else:
                where.append("venue = ?")
                params.append(venue)
        if batch:
            if batch == "__none__":
                where.append("batch_id IS NULL")
            else:
                where.append("batch_id = ?")
                params.append(batch)
        w = " AND ".join(where)
        total = query_one(f"SELECT COUNT(*) AS c FROM paper WHERE {w}", params)["c"]
        order_sql = {
            "relevance": "relevance DESC NULLS LAST, citation_count DESC",
            "date": "published_at DESC NULLS LAST",
            "citations": "citation_count DESC",
            "title": "title ASC",
        }.get(sort, "relevance DESC NULLS LAST")
        rows = query(
            f"SELECT * FROM paper WHERE {w} ORDER BY {order_sql} LIMIT ? OFFSET ?",
            (*params, limit, offset),
        )

    items = []
    for r in rows:
        d = row_to_dict(r, json_fields=("authors_json",))
        d["authors"] = d.pop("authors_json", [])
        d.pop("raw_json", None)
        d["insight"] = _insight_brief(r["id"])
        items.append(d)
    return {"total": total, "items": items}


@router.get("/projects/{project_id}/batches")
def list_batches(project_id: str):
    """调研批次清单。每调研一个方向就是一批，界面上按这个分块。"""
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")
    return batch_service.list_for(project_id)


@router.patch("/projects/{project_id}/batches/{batch_id}")
def rename_batch(project_id: str, batch_id: str, body: BatchRenameBody):
    try:
        return batch_service.rename(project_id, batch_id, body.label)
    except ValueError as e:
        raise HTTPException(404 if "不存在" in str(e) else 400, str(e)) from e


@router.delete("/projects/{project_id}/batches/{batch_id}")
def delete_batch(project_id: str, batch_id: str):
    """删掉一批（连同这批的论文）。界面要二次确认。"""
    try:
        return batch_service.remove(project_id, batch_id)
    except ValueError as e:
        raise HTTPException(404, str(e)) from e


@router.get("/projects/{project_id}/papers/venues")
def list_venues(project_id: str, limit: int = 60):
    """按篇数排的期刊/会议清单，给筛选下拉用。"""
    rows = query(
        "SELECT venue, COUNT(*) AS c FROM paper WHERE project_id = ?"
        " AND venue IS NOT NULL AND venue != '' GROUP BY venue ORDER BY c DESC LIMIT ?",
        (project_id, max(1, min(limit, 200))),
    )
    empty = query_one(
        "SELECT COUNT(*) AS c FROM paper WHERE project_id = ?"
        " AND (venue IS NULL OR venue = '')",
        (project_id,),
    )
    return {
        "items": [{"venue": r["venue"], "count": r["c"]} for r in rows],
        "unlabeled": empty["c"] if empty else 0,
    }


@router.get("/projects/{project_id}/venue-prefs")
def get_venue_prefs(project_id: str):
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")
    return ingest_service.load_venue_prefs(project_id)


@router.put("/projects/{project_id}/venue-prefs")
def put_venue_prefs(project_id: str, body: VenuePrefsBody):
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")
    return ingest_service.save_venue_prefs(project_id, body.model_dump())


@router.post("/projects/{project_id}/papers/retry-understanding")
async def retry_understanding(project_id: str):
    """把 skipped / failed 的论文重置成 new，再跑一遍理解。

    没摘要的那种重跑也没用，但可能有 TLDR 兜底或者用户就是想再试一次——
    重跑一次成本很低（每篇几厘钱），比让用户猜「为什么一直是待理解」好。
    """
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")

    rows = query(
        "SELECT id FROM paper WHERE project_id = ? AND status IN ('skipped','failed')",
        (project_id,),
    )
    ids = [r["id"] for r in rows]
    if not ids:
        return {"job_id": None, "count": 0}

    execute(
        "UPDATE paper SET status = 'new', status_reason = NULL"
        " WHERE project_id = ? AND status IN ('skipped','failed')",
        (project_id,),
    )
    job_id = ingest_service.start_understand(project_id, paper_ids=ids)
    return {"job_id": job_id, "count": len(ids)}


@router.get("/projects/{project_id}/papers/stats")
def paper_stats(project_id: str):
    rows = query(
        "SELECT status, COUNT(*) AS c FROM paper WHERE project_id = ? GROUP BY status",
        (project_id,),
    )
    by_status = {r["status"]: r["c"] for r in rows}
    total = sum(by_status.values())
    concepts = query_one(
        "SELECT COUNT(*) AS c FROM concept WHERE project_id = ?", (project_id,)
    )["c"]
    return {
        "total": total,
        "by_status": by_status,
        "understood": by_status.get("understood", 0),
        "concepts": concepts,
    }


@router.get("/papers/{paper_id}")
def get_paper(paper_id: str):
    row = query_one("SELECT * FROM paper WHERE id = ?", (paper_id,))
    if row is None:
        raise HTTPException(404, "论文不存在")
    d = row_to_dict(row, json_fields=("authors_json", "raw_json"))
    d["authors"] = d.pop("authors_json", [])

    ins = query_one(
        "SELECT * FROM paper_insight WHERE paper_id = ? ORDER BY schema_version DESC LIMIT 1",
        (paper_id,),
    )
    insight = None
    if ins:
        insight = row_to_dict(
            ins,
            json_fields=(
                "datasets_json", "findings_json", "limitations_json",
                "key_claims_json", "concepts_json",
            ),
        )
        for a, b in (
            ("datasets_json", "datasets"),
            ("findings_json", "findings"),
            ("limitations_json", "limitations"),
            ("key_claims_json", "key_claims"),
            ("concepts_json", "concepts"),
        ):
            insight[b] = insight.pop(a, [])

    claims = [
        dict(r)
        for r in query(
            "SELECT text, claim_type, polarity, quote FROM claim WHERE paper_id = ?",
            (paper_id,),
        )
    ]
    d["insight"] = insight
    d["claims"] = claims
    return d


@router.post("/projects/{project_id}/ingest")
async def start_ingest(project_id: str, body: IngestBody):
    proj = query_one("SELECT id, topic FROM project WHERE id = ?", (project_id,))
    if proj is None:
        raise HTTPException(404, "项目不存在")
    query_text = (body.query or proj["topic"] or "").strip()
    if not query_text:
        raise HTTPException(400, "缺少检索主题")
    job_id = ingest_service.start_ingest(
        project_id,
        query=query_text,
        max_papers=body.max_papers,
        understand=body.understand,
        date_from=body.date_from,
        date_to=body.date_to,
        batch_label=body.batch_label,
    )
    return {"job_id": job_id}


@router.post("/projects/{project_id}/understand")
async def start_understand(project_id: str, body: UnderstandBody):
    job_id = ingest_service.start_understand(
        project_id, limit=body.limit, paper_ids=body.paper_ids
    )
    return {"job_id": job_id}
