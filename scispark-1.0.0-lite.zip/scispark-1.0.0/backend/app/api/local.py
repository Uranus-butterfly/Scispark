"""本地论文：目录选择、浏览、导入、大纲、创新点讨论。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..db import query_one
from ..services import host_fs, local_papers

router = APIRouter(prefix="/api/projects/{project_id}/local", tags=["local"])


class ImportBody(BaseModel):
    paths: list[str] = Field(min_length=1, max_length=60)


class OutlineBody(BaseModel):
    doc_ids: list[str] | None = None


class DiscussBody(BaseModel):
    outline_id: str | None = None


class RootBody(BaseModel):
    path: str


def _check_project(project_id: str) -> None:
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")


# ----------------------------------------------------------------------
# 目录选择（界面里的文件夹选择器）
# ----------------------------------------------------------------------
@router.get("/root")
def get_root(project_id: str):
    _check_project(project_id)
    return host_fs.root_info()


@router.put("/root")
def set_root(project_id: str, body: RootBody):
    _check_project(project_id)
    try:
        host_fs.set_root(body.path)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    return host_fs.root_info()


@router.get("/pick")
def pick(project_id: str, path: str = ""):
    """文件夹选择器用：只列子目录，顺带统计每个目录里有多少篇论文。"""
    _check_project(project_id)
    try:
        return host_fs.browse(path or None)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


# ----------------------------------------------------------------------
# 浏览 + 导入
# ----------------------------------------------------------------------
@router.get("/browse")
def browse(project_id: str, path: str = ""):
    _check_project(project_id)
    try:
        return local_papers.browse(path or None)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@router.get("/docs")
def list_docs(project_id: str):
    _check_project(project_id)
    return local_papers.list_docs(project_id)


@router.post("/import")
async def start_import(project_id: str, body: ImportBody):
    _check_project(project_id)
    job_id = local_papers.start_import(project_id, body.paths)
    return {"job_id": job_id}


@router.post("/outline")
async def start_outline(project_id: str, body: OutlineBody):
    _check_project(project_id)
    job_id = local_papers.start_outline(project_id, body.doc_ids)
    return {"job_id": job_id}


@router.get("/outline")
def get_outline(project_id: str):
    _check_project(project_id)
    return local_papers.latest_outline(project_id)


@router.post("/discuss")
async def start_discuss(project_id: str, body: DiscussBody):
    _check_project(project_id)
    job_id = local_papers.start_discuss(project_id, body.outline_id)
    return {"job_id": job_id}


@router.get("/discussion")
def get_discussion(project_id: str):
    _check_project(project_id)
    return local_papers.latest_discussion(project_id)


@router.delete("/docs/{doc_id}")
def delete_doc(project_id: str, doc_id: str):
    _check_project(project_id)
    try:
        local_papers.delete_doc(project_id, doc_id)
    except ValueError as e:
        raise HTTPException(404, str(e)) from e
    return {"ok": True}
