"""共创对话：一轮一轮把方向收敛成研究问题。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..db import query_one
from ..services import chat as chat_service

router = APIRouter(prefix="/api/projects/{project_id}/chat", tags=["chat"])


class StartBody(BaseModel):
    topic: str | None = None


class TurnBody(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


def _check_project(project_id: str) -> None:
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")


def _check_conv(project_id: str, conversation_id: str) -> None:
    if (
        query_one(
            "SELECT id FROM conversation WHERE id = ? AND project_id = ?",
            (conversation_id, project_id),
        )
        is None
    ):
        raise HTTPException(404, "对话不存在")


@router.get("")
def latest(project_id: str):
    _check_project(project_id)
    return chat_service.latest(project_id)


@router.post("/start")
async def start(project_id: str, body: StartBody | None = None):
    _check_project(project_id)
    try:
        return await chat_service.start(project_id, body.topic if body else None)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@router.get("/{conversation_id}")
def get_conversation(project_id: str, conversation_id: str):
    _check_project(project_id)
    view = chat_service.conversation_view(conversation_id)
    if view is None:
        raise HTTPException(404, "对话不存在")
    return view


@router.post("/{conversation_id}/turn")
async def turn(project_id: str, conversation_id: str, body: TurnBody):
    _check_project(project_id)
    _check_conv(project_id, conversation_id)
    try:
        return await chat_service.turn(project_id, conversation_id, body.text)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
