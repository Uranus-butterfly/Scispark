"""创新点：Elo 排行、两两对比、提案导出。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..db import query_one
from ..services import ideas as ideas_service
from ..workers import queue

router = APIRouter(prefix="/api/projects/{project_id}/ideas", tags=["ideas"])


class TournamentBody(BaseModel):
    rounds: int = Field(default=1, ge=1, le=3)


class ProposalBody(BaseModel):
    idea_id: str


def _check_project(project_id: str) -> None:
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")


@router.get("")
def list_ideas(project_id: str):
    _check_project(project_id)
    return ideas_service.list_ideas(project_id)


@router.get("/{idea_id}")
def get_idea(project_id: str, idea_id: str):
    _check_project(project_id)
    d = ideas_service.idea_detail(project_id, idea_id)
    if d is None:
        raise HTTPException(404, "想法不存在")
    return d


@router.post("/tournament")
async def tournament(project_id: str, body: TournamentBody | None = None):
    _check_project(project_id)
    body = body or TournamentBody()
    job_id = queue.submit(
        "idea_tournament",
        project_id,
        {"project_id": project_id, "rounds": body.rounds},
        ideas_service.run_tournament,
    )
    return {"job_id": job_id}


@router.post("/proposal")
async def proposal(project_id: str, body: ProposalBody):
    _check_project(project_id)
    if query_one(
        "SELECT id FROM idea WHERE id = ? AND project_id = ?", (body.idea_id, project_id)
    ) is None:
        raise HTTPException(404, "想法不存在")
    job_id = queue.submit(
        "idea_proposal",
        project_id,
        {"project_id": project_id, "idea_id": body.idea_id},
        ideas_service.generate_proposal,
    )
    return {"job_id": job_id}
