"""项目 CRUD。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ..db import execute, new_id, query, query_one, row_to_dict
from ..models.common import ProjectCreate, ProjectOut, ProjectUpdate

router = APIRouter(prefix="/api/projects", tags=["projects"])


def _stats(project_id: str) -> dict:
    def cnt(sql: str) -> int:
        r = query_one(sql, (project_id,))
        return int(r[0]) if r else 0

    return {
        "paper_count": cnt("SELECT COUNT(*) FROM paper WHERE project_id = ?"),
        "idea_count": cnt("SELECT COUNT(*) FROM idea WHERE project_id = ?"),
        "rq_count": cnt("SELECT COUNT(*) FROM rq_node WHERE project_id = ?"),
    }


def _to_out(row) -> ProjectOut:
    d = dict(row)
    d.update(_stats(d["id"]))
    return ProjectOut(**d)


@router.get("", response_model=list[ProjectOut])
def list_projects(status: str | None = None):
    sql = "SELECT * FROM project"
    params: list = []
    if status:
        sql += " WHERE status = ?"
        params.append(status)
    sql += " ORDER BY updated_at DESC"
    return [_to_out(r) for r in query(sql, params)]


@router.post("", response_model=ProjectOut, status_code=201)
def create_project(body: ProjectCreate):
    pid = new_id()
    execute(
        "INSERT INTO project(id, name, name_en, topic, description) VALUES (?,?,?,?,?)",
        (
            pid,
            body.name.strip(),
            (body.name_en or "").strip() or None,
            body.topic.strip(),
            (body.description or "").strip() or None,
        ),
    )
    row = query_one("SELECT * FROM project WHERE id = ?", (pid,))
    return _to_out(row)


@router.get("/{project_id}", response_model=ProjectOut)
def get_project(project_id: str):
    row = query_one("SELECT * FROM project WHERE id = ?", (project_id,))
    if row is None:
        raise HTTPException(404, "项目不存在")
    return _to_out(row)


@router.patch("/{project_id}", response_model=ProjectOut)
def update_project(project_id: str, body: ProjectUpdate):
    row = query_one("SELECT * FROM project WHERE id = ?", (project_id,))
    if row is None:
        raise HTTPException(404, "项目不存在")
    fields = {k: v for k, v in body.model_dump(exclude_none=True).items()}
    if fields:
        sets = ", ".join(f"{k} = ?" for k in fields)
        execute(
            f"UPDATE project SET {sets}, updated_at = datetime('now','localtime') WHERE id = ?",
            (*fields.values(), project_id),
        )
    return _to_out(query_one("SELECT * FROM project WHERE id = ?", (project_id,)))


@router.delete("/{project_id}")
def delete_project(project_id: str):
    row = query_one("SELECT id FROM project WHERE id = ?", (project_id,))
    if row is None:
        raise HTTPException(404, "项目不存在")
    execute("DELETE FROM project WHERE id = ?", (project_id,))
    return {"ok": True}
