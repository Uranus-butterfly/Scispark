"""图谱、Gap、新颖性查重。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..db import query_one
from ..services import gaps as gaps_service
from ..services import graph as graph_service
from ..services import novelty as novelty_service
from ..workers import queue

router = APIRouter(prefix="/api/projects/{project_id}", tags=["graph"])


class BuildBody(BaseModel):
    layers: list[str] | None = None


class MineBody(BaseModel):
    pass


class NoveltyBody(BaseModel):
    idea_id: str
    live: bool = False


def _check_project(project_id: str) -> None:
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")


# ----------------------------------------------------------------------
# 图谱
# ----------------------------------------------------------------------
@router.get("/graph")
def get_graph(project_id: str, layers: str | None = None, limit: int = 600):
    _check_project(project_id)
    sel = [x for x in (layers or "").split(",") if x] or None
    return graph_service.snapshot(project_id, layers=sel, limit=min(limit, 2000))


@router.post("/graph/build")
async def build_graph(project_id: str, body: BuildBody | None = None):
    _check_project(project_id)
    layers = body.layers if body else None
    job_id = queue.submit(
        "graph_build",
        project_id,
        {"project_id": project_id, "layers": layers},
        graph_service.run_build,
    )
    return {"job_id": job_id}


@router.get("/graph/neighbors/{paper_id}")
def get_neighbors(project_id: str, paper_id: str):
    _check_project(project_id)
    return graph_service.neighbors(project_id, paper_id)


# ----------------------------------------------------------------------
# Gap
# ----------------------------------------------------------------------
@router.get("/gaps")
def list_gaps(project_id: str, strategy: str | None = None):
    _check_project(project_id)
    return gaps_service.list_gaps(project_id, strategy)


@router.post("/gaps/mine")
async def mine_gaps(project_id: str):
    _check_project(project_id)
    job_id = queue.submit(
        "gap_mine", project_id, {"project_id": project_id}, gaps_service.run_mine
    )
    return {"job_id": job_id}


@router.delete("/gaps/{gap_id}")
def delete_gap(project_id: str, gap_id: str):
    _check_project(project_id)
    gaps_service.delete_gap(project_id, gap_id)
    return {"ok": True}


# ----------------------------------------------------------------------
# 新颖性查重
# ----------------------------------------------------------------------
@router.post("/novelty")
async def check_novelty(project_id: str, body: NoveltyBody):
    _check_project(project_id)
    if query_one("SELECT id FROM idea WHERE id = ? AND project_id = ?", (body.idea_id, project_id)) is None:
        raise HTTPException(404, "想法不存在")
    job_id = queue.submit(
        "novelty",
        project_id,
        {"project_id": project_id, "idea_id": body.idea_id, "live": body.live},
        novelty_service.run_check,
    )
    return {"job_id": job_id}
