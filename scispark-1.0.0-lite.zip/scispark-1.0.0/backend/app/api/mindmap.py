"""研究脑图 API。"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..db import query_one
from ..services import mindmap as mm

router = APIRouter(prefix="/api/projects/{project_id}/mindmap", tags=["mindmap"])


class CreateBody(BaseModel):
    title: str | None = None


class AddBody(BaseModel):
    parent_id: str
    title: str = Field(min_length=1, max_length=200)
    body: str = ""
    node_type: str = "rq"


class UpdateBody(BaseModel):
    title: str | None = None
    body: str | None = None
    status: str | None = None
    node_type: str | None = None
    pos_x: float | None = None
    pos_y: float | None = None


class ExpandBody(BaseModel):
    node_id: str
    mode: str = "explore"  # explore | ideas


def _check_project(project_id: str) -> None:
    if query_one("SELECT id FROM project WHERE id = ?", (project_id,)) is None:
        raise HTTPException(404, "项目不存在")


def _map_or_404(project_id: str):
    m = mm.get_map(project_id)
    if m is None:
        raise HTTPException(404, "还没有脑图")
    return m


@router.get("")
def get_map(project_id: str):
    _check_project(project_id)
    return mm.get_map(project_id)


@router.post("")
def create_map(project_id: str, body: CreateBody | None = None):
    _check_project(project_id)
    try:
        return mm.create_map(project_id, body.title if body else None)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/nodes")
def add_node(project_id: str, body: AddBody):
    _check_project(project_id)
    m = _map_or_404(project_id)
    try:
        mm.add_node(project_id, m["id"], body.parent_id, body.title, body.body, body.node_type)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    return mm.get_map(project_id)


@router.patch("/nodes/{node_id}")
def update_node(project_id: str, node_id: str, body: UpdateBody):
    _check_project(project_id)
    m = _map_or_404(project_id)
    try:
        mm.update_node(project_id, m["id"], node_id, **body.model_dump(exclude_none=True))
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    return mm.get_map(project_id)


@router.delete("/nodes/{node_id}")
def delete_node(project_id: str, node_id: str):
    _check_project(project_id)
    m = _map_or_404(project_id)
    try:
        mm.delete_node(project_id, m["id"], node_id)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    return mm.get_map(project_id)


@router.post("/expand")
async def expand(project_id: str, body: ExpandBody):
    _check_project(project_id)
    m = _map_or_404(project_id)
    try:
        return await mm.expand_node(project_id, m["id"], body.node_id, body.mode)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/seed")
async def seed(project_id: str):
    _check_project(project_id)
    m = _map_or_404(project_id)
    try:
        return await mm.seed(project_id, m["id"])
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
