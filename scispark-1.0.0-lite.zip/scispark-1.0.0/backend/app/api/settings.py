"""设置与成本。"""

from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel, Field

from ..config import settings
from ..llm import budget, cache, client, pricing
from ..models.common import OkOut, SettingsOut, SettingsUpdate
from ..services import settings_store

router = APIRouter(prefix="/api/settings", tags=["settings"])


class TestLlmBody(BaseModel):
    """测试连接时可以带上表单里还没保存的值，不写库。"""

    values: dict[str, str] = Field(default_factory=dict)


@router.get("", response_model=SettingsOut)
def read_settings():
    return SettingsOut(
        items=settings_store.public_view(),
        budget=budget.summary(),
        cache=cache.stats(),
        pricing={
            "peak": pricing.is_peak(),
            "hint": pricing.peak_hint(),
            "usd_to_cny": pricing.USD_TO_CNY,
            "models": {
                "flash": settings_store.effective_model("flash"),
                "pro": settings_store.effective_model("pro"),
            },
            "table": {
                m: {"cache_hit": v[0], "input": v[1], "output": v[2]}
                for m, v in pricing.PRICES.items()
            },
        },
    )


@router.put("", response_model=SettingsOut)
def write_settings(body: SettingsUpdate):
    settings_store.set_many(body.values)
    return read_settings()


@router.post("/test-llm", response_model=OkOut)
async def test_llm(body: TestLlmBody | None = None):
    """测试连通性。带上 values 时优先用表单里的值（临时覆盖，不写库）。"""
    with settings_store.temporary(body.values if body else None):
        res = await client.test_connection()
    return OkOut(ok=bool(res.get("ok")), message=res.get("message"), data=res)


@router.get("/cost")
def cost_summary():
    return {
        "budget": budget.summary(),
        "peak": pricing.is_peak(),
        "peak_hint": pricing.peak_hint(),
    }


@router.post("/cache/clear", response_model=OkOut)
def clear_cache():
    n = cache.clear()
    return OkOut(ok=True, message=f"已清除 {n} 条缓存", data={"cleared": n})


@router.get("/paths")
def paths():
    return {
        "data_dir": str(settings.data_path),
        "db": str(settings.db_file),
        "cache": str(settings.cache_dir),
        "reports": str(settings.reports_dir),
    }
