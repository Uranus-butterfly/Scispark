"""OpenAlex Works API。

无 key 时是「全网络共享 $0.10/天」，响应头 x-ratelimit-remaining-usd 会告诉你还剩多少。
免费 key（$1/天）可在设置页填。
"""

from __future__ import annotations

import logging

import httpx

from ..services import settings_store
from .base import PaperRecord
from .normalize import normalize_arxiv_id, normalize_doi, parse_date, reconstruct_abstract

log = logging.getLogger(__name__)

BASE = "https://api.openalex.org/works"
SELECT = (
    "id,doi,display_name,title,publication_year,publication_date,cited_by_count,"
    "abstract_inverted_index,authorships,primary_location,referenced_works,ids"
)
USER_AGENT = "SciSpark/0.1 (local research assistant; mailto:%s)"


def _parse_work(w: dict) -> PaperRecord | None:
    title = (w.get("title") or w.get("display_name") or "").strip()
    if not title:
        return None

    ids = w.get("ids") or {}
    doi = normalize_doi(w.get("doi") or ids.get("doi") or "")
    arxiv_id = ""
    if ids.get("mag"):
        pass
    landing = (w.get("primary_location") or {}).get("landing_page_url") or ""
    if "arxiv.org" in landing:
        arxiv_id = normalize_arxiv_id(landing)

    authors: list[str] = []
    for a in (w.get("authorships") or [])[:30]:
        nm = (a.get("author") or {}).get("display_name")
        if nm:
            authors.append(nm)

    src = (w.get("primary_location") or {}).get("source") or {}
    venue = src.get("display_name") or ""
    pdf_url = (w.get("primary_location") or {}).get("pdf_url") or ""

    published = parse_date(w.get("publication_date") or "")
    if not published and w.get("publication_year"):
        published = f"{w['publication_year']}-01-01"

    return PaperRecord(
        source="openalex",
        source_id=(w.get("id") or "").rsplit("/", 1)[-1],
        title=title,
        abstract=reconstruct_abstract(w.get("abstract_inverted_index")),
        authors=authors,
        year=w.get("publication_year"),
        venue=venue,
        url=w.get("id") or "",
        pdf_url=pdf_url,
        doi=doi,
        arxiv_id=arxiv_id,
        citation_count=int(w.get("cited_by_count") or 0),
        published_at=published,
        referenced_works=[
            r.rsplit("/", 1)[-1] for r in (w.get("referenced_works") or []) if r
        ],
        raw={"type": w.get("type")},
    )


async def search(
    phrases: list[str],
    per_query: int = 50,
    date_from: str | None = None,
    date_to: str | None = None,
) -> tuple[list[PaperRecord], dict]:
    out: list[PaperRecord] = []
    stats = {"requests": 0, "found": 0, "errors": [], "remaining_usd": None}

    api_key = (settings_store.get("openalex_api_key") or "").strip()
    mailto = (settings_store.get("openalex_mailto") or "").strip()

    base_params: dict[str, str] = {
        "select": SELECT,
        "per-page": str(min(per_query, 100)),
        "sort": "relevance_score:desc",
    }
    if api_key:
        base_params["api_key"] = api_key
    if mailto:
        base_params["mailto"] = mailto

    filters = []
    if date_from:
        filters.append(f"from_publication_date:{date_from}")
    if date_to:
        filters.append(f"to_publication_date:{date_to}")
    if filters:
        base_params["filter"] = ",".join(filters)

    ua = USER_AGENT % (mailto or "anonymous@example.com")

    async with httpx.AsyncClient(
        timeout=httpx.Timeout(45.0, connect=15.0),
        headers={"User-Agent": ua},
    ) as client:
        for phrase in phrases[:4]:
            params = {**base_params, "search": phrase}
            try:
                r = await client.get(BASE, params=params)
                stats["requests"] += 1
                rem = r.headers.get("x-ratelimit-remaining-usd")
                if rem:
                    stats["remaining_usd"] = rem
                if r.status_code == 429:
                    stats["errors"].append("OpenAlex 限流（配额用尽），可到设置页填免费 key")
                    break
                if r.status_code != 200:
                    stats["errors"].append(f"OpenAlex {r.status_code}")
                    continue
                data = r.json()
                for w in data.get("results") or []:
                    rec = _parse_work(w)
                    if rec:
                        out.append(rec)
                stats["found"] += len(data.get("results") or [])
            except httpx.HTTPError as e:
                stats["errors"].append(f"OpenAlex {type(e).__name__}")
                log.warning("OpenAlex 查询失败 %s: %s", phrase, e)

    return out, stats
