"""归一化、去重、候选排序。

去重策略（依次）：
1. DOI 命中
2. arXiv id 命中
3. 归一标题完全一致
4. 归一标题模糊相似度 ≥ 92（rapidfuzz）

合并时保留被引数最高的那条作为主记录，其余塞进 raw.merged_from。
"""

from __future__ import annotations

import math
import re
from collections import Counter
from datetime import date, datetime

from rapidfuzz import fuzz

from .base import PaperRecord

_LATEX = re.compile(r"\$[^$]*\$")
_VERSION = re.compile(r"\s*v\d+$")
_NON_ALNUM = re.compile(r"[^a-z0-9\u4e00-\u9fff]+")
_WS = re.compile(r"\s+")


def normalize_title(title: str) -> str:
    """标题归一：小写、去 LaTeX、去标点、去版本号、压空白。"""
    if not title:
        return ""
    t = title.strip().lower()
    t = _LATEX.sub(" ", t)
    t = t.replace("–", "-").replace("—", "-")
    t = _NON_ALNUM.sub(" ", t)
    t = _WS.sub(" ", t).strip()
    t = _VERSION.sub("", t)
    return t.strip()


def normalize_doi(doi: str) -> str:
    d = (doi or "").strip().lower()
    for p in ("https://doi.org/", "http://doi.org/", "doi:"):
        if d.startswith(p):
            d = d[len(p) :]
    return d.strip()


def normalize_arxiv_id(raw: str) -> str:
    """把 http://arxiv.org/abs/2401.00001v2 变成 2401.00001。"""
    if not raw:
        return ""
    s = raw.strip()
    s = s.split("/abs/")[-1] if "/abs/" in s else s.rsplit("/", 1)[-1]
    s = s.replace("arXiv:", "").replace("arxiv:", "")
    return _VERSION.sub("", s).strip()


def parse_date(value: str | None) -> str:
    """把各种日期格式压成 YYYY-MM-DD，失败返回空串。"""
    if not value:
        return ""
    s = str(value).strip()
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d", "%Y/%m/%d", "%Y-%m", "%Y"):
        try:
            d = datetime.strptime(s, fmt)
            return d.strftime("%Y-%m-%d") if fmt != "%Y" else f"{d.year}-01-01"
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).strftime("%Y-%m-%d")
    except ValueError:
        return ""


def reconstruct_abstract(inverted_index: dict | None) -> str:
    """OpenAlex 的摘要倒排索引还原成正文。"""
    if not inverted_index:
        return ""
    positions: list[tuple[int, str]] = []
    for word, idxs in inverted_index.items():
        for i in idxs:
            positions.append((int(i), word))
    positions.sort()
    return " ".join(w for _, w in positions)


# ----------------------------------------------------------------------
# 去重
# ----------------------------------------------------------------------
def _quality(r: PaperRecord) -> tuple:
    """判断哪条记录更值得保留。"""
    return (
        1 if r.abstract else 0,
        len(r.abstract or ""),
        r.citation_count or 0,
    )


def merge_records(primary: PaperRecord, other: PaperRecord) -> PaperRecord:
    """把 other 的补丁合并进 primary。"""
    if not primary.abstract and other.abstract:
        primary.abstract = other.abstract
    if not primary.tldr and other.tldr:
        primary.tldr = other.tldr
        primary.tldr_source = other.tldr_source
    if not primary.doi and other.doi:
        primary.doi = other.doi
    if not primary.arxiv_id and other.arxiv_id:
        primary.arxiv_id = other.arxiv_id
    if not primary.pdf_url and other.pdf_url:
        primary.pdf_url = other.pdf_url
    if not primary.venue and other.venue:
        primary.venue = other.venue
    if not primary.published_at and other.published_at:
        primary.published_at = other.published_at
    if not primary.year and other.year:
        primary.year = other.year
    primary.citation_count = max(primary.citation_count or 0, other.citation_count or 0)
    if len(other.authors) > len(primary.authors):
        primary.authors = other.authors
    if not primary.referenced_works and other.referenced_works:
        primary.referenced_works = other.referenced_works
    merged = primary.raw.setdefault("merged_from", [])
    merged.append({"source": other.source, "source_id": other.source_id})
    return primary


def dedupe(records: list[PaperRecord], fuzzy_threshold: int = 92) -> list[PaperRecord]:
    """跨源 + 库内去重。

    注意：合并时主记录会被新对象替换，所有指向旧对象的索引都必须同步更新，
    否则后续记录会命中「已不在列表里」的僵尸对象。
    """
    out: list[PaperRecord] = []
    pos: dict[int, int] = {}            # id(record) -> out 下标
    by_key: dict[str, PaperRecord] = {}
    by_title: dict[str, PaperRecord] = {}

    def register(rec: PaperRecord) -> None:
        pos[id(rec)] = len(out)
        out.append(rec)
        tn = normalize_title(rec.title)
        if tn:
            by_title[tn] = rec
        for k in rec.dedupe_keys:
            by_key[k] = rec

    def replace(old: PaperRecord, new: PaperRecord) -> None:
        idx = pos.pop(id(old), None)
        if idx is None:  # old 已不在列表里，直接补进来
            register(new)
            return
        out[idx] = new
        pos[id(new)] = idx
        for k, v in list(by_key.items()):
            if v is old:
                by_key[k] = new
        for t, v in list(by_title.items()):
            if v is old:
                by_title[t] = new
        tn = normalize_title(new.title)
        if tn:
            by_title[tn] = new
        for k in new.dedupe_keys:
            by_key[k] = new

    for r in records:
        if not r.title:
            continue
        norm = normalize_title(r.title)

        hit: PaperRecord | None = None
        for k in r.dedupe_keys:
            if k in by_key:
                hit = by_key[k]
                break
        if hit is None and norm in by_title:
            hit = by_title[norm]
        if hit is None and norm:
            for tn, cand in by_title.items():
                if abs(len(tn) - len(norm)) > max(len(norm), len(tn)) * 0.4:
                    continue
                if fuzz.token_set_ratio(norm, tn) >= fuzzy_threshold:
                    hit = cand
                    break

        if hit is None:
            register(r)
        elif _quality(r) > _quality(hit):
            replace(hit, merge_records(r, hit))
        else:
            merge_records(hit, r)

    return out


# ----------------------------------------------------------------------
# 候选粗排（内存版 BM25，无依赖）
# ----------------------------------------------------------------------
_TOKEN = re.compile(r"[a-z0-9]+")


def tokenize(text: str) -> list[str]:
    return _TOKEN.findall((text or "").lower())


class BM25:
    """极简 BM25，用于候选集粗排。"""

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.docs: list[list[str]] = []
        self.df: Counter = Counter()
        self.avgdl = 0.0

    def fit(self, docs: list[list[str]]) -> "BM25":
        self.docs = docs
        self.df = Counter()
        for d in docs:
            for t in set(d):
                self.df[t] += 1
        self.avgdl = sum(len(d) for d in docs) / max(1, len(docs))
        return self

    def score(self, query_terms: list[str], idx: int) -> float:
        doc = self.docs[idx]
        if not doc:
            return 0.0
        n = len(self.docs)
        dl = len(doc)
        tf = Counter(doc)
        s = 0.0
        for t in query_terms:
            if t not in tf:
                continue
            df = self.df.get(t, 0)
            if df == 0:
                continue
            idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
            f = tf[t]
            s += idf * (f * (self.k1 + 1)) / (f + self.k1 * (1 - self.b + self.b * dl / max(1e-9, self.avgdl)))
        return s


def coarse_rank(records: list[PaperRecord], query_terms: list[str], today: date | None = None) -> list[tuple[PaperRecord, float]]:
    """BM25 + 被引 + 新鲜度 的加权粗排。"""
    today = today or date.today()
    docs = [tokenize(f"{r.title} {r.title} {r.abstract}") for r in records]  # 标题加权
    bm = BM25().fit(docs)

    raw_scores = [bm.score(query_terms, i) for i in range(len(records))]
    mx = max(raw_scores) or 1.0

    scored: list[tuple[PaperRecord, float]] = []
    for i, r in enumerate(records):
        rel = raw_scores[i] / mx
        cite = math.log1p(r.citation_count or 0) / math.log1p(5000)
        cite = min(1.0, cite)
        recency = 0.0
        if r.published_at:
            try:
                d = datetime.strptime(r.published_at[:10], "%Y-%m-%d").date()
                years = max(0.0, (today - d).days / 365.0)
                recency = max(0.0, 1.0 - years / 6.0)
            except ValueError:
                pass
        total = 0.60 * rel + 0.20 * cite + 0.20 * recency
        scored.append((r, total))

    scored.sort(key=lambda x: x[1], reverse=True)
    return scored
