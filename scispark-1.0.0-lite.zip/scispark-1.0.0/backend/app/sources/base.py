"""数据源统一记录结构。"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(eq=False)
class PaperRecord:
    """所有检索源归一后的统一结构。

    eq=False：按身份比较。去重时会有对象替换，值相等比较会带来误判和性能问题。
    """

    source: str                       # arxiv | openalex | s2 | manual
    source_id: str
    title: str
    abstract: str = ""
    tldr: str = ""
    tldr_source: str = ""
    authors: list[str] = field(default_factory=list)
    year: int | None = None
    venue: str = ""
    url: str = ""
    pdf_url: str = ""
    doi: str = ""
    arxiv_id: str = ""
    citation_count: int = 0
    published_at: str = ""            # YYYY-MM-DD
    referenced_works: list[str] = field(default_factory=list)
    raw: dict = field(default_factory=dict)

    @property
    def dedupe_keys(self) -> list[str]:
        keys = []
        if self.doi:
            keys.append(f"doi:{self.doi.lower()}")
        if self.arxiv_id:
            keys.append(f"arxiv:{self.arxiv_id.lower()}")
        return keys

    def short(self, n: int = 60) -> str:
        t = self.title if len(self.title) <= n else self.title[: n - 1] + "…"
        return f"[{self.source}] {t}"
