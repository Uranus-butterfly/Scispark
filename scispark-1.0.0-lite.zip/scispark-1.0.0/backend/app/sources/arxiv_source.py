"""arXiv Atom API。

限制：单连接、请求间隔 ≥3 秒（官方 ToU）。
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
import xml.etree.ElementTree as ET

import httpx

from ..config import settings
from .base import PaperRecord
from .normalize import normalize_arxiv_id, parse_date

log = logging.getLogger(__name__)

ATOM = "{http://www.w3.org/2005/Atom}"
ARXIV = "{http://arxiv.org/schemas/atom}"
USER_AGENT = "SciSpark/0.1 (local research assistant)"

_lock = asyncio.Lock()
_last_call = 0.0
MIN_INTERVAL = 3.1


async def _throttle() -> None:
    global _last_call
    async with _lock:
        wait = MIN_INTERVAL - (time.monotonic() - _last_call)
        if wait > 0:
            await asyncio.sleep(wait)
        _last_call = time.monotonic()


# arXiv 的 all:"长短语" 是严格短语匹配，5 个词的短语几乎必然 0 命中。
# 实测：5 词短语 0 条，同样 5 个词的 AND 组合 190 条。所以统一走 AND 分词。
_STOP = {
    "a", "an", "the", "of", "for", "in", "on", "to", "and", "or", "with",
    "using", "based", "via", "from", "by", "as", "at", "is", "are", "be",
    "towards", "toward", "into", "under", "over", "between",
}
_WORD = re.compile(r"[a-z0-9]+")


def build_query(phrase: str, cats: list[str] | None = None) -> str:
    """把自然语言短语变成 arXiv 查询串。

    做法：去停用词 → 取前 4 个实词 → 用 AND 连接。分类用 OR 组做与运算。
    """
    words = [w for w in _WORD.findall((phrase or "").lower()) if w not in _STOP and len(w) > 1]
    words = words[:4]
    if not words:
        return ""

    terms = " AND ".join(f"all:{w}" for w in words)
    if cats:
        ors = " OR ".join(f"cat:{c}" for c in cats)
        return f"({terms}) AND ({ors})"
    return terms


def _parse_entry(entry: ET.Element) -> PaperRecord | None:
    id_el = entry.find(f"{ATOM}id")
    title_el = entry.find(f"{ATOM}title")
    if id_el is None or title_el is None:
        return None

    raw_id = (id_el.text or "").strip()
    arxiv_id = normalize_arxiv_id(raw_id)
    title = " ".join((title_el.text or "").split())

    summary = entry.find(f"{ATOM}summary")
    abstract = " ".join((summary.text or "").split()) if summary is not None else ""

    published = entry.find(f"{ATOM}published")
    published_at = parse_date(published.text if published is not None else "")

    authors = [
        " ".join((n.text or "").split())
        for n in entry.findall(f"{ATOM}author/{ATOM}name")
        if n.text
    ]

    pdf_url = ""
    for link in entry.findall(f"{ATOM}link"):
        if link.get("title") == "pdf":
            pdf_url = link.get("href", "")
            break

    doi_el = entry.find(f"{ARXIV}doi")
    doi = (doi_el.text or "").strip() if doi_el is not None else ""

    journal_el = entry.find(f"{ARXIV}journal_ref")
    venue = " ".join((journal_el.text or "").split()) if journal_el is not None else ""

    # 没有 journal_ref 时用分类号兜底，但要标清是 arXiv 分类，
    # 否则「cs.CL」会混进期刊列，看着像个期刊名
    cat_el = entry.find(f"{ARXIV}primary_category")
    if cat_el is not None and not venue:
        term = (cat_el.get("term") or "").strip()
        venue = f"arXiv {term}" if term else "arXiv"

    return PaperRecord(
        source="arxiv",
        source_id=arxiv_id,
        arxiv_id=arxiv_id,
        title=title,
        abstract=abstract,
        authors=authors,
        year=int(published_at[:4]) if published_at else None,
        venue=venue,
        url=f"https://arxiv.org/abs/{arxiv_id}" if arxiv_id else raw_id,
        pdf_url=pdf_url or (f"https://arxiv.org/pdf/{arxiv_id}" if arxiv_id else ""),
        doi=doi,
        published_at=published_at,
    )


async def search(
    phrases: list[str],
    cats: list[str] | None = None,
    per_query: int = 60,
    date_from: str | None = None,
    date_to: str | None = None,
) -> tuple[list[PaperRecord], dict]:
    """多短语并发（串行限流）检索。

    返回 (记录列表, 统计)。统计含每条的 found 数与总耗时。
    """
    out: list[PaperRecord] = []
    stats = {"requests": 0, "found": 0, "errors": []}

    async with httpx.AsyncClient(
        timeout=httpx.Timeout(45.0, connect=15.0),
        headers={"User-Agent": USER_AGENT},
        follow_redirects=True,
    ) as client:
        for phrase in phrases[:4]:
            q = build_query(phrase, cats)
            if not q:
                continue
            await _throttle()
            if date_from or date_to:
                lo = (date_from or "19910101").replace("-", "") + "0000"
                hi = (date_to or "21000101").replace("-", "") + "2359"
                q = f"({q}) AND submittedDate:[{lo} TO {hi}]"

            params = {
                "search_query": q,
                "start": 0,
                "max_results": min(per_query, 100),
                "sortBy": "relevance",
                "sortOrder": "descending",
            }
            try:
                r = await client.get(settings.arxiv_base_url, params=params)
                stats["requests"] += 1
                if r.status_code != 200:
                    stats["errors"].append(f"arXiv {r.status_code}: {phrase}")
                    continue
                root = ET.fromstring(r.text)
                entries = root.findall(f"{ATOM}entry")
                for e in entries:
                    rec = _parse_entry(e)
                    if rec and rec.title:
                        out.append(rec)
                stats["found"] += len(entries)
            except (httpx.HTTPError, ET.ParseError) as e:
                stats["errors"].append(f"arXiv {type(e).__name__}: {phrase}")
                log.warning("arXiv 查询失败 %s: %s", phrase, e)

    return out, stats
