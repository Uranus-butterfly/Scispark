"""本地论文读取：目录扫描 + 文本提取 + 章节切分。

支持 pdf / docx / md / txt。
PDF 用 PyMuPDF 的分块模式，能处理常见的双栏排版（naive get_text 会把左右栏交错）。
"""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)

SUPPORTED = {".pdf", ".docx", ".md", ".markdown", ".txt"}
MAX_FILE_MB = 80
SKIP_DIRS = {"__MACOSX", ".git", "node_modules", ".Trash", "$RECYCLE.BIN"}


@dataclass
class LocalFile:
    rel_path: str
    abs_path: str
    name: str
    ext: str
    size: int
    mtime: str

    def to_dict(self) -> dict:
        return {
            "rel_path": self.rel_path,
            "name": self.name,
            "ext": self.ext.lstrip("."),
            "size": self.size,
            "mtime": self.mtime,
        }


@dataclass
class Extracted:
    title: str
    text: str
    pages: int
    sections: list[tuple[str, str]] = field(default_factory=list)
    meta: dict = field(default_factory=dict)

    @property
    def chars(self) -> int:
        return len(self.text)


def scan_dir(root: Path, max_depth: int = 3, limit: int = 500) -> list[LocalFile]:
    """递归扫描支持的论文文件。"""
    root = root.resolve()
    if not root.is_dir():
        return []

    out: list[LocalFile] = []
    stack: list[tuple[Path, int]] = [(root, 0)]
    while stack and len(out) < limit:
        cur, depth = stack.pop()
        try:
            entries = sorted(cur.iterdir(), key=lambda p: p.name.lower())
        except (PermissionError, OSError):
            continue
        for p in entries:
            if p.name.startswith(".") or p.name in SKIP_DIRS:
                continue
            try:
                if p.is_dir():
                    if depth < max_depth:
                        stack.append((p, depth + 1))
                    continue
                if p.suffix.lower() not in SUPPORTED:
                    continue
                st = p.stat()
                if st.st_size > MAX_FILE_MB * 1024 * 1024:
                    continue
                out.append(
                    LocalFile(
                        rel_path=str(p.relative_to(root)),
                        abs_path=str(p),
                        name=p.name,
                        ext=p.suffix.lower(),
                        size=st.st_size,
                        mtime=_fmt_ts(st.st_mtime),
                    )
                )
            except OSError:
                continue
    out.sort(key=lambda f: f.rel_path)
    return out


def _fmt_ts(ts: float) -> str:
    from datetime import datetime

    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ----------------------------------------------------------------------
# PDF
# ----------------------------------------------------------------------
def _order_pdf_blocks(blocks: list, page_width: float) -> str:
    """把块按「通栏 → 左栏 → 右栏」重排。

    简化处理：通栏块（通常是大标题、摘要、图注）先出，再左栏、再右栏。
    对绝大多数论文够用；极少数把通栏图注插在正文中间的页面会有轻微错序，
    不影响 LLM 抽取观点。
    """
    if not blocks:
        return ""

    def width(b) -> float:
        return b[2] - b[0]

    full = [b for b in blocks if width(b) > page_width * 0.62]
    narrow = [b for b in blocks if width(b) <= page_width * 0.62]

    mid = page_width / 2
    left = [b for b in narrow if (b[0] + b[2]) / 2 < mid]
    right = [b for b in narrow if (b[0] + b[2]) / 2 >= mid]

    two_column = len(left) >= 2 and len(right) >= 2
    if not two_column:
        return "\n".join(b[4].strip() for b in sorted(blocks, key=lambda b: (b[1], b[0])) if b[4].strip())

    parts = []
    for group in (sorted(full, key=lambda b: b[1]), sorted(left, key=lambda b: b[1]), sorted(right, key=lambda b: b[1])):
        for b in group:
            t = b[4].strip()
            if t:
                parts.append(t)
    return "\n".join(parts)


def extract_pdf(path: Path) -> Extracted:
    try:
        import pymupdf  # type: ignore
    except ImportError:  # 兼容旧包名
        import fitz as pymupdf  # type: ignore

    doc = pymupdf.open(str(path))
    pages_text: list[str] = []
    try:
        for page in doc:
            blocks = [b for b in page.get_text("blocks") if len(b) > 6 and b[6] == 0]
            txt = _order_pdf_blocks(blocks, page.rect.width)
            if not txt.strip():
                txt = page.get_text()
            pages_text.append(txt)
        n_pages = doc.page_count
        meta = dict(doc.metadata or {})
    finally:
        doc.close()

    text = "\n\n".join(pages_text)
    title = (meta.get("title") or "").strip() or _guess_title(text, path)
    return Extracted(title=title, text=text, pages=n_pages, meta=meta)


def extract_docx(path: Path) -> Extracted:
    from docx import Document  # type: ignore

    doc = Document(str(path))
    paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    text = "\n".join(paras)
    return Extracted(title=_guess_title(text, path), text=text, pages=0, meta={})


def extract_text_file(path: Path) -> Extracted:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    # 去掉 markdown 代码块围栏，保留结构
    text = re.sub(r"^```[a-zA-Z]*\n", "", raw, flags=re.MULTILINE)
    text = text.replace("```", "")
    return Extracted(title=_guess_title(text, path), text=text, pages=0, meta={})


def _guess_title(text: str, path: Path) -> str:
    for line in text.splitlines()[:25]:
        s = line.strip()
        if 12 <= len(s) <= 180 and not s.lower().startswith(("arxiv:", "doi", "http")):
            if sum(c.isalpha() for c in s) / max(1, len(s)) > 0.5:
                return s
    return path.stem


# ----------------------------------------------------------------------
# 章节切分
# ----------------------------------------------------------------------
_HEADING = re.compile(
    r"^\s*(?:\d{1,2}(?:\.\d{1,2}){0,2}\.?\s+)?"
    r"(Abstract|Introduction|Background|Related Work|Preliminaries|Method(?:ology)?|Approach|"
    r"Model|Framework|Experiment(?:s|al Setup)?|Evaluation|Results?(?: and Discussion)?|"
    r"Discussion|Analysis|Ablation(?: Study)?|Conclusion(?:s)?|Future Work|Limitations?|"
    r"References|Bibliography|Appendix)\s*$",
    re.IGNORECASE,
)
_REF = re.compile(r"^\s*(References|Bibliography|参考文献)\s*$", re.IGNORECASE)


def split_sections(text: str) -> list[tuple[str, str]]:
    """按常见论文标题切章节。切不出来就返回单节。"""
    lines = text.splitlines()
    marks: list[tuple[int, str]] = []
    for i, line in enumerate(lines):
        s = line.strip()
        if not s or len(s) > 60:
            continue
        if _HEADING.match(s):
            name = re.sub(r"^\d{1,2}(?:\.\d{1,2}){0,2}\.?\s*", "", s).strip()
            marks.append((i, name))

    if len(marks) < 2:
        return [("正文", text)]

    out: list[tuple[str, str]] = []
    for idx, (start, name) in enumerate(marks):
        if _REF.match(name):
            break  # 参考文献之后不要
        end = marks[idx + 1][0] if idx + 1 < len(marks) else len(lines)
        body = "\n".join(lines[start + 1 : end]).strip()
        if len(body) > 80:
            out.append((name, body))
    return out or [("正文", text)]


def extract(path: Path) -> Extracted:
    ext = path.suffix.lower()
    if ext == ".pdf":
        ex = extract_pdf(path)
    elif ext == ".docx":
        ex = extract_docx(path)
    elif ext in (".md", ".markdown", ".txt"):
        ex = extract_text_file(path)
    else:
        raise ValueError(f"不支持的文件类型：{ext}")

    ex.text = _clean(ex.text)
    ex.sections = split_sections(ex.text)
    return ex


def _clean(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"-\n(?=[a-z])", "", text)      # 断词连字符
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()
