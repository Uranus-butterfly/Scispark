"""Pydantic 出入参模型。"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# ---------------- 项目 ----------------
class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    name_en: str | None = None
    topic: str = Field(min_length=1, max_length=400)
    description: str | None = None


class ProjectUpdate(BaseModel):
    name: str | None = None
    name_en: str | None = None
    topic: str | None = None
    description: str | None = None
    status: str | None = None


class ProjectOut(BaseModel):
    id: str
    name: str
    name_en: str | None = None
    topic: str
    description: str | None = None
    status: str = "active"
    created_at: str
    updated_at: str
    paper_count: int = 0
    idea_count: int = 0
    rq_count: int = 0


# ---------------- 设置 ----------------
class SettingsUpdate(BaseModel):
    values: dict[str, str] = Field(default_factory=dict)


class SettingsOut(BaseModel):
    items: dict[str, Any]
    budget: dict[str, Any]
    cache: dict[str, Any]
    pricing: dict[str, Any]


# ---------------- 通用 ----------------
class OkOut(BaseModel):
    ok: bool = True
    message: str | None = None
    data: Any = None
