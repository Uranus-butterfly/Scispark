"""运行时配置：环境变量默认值 + app_setting 表覆盖。

设置页写入的值存在 DB 里，优先级高于 .env，
这样改 key / 换模型不用重建容器。
"""

from __future__ import annotations

import contextvars
from contextlib import contextmanager

from ..config import settings
from ..db import query, tx

# 临时覆盖层：用于「测试连接」时把表单里还没保存的值也纳入，
# 但不写库。用 ContextVar 保证并发请求之间不串。
_override: contextvars.ContextVar[dict[str, str]] = contextvars.ContextVar(
    "settings_override", default={}
)

# 允许在设置页修改的键（白名单）
EDITABLE = {
    "deepseek_api_key": {"secret": True, "label": "DeepSeek API Key"},
    "deepseek_base_url": {"secret": False, "label": "DeepSeek Base URL"},
    "model_flash": {"secret": False, "label": "快速模型"},
    "model_pro": {"secret": False, "label": "强模型"},
    "openalex_api_key": {"secret": True, "label": "OpenAlex API Key"},
    "openalex_mailto": {"secret": False, "label": "OpenAlex 联系邮箱"},
    "daily_budget_cny": {"secret": False, "label": "每日预算（元）"},
    "llm_mode": {"secret": False, "label": "LLM 模式（live / mock）"},
    "cache_enabled": {"secret": False, "label": "启用响应缓存"},
    # 语言：zh | en。ui_language 控制界面文案，result_language 控制调研结果（LLM 输出）
    "ui_language": {"secret": False, "label": "界面语言 / UI Language"},
    "result_language": {"secret": False, "label": "调研结果语言 / Result Language"},
}


def _env_default(key: str) -> str:
    v = getattr(settings, key, "")
    if isinstance(v, bool):
        return "1" if v else "0"
    return "" if v is None else str(v)


@contextmanager
def temporary(values: dict[str, str] | None):
    """临时覆盖若干配置，仅在本上下文内生效，不写库。

    空字符串视为「未提供」，不会覆盖已保存的值。
    """
    clean = {
        k: str(v).strip()
        for k, v in (values or {}).items()
        if k in EDITABLE and v is not None and str(v).strip() != ""
    }
    if not clean:
        yield
        return
    token = _override.set({**_override.get(), **clean})
    try:
        yield
    finally:
        _override.reset(token)


def get(key: str, default: str = "") -> str:
    ov = _override.get()
    if key in ov:
        return ov[key]
    row = query("SELECT value FROM app_setting WHERE key = ?", (key,))
    if row:
        return row[0]["value"]
    if key in EDITABLE:
        return _env_default(key)
    return default


def get_float(key: str, default: float = 0.0) -> float:
    try:
        return float(get(key) or default)
    except (TypeError, ValueError):
        return default


def get_bool(key: str, default: bool = False) -> bool:
    v = (get(key) or "").strip().lower()
    if v in ("1", "true", "yes", "on"):
        return True
    if v in ("0", "false", "no", "off"):
        return False
    return default


def set_many(values: dict[str, str]) -> None:
    with tx() as conn:
        for k, v in values.items():
            if k not in EDITABLE:
                continue
            conn.execute(
                "INSERT INTO app_setting(key, value, is_secret, updated_at)"
                " VALUES (?,?,?,datetime('now','localtime'))"
                " ON CONFLICT(key) DO UPDATE SET value=excluded.value,"
                " updated_at=excluded.updated_at",
                (k, str(v), 1 if EDITABLE[k]["secret"] else 0),
            )


def _mask(v: str) -> str:
    if not v:
        return ""
    if len(v) <= 8:
        return "•" * len(v)
    return f"{v[:4]}{'•' * 6}{v[-4:]}"


def public_view() -> dict:
    out = {}
    for key, meta in EDITABLE.items():
        raw = get(key)
        configured = bool(raw)
        out[key] = {
            "value": _mask(raw) if meta["secret"] else raw,
            "secret": meta["secret"],
            "label": meta["label"],
            "configured": configured,
            "raw_empty": not configured,
        }
    return out


def effective_api_key() -> str:
    return (get("deepseek_api_key") or "").strip()


def effective_base_url() -> str:
    return (get("deepseek_base_url") or "https://api.deepseek.com").strip().rstrip("/")


def effective_model(which: str = "flash") -> str:
    return (get("model_flash") if which == "flash" else get("model_pro")) or (
        settings.model_flash if which == "flash" else settings.model_pro
    )


def is_mock() -> bool:
    return (get("llm_mode") or "live").strip().lower() == "mock"
