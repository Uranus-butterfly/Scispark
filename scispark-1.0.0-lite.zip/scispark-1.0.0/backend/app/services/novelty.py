"""新颖性查重：想法 vs 论文库（可选再联网查一次）。

两级检索：
1. **库内**：TF-IDF 语义相似（和建图同一套），零成本，先看是不是自己已经读过。
2. **联网**（可选）：拿想法当 query 去 arXiv / OpenAlex 搜，抓最近 1~2 年，
   防止「库里没有 ≠ 世界上没有」。这一步要花钱，默认关。

然后一次 LLM 判定：done / partial / novel。
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from ..db import execute, new_id, now, query_one
from ..llm.client import chat_json
from ..services import settings_store
from ..workers import queue
from . import graph

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT_DIR = Path(__file__).resolve().parent.parent / "llm" / "prompts"
KB_TOP_K = 6


def _prompt(name: str) -> str:
    try:
        return prompt_loader.load(name)
    except OSError:
        return "只输出 JSON。"


def idea_text(idea: dict) -> str:
    parts = [
        idea.get("title") or "",
        idea.get("one_liner") or "",
        idea.get("problem") or "",
        idea.get("gap") or "",
        idea.get("method_sketch") or "",
    ]
    return "\n".join(p for p in parts if p).strip()


async def _live_search(project_id: str, text: str, job_id: str | None) -> tuple[list[dict], float]:
    """拿想法去 arXiv / OpenAlex 搜近 3 年。只搜不落库。"""
    from datetime import date, timedelta

    from ..sources import arxiv_source, openalex_source
    from ..sources.normalize import dedupe
    from .ingest import expand_query

    exp = await expand_query(project_id, text[:400], job_id)
    phrases = exp.get("phrases") or []
    if not phrases:
        return [], 0.0

    since = (date.today() - timedelta(days=365 * 3)).isoformat()
    recs = []
    for fn in (arxiv_source.search, openalex_source.search):
        try:
            got, _ = await fn(phrases[:3], per_query=25, date_from=since)
            recs.extend(got)
        except Exception as e:  # noqa: BLE001
            log.warning("联网检索失败 %s: %s", fn.__module__, e)

    uniq = dedupe(recs)
    uniq.sort(key=lambda r: -(r.citation_count or 0))
    return (
        [
            {
                "id": "",
                "title": r.title,
                "year": (r.published_at or "")[:4],
                "tldr": (r.abstract or "")[:300],
            }
            for r in uniq[:8]
        ],
        0.0,
    )


async def run_check(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    idea_id = payload["idea_id"]
    live = bool(payload.get("live"))

    row = query_one("SELECT * FROM idea WHERE id = ? AND project_id = ?", (idea_id, project_id))
    if row is None:
        raise ValueError("想法不存在")
    idea = dict(row)

    text = idea_text(idea)
    if len(text) < 12:
        raise ValueError("这个想法内容太少，先补一句说明再查重")

    queue.progress(job_id, 0.2, "在论文库里找相近工作")
    kb = graph.similar_papers(project_id, text, top_k=KB_TOP_K)
    # 中文想法切不出英文词时会退回「按被引排序」，这个要如实告诉用户，
    # 否则「库内没找到」会被误读成「世界上没有」
    kb_fallback = bool(kb and kb[0].get("fallback"))

    live_hits: list[dict] = []
    cost = 0.0
    if live:
        queue.progress(job_id, 0.4, "联网检索最新工作")
        try:
            live_hits, live_cost = await _live_search(project_id, text, job_id)
            cost += live_cost
        except Exception as e:  # noqa: BLE001
            log.warning("联网查重失败：%s", e)

    queue.progress(job_id, 0.65, "AI 判定重复程度")
    cands = [
        {
            "id": p["id"],
            "title": p["title"],
            "year": p["year"],
            "tldr": p["tldr"],
            "problem": p["problem"],
            "method": p["method"],
        }
        for p in kb
    ] + [{"id": h["id"] or f"live-{i}", "title": h["title"], "year": h["year"], "tldr": h["tldr"]}
         for i, h in enumerate(live_hits)]

    user = (
        "【待查的想法】\n"
        + json.dumps(
            {
                "title": idea.get("title"),
                "one_liner": idea.get("one_liner"),
                "problem": idea.get("problem"),
                "gap": idea.get("gap"),
                "method": idea.get("method_sketch"),
                "why_novel": idea.get("why_novel"),
            },
            ensure_ascii=False,
        )
        + "\n\n【检索到的候选工作】\n"
        + json.dumps(cands, ensure_ascii=False)
        + f"\n\n检索范围：项目论文库 {len(kb)} 篇"
        + ("（注意：这些是按被引排序的，不是按语义匹配，可能不完全相关）" if kb_fallback else "")
        + (f" + 联网 {len(live_hits)} 篇（近 3 年）" if live else "（未联网，可能漏掉库外工作）")
    )

    data, res = await chat_json(
        [{"role": "system", "content": _prompt("check_novelty.md")}, {"role": "user", "content": user}],
        purpose="novelty",
        model=settings_store.effective_model("pro"),
        thinking=True,
        reasoning_effort="medium",
        project_id=project_id,
        job_id=job_id,
        fallback=None,
    )
    cost += res.cost_cny

    status = str((data or {}).get("status") or "unchecked")
    if status not in ("done", "partial", "novel", "unchecked"):
        status = "unchecked"

    report = {
        "status": status,
        "confidence": (data or {}).get("confidence"),
        "summary": (data or {}).get("summary"),
        "closest": (data or {}).get("closest") or [],
        "suggestions": (data or {}).get("suggestions") or [],
        "kb_candidates": len(kb),
        "kb_fallback": kb_fallback,
        "live_candidates": len(live_hits),
        "checked_at": now(),
        "cost_cny": round(cost, 4),
    }

    # novelty_report_json 里原本还放着生成时写的 next_step / collision / evidence，
    # 查重结果挂在 check 子键下，别把原来的内容冲掉
    try:
        extra = json.loads(idea.get("novelty_report_json") or "{}")
        if not isinstance(extra, dict):
            extra = {}
    except (json.JSONDecodeError, TypeError):
        extra = {}
    extra["check"] = report

    execute(
        "UPDATE idea SET novelty_status = ?, novelty_report_json = ?, updated_at = ? WHERE id = ?",
        (status, json.dumps(extra, ensure_ascii=False), now(), idea_id),
    )

    # 把最接近的工作记成证据，方便在想法卡片上点开看
    for c in report["closest"][:5]:
        pid = str(c.get("paper_id") or "")
        if not pid or not query_one("SELECT id FROM paper WHERE id = ?", (pid,)):
            continue
        execute(
            "INSERT OR REPLACE INTO idea_evidence(idea_id, paper_id, rel, quote) VALUES (?,?,?,?)",
            (idea_id, pid, "overlaps", str(c.get("delta") or "")[:500]),
        )

    queue.progress(job_id, 1.0, "完成")
    return {"status": status, "summary": report["summary"], "cost_cny": round(cost, 4)}
