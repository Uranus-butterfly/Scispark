"""Gap 挖掘：四种策略 + 一次 LLM 判定。

分工：
- **确定性部分（不花钱）**负责「找候选」：反复出现的局限、互相打架的结论、
  从未共现的概念组合、可以迁移的方法。
- **LLM 部分（一次调用）**负责「判真假」：把候选连同证据一起给它，
  让它说这条是真空白 / 证据不足 / 已经有人做了。

这样做的原因是：让模型自由发挥「找空白」会编得很像真的，但它没法判断
「这个方向其实已经有人做了」。先把候选压到十几条、把证据摆在它面前，
它只需要做判断题，幻觉空间小很多，成本也只有一次调用。
"""

from __future__ import annotations

import json
import logging
import re
from collections import Counter, defaultdict
from pathlib import Path

from ..db import execute, new_id, query
from ..llm.client import chat_json
from ..services import settings_store
from ..workers import queue
from . import graph

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT_DIR = Path(__file__).resolve().parent.parent / "llm" / "prompts"
MAX_CANDIDATES = 18

_NEG = re.compile(
    r"\b(no|not|never|cannot|can't|without|fail|fails|failed|struggle|struggles|"
    r"limited|limitation|weak|poor|worse|lower|less|insufficient|lack|lacks|"
    r"difficult|hard|expensive|slow|degrade|degradation|bottleneck)\b",
    re.IGNORECASE,
)


def _prompt(name: str) -> str:
    try:
        return prompt_loader.load(name)
    except OSError:
        return "只输出 JSON。"


def _tokens(text: str) -> set[str]:
    return set(graph.tokenize(text or ""))


def _jac(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


# ----------------------------------------------------------------------
# 候选 1：局限聚类
# ----------------------------------------------------------------------
def limitation_candidates(project_id: str, limit: int = 6) -> list[dict]:
    rows = query(
        "SELECT c.id AS claim_id, c.paper_id, c.text, c.quote, p.title"
        " FROM claim c JOIN paper p ON p.id = c.paper_id"
        " WHERE p.project_id = ? AND c.claim_type = 'limitation'",
        (project_id,),
    )
    items = [
        {
            "claim_id": r["claim_id"],
            "paper_id": r["paper_id"],
            "text": r["text"],
            "quote": r["quote"] or "",
            "title": r["title"],
            "tokens": _tokens(r["text"]),
        }
        for r in rows
        if len(r["text"] or "") > 12
    ]

    # 贪心聚类：和已有簇的代表句子相似度够高就并进去
    clusters: list[dict] = []
    for it in items:
        for cl in clusters:
            if _jac(it["tokens"], cl["rep"]) >= 0.26:
                cl["items"].append(it)
                break
        else:
            clusters.append({"rep": it["tokens"], "items": [it]})

    out = []
    for cl in clusters:
        papers = {x["paper_id"] for x in cl["items"]}
        if len(papers) < 2:
            continue
        out.append(
            {
                "strategy": "limitation_cluster",
                "signal": {
                    "paper_count": len(papers),
                    "limitations": [
                        {"paper": x["title"][:120], "claim": x["text"][:220]} for x in cl["items"][:6]
                    ],
                },
                "support": [
                    {
                        "paper_id": x["paper_id"],
                        "claim_id": x["claim_id"],
                        "quote": (x["quote"] or x["text"])[:300],
                        "note": "提出该局限",
                    }
                    for x in cl["items"][:6]
                ],
                "score": len(papers),
            }
        )
    out.sort(key=lambda c: -c["score"])
    return out[:limit]


# ----------------------------------------------------------------------
# 候选 2：结论冲突
# ----------------------------------------------------------------------
def contradiction_candidates(project_id: str, limit: int = 5) -> list[dict]:
    rows = query(
        "SELECT c.id AS claim_id, c.paper_id, c.text, c.polarity, p.title"
        " FROM claim c JOIN paper p ON p.id = c.paper_id"
        " WHERE p.project_id = ? AND c.claim_type IN ('finding','result')",
        (project_id,),
    )
    items = []
    for r in rows:
        text = r["text"] or ""
        if len(text) < 20:
            continue
        items.append(
            {
                "claim_id": r["claim_id"],
                "paper_id": r["paper_id"],
                "title": r["title"],
                "text": text,
                "tokens": _tokens(text),
                "neg": bool(_NEG.search(text)),
                "polarity": r["polarity"],
            }
        )

    out = []
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            a, b = items[i], items[j]
            if a["paper_id"] == b["paper_id"]:
                continue
            sim = _jac(a["tokens"], b["tokens"])
            if sim < 0.42:
                continue
            opposed = a["neg"] != b["neg"] or a["polarity"] != b["polarity"]
            if not opposed:
                continue
            out.append(
                {
                    "strategy": "contradiction",
                    "signal": {
                        "similarity": round(sim, 2),
                        "a": {"paper": a["title"][:120], "claim": a["text"][:240]},
                        "b": {"paper": b["title"][:120], "claim": b["text"][:240]},
                    },
                    "support": [
                        {"paper_id": a["paper_id"], "claim_id": a["claim_id"], "quote": a["text"][:300], "note": "一方"},
                        {"paper_id": b["paper_id"], "claim_id": b["claim_id"], "quote": b["text"][:300], "note": "另一方"},
                    ],
                    "score": sim,
                }
            )
    out.sort(key=lambda c: -c["score"])
    return out[:limit]


# ----------------------------------------------------------------------
# 候选 3：概念组合（各自成熟、从未同时出现）
# ----------------------------------------------------------------------
def combination_candidates(project_id: str, limit: int = 5) -> list[dict]:
    concepts = query(
        "SELECT id, name, paper_count FROM concept WHERE project_id = ? AND paper_count >= 2"
        " ORDER BY paper_count DESC LIMIT 40",
        (project_id,),
    )
    if len(concepts) < 2:
        return []

    pairs_of = query(
        "SELECT a.concept_id AS a, b.concept_id AS b FROM paper_concept a"
        " JOIN paper_concept b ON a.paper_id = b.paper_id AND a.concept_id < b.concept_id"
        " JOIN paper p ON p.id = a.paper_id WHERE p.project_id = ?",
        (project_id,),
    )
    co = {(r["a"], r["b"]) for r in pairs_of}

    out = []
    for i in range(len(concepts)):
        for j in range(i + 1, len(concepts)):
            a, b = concepts[i], concepts[j]
            key = tuple(sorted((a["id"], b["id"])))
            if key in co:
                continue
            score = min(a["paper_count"], b["paper_count"])
            out.append(
                {
                    "strategy": "combination",
                    "signal": {
                        "concept_a": {"name": a["name"], "papers": a["paper_count"]},
                        "concept_b": {"name": b["name"], "papers": b["paper_count"]},
                        "cooccurrence": 0,
                    },
                    "support": [],
                    "concept_ids": [a["id"], b["id"]],
                    "score": score,
                }
            )
    out.sort(key=lambda c: -c["score"])
    return out[:limit]


# ----------------------------------------------------------------------
# 候选 4：方法迁移（A 的方法 → B 的问题）
# ----------------------------------------------------------------------
def transfer_candidates(project_id: str, limit: int = 4) -> list[dict]:
    rows = query(
        "SELECT p.id, p.title, p.citation_count, i.problem, i.method, i.findings_json"
        " FROM paper p JOIN paper_insight i ON i.paper_id = p.id"
        "   AND i.schema_version = (SELECT MAX(schema_version) FROM paper_insight WHERE paper_id = p.id)"
        " WHERE p.project_id = ? AND i.problem IS NOT NULL AND i.method IS NOT NULL",
        (project_id,),
    )
    papers = [dict(r) for r in rows if (r["problem"] or "").strip() and (r["method"] or "").strip()]
    if len(papers) < 2:
        return []

    concepts: dict[str, set[str]] = defaultdict(set)
    for r in query(
        "SELECT pc.paper_id, c.name FROM paper_concept pc JOIN concept c ON c.id = pc.concept_id"
        " JOIN paper p ON p.id = pc.paper_id WHERE p.project_id = ?",
        (project_id,),
    ):
        concepts[r["paper_id"]].add(r["name"])

    # 只看语义/概念上确实没连起来的组合，否则就是「已经在做的事」
    linked = set()
    for r in query(
        "SELECT src_id, dst_id FROM paper_relation r JOIN paper p ON p.id = r.src_id"
        " WHERE p.project_id = ?",
        (project_id,),
    ):
        linked.add((r["src_id"], r["dst_id"]))
        linked.add((r["dst_id"], r["src_id"]))

    out = []
    for a in papers:
        for b in papers:
            if a["id"] == b["id"]:
                continue
            if (a["id"], b["id"]) in linked:
                continue
            shared = concepts[a["id"]] & concepts[b["id"]]
            if shared:
                continue
            out.append(
                {
                    "strategy": "transfer",
                    "signal": {
                        "method_from": {"paper": a["title"][:120], "method": a["method"][:200]},
                        "problem_to": {"paper": b["title"][:120], "problem": b["problem"][:200]},
                        "concept_overlap": 0,
                    },
                    "support": [
                        {"paper_id": a["id"], "claim_id": None, "quote": a["method"][:300], "note": "方法来源"},
                        {"paper_id": b["id"], "claim_id": None, "quote": b["problem"][:300], "note": "问题来源"},
                    ],
                    "score": (a["citation_count"] or 0) + (b["citation_count"] or 0) + 1,
                }
            )
    out.sort(key=lambda c: -c["score"])
    return out[:limit]


# ----------------------------------------------------------------------
# 汇总
# ----------------------------------------------------------------------
def candidates(project_id: str) -> list[dict]:
    out: list[dict] = []
    for fn in (limitation_candidates, contradiction_candidates, combination_candidates, transfer_candidates):
        try:
            out.extend(fn(project_id))
        except Exception as e:  # noqa: BLE001
            log.warning("候选生成失败 %s: %s", fn.__name__, e)
    return out[:MAX_CANDIDATES]


async def run_mine(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]

    queue.progress(job_id, 0.15, "扫描局限与冲突")
    cands = candidates(project_id)
    if not cands:
        raise ValueError("没有挖到候选信号，可能论文太少或还没做结构化理解")

    for i, c in enumerate(cands):
        c["cid"] = f"g{i + 1}"

    queue.progress(job_id, 0.45, f"AI 判定 {len(cands)} 条候选")
    payload_json = json.dumps(
        [
            {"cid": c["cid"], "strategy": c["strategy"], "signal": c["signal"]}
            for c in cands
        ],
        ensure_ascii=False,
    )

    data, res = await chat_json(
        [
            {"role": "system", "content": _prompt("mine_gaps.md")},
            {"role": "user", "content": f"候选信号：\n{payload_json}"},
        ],
        purpose="mine_gaps",
        model=settings_store.effective_model("pro"),
        thinking=True,
        reasoning_effort="medium",
        project_id=project_id,
        job_id=job_id,
        fallback=None,
    )

    by_cid = {c["cid"]: c for c in cands}
    gaps = []
    for item in (data or {}).get("gaps") or []:
        cid = str(item.get("cid") or "")
        cand = by_cid.get(cid)
        if cand is None or not item.get("title"):
            continue
        gid = new_id()
        execute(
            "INSERT INTO gap(id, project_id, strategy, title, statement, detail,"
            " support_json, concept_ids_json, paper_count, strength, verdict)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (
                gid, project_id, cand["strategy"], str(item["title"])[:200],
                str(item.get("statement") or "")[:600],
                str(item.get("detail") or "")[:1500],
                json.dumps(cand.get("support") or [], ensure_ascii=False),
                json.dumps(cand.get("concept_ids") or [], ensure_ascii=False),
                len({s["paper_id"] for s in (cand.get("support") or []) if s.get("paper_id")}),
                float(item.get("strength") or 0.5),
                str(item.get("verdict") or "weak"),
            ),
        )
        gaps.append({"id": gid, "verdict": item.get("verdict"), "title": item["title"]})

    queue.progress(job_id, 1.0, "完成")
    real = sum(1 for g in gaps if g["verdict"] == "real_gap")
    return {
        "candidates": len(cands),
        "gaps": len(gaps),
        "real_gap": real,
        "cost_cny": round(res.cost_cny, 4),
    }


# ----------------------------------------------------------------------
# 查询
# ----------------------------------------------------------------------
def list_gaps(project_id: str, strategy: str | None = None) -> list[dict]:
    sql = "SELECT * FROM gap WHERE project_id = ?"
    params: list = [project_id]
    if strategy:
        sql += " AND strategy = ?"
        params.append(strategy)
    sql += " ORDER BY CASE verdict WHEN 'real_gap' THEN 0 WHEN 'weak' THEN 1 ELSE 2 END,"
    sql += " strength DESC, created_at DESC"

    out = []
    for r in query(sql, params):
        d = dict(r)
        try:
            d["support"] = json.loads(d.pop("support_json") or "[]")
        except (json.JSONDecodeError, TypeError):
            d["support"] = []
        d.pop("concept_ids_json", None)
        out.append(d)
    return out


def delete_gap(project_id: str, gap_id: str) -> None:
    execute("DELETE FROM gap WHERE id = ? AND project_id = ?", (gap_id, project_id))
