"""检索接口。

默认实现是 FTS5(BM25) + 查询扩展。
将来接本地 embedding 时，只需再实现一个 VectorRetriever，
上层 services 不用改。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from ..db import fts_search


@dataclass
class Hit:
    paper_id: str
    score: float
    why: str = ""


class Retriever(Protocol):
    async def search(self, q: str, k: int = 20, project_id: str | None = None) -> list[Hit]: ...


class LexicalRetriever:
    """FTS5 BM25。查询串由调用方保证已是英文关键词组合。"""

    async def search(self, q: str, k: int = 20, project_id: str | None = None) -> list[Hit]:
        rows = fts_search(q, limit=k * 2, project_id=project_id)
        return [Hit(paper_id=r["paper_id"], score=r["score"]) for r in rows[:k]]


def get_retriever() -> Retriever:
    return LexicalRetriever()
