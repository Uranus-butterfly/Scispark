"""想法排序：Elo 锦标赛 + 提案导出。

为什么不让人直接打分：让人（或模型）给每个想法打 1~5 分，最后所有想法都是 4 分，
排序没有信息量。两两比较则稳定得多——「这两个只能留一个，你留哪个」是个真问题。

防位置偏置：每场比较随机决定谁先出现，结果记在 `idea_comparison.swapped` 里。
不双跑（成本翻倍），但至少让偏置随机化而不是系统性偏向 A。
"""

from __future__ import annotations

import json
import logging
import random
from pathlib import Path

from ..db import execute, new_id, now, query, query_one
from ..llm.client import chat, chat_json
from ..services import settings_store
from ..workers import queue

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT_DIR = Path(__file__).resolve().parent.parent / "llm" / "prompts"
K_FACTOR = 32.0
MIN_IDEAS = 2


def _prompt(name: str) -> str:
    try:
        return prompt_loader.load(name)
    except OSError:
        return "只输出 JSON。"


# ----------------------------------------------------------------------
# Elo
# ----------------------------------------------------------------------
def expected_score(rating_a: float, rating_b: float) -> float:
    return 1.0 / (1.0 + 10 ** ((rating_b - rating_a) / 400.0))


def update_elo(
    ra: float, rb: float, score_a: float, k: float = K_FACTOR
) -> tuple[float, float]:
    """score_a: 1 赢 / 0.5 平 / 0 输。返回 (新 A, 新 B)。"""
    ea = expected_score(ra, rb)
    na = ra + k * (score_a - ea)
    nb = rb + k * ((1 - score_a) - (1 - ea))
    return round(na, 1), round(nb, 1)


def _idea_brief(row) -> dict:
    return {
        "title": row["title"] or "",
        "one_liner": (row["one_liner"] or "")[:300],
        "gap": (row["gap"] or "")[:400],
        "method": (row["method_sketch"] or "")[:500],
        "risks": (row["risks"] or "")[:300],
    }


async def run_tournament(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    rounds = max(1, min(3, int(payload.get("rounds") or 1)))

    rows = query(
        "SELECT * FROM idea WHERE project_id = ? AND status != 'archived'"
        " ORDER BY elo DESC, created_at",
        (project_id,),
    )
    if len(rows) < MIN_IDEAS:
        raise ValueError(f"至少要 {MIN_IDEAS} 个想法才能比")

    ideas = [dict(r) for r in rows]
    pairs: list[tuple[int, int]] = []
    for i in range(len(ideas)):
        for j in range(i + 1, len(ideas)):
            pairs.append((i, j))
    pairs = pairs * rounds

    total = len(pairs)
    done = 0
    cost = 0.0
    wins = {i: 0 for i in range(len(ideas))}

    for a_i, b_i in pairs:
        queue.progress(job_id, done / total, f"第 {done + 1}/{total} 场对比")
        a, b = ideas[a_i], ideas[b_i]

        swapped = random.random() < 0.5
        first, second = (b, a) if swapped else (a, b)
        first_i, second_i = (b_i, a_i) if swapped else (a_i, b_i)

        user = (
            "【想法 A】\n"
            + json.dumps(_idea_brief(first), ensure_ascii=False)
            + "\n\n【想法 B】\n"
            + json.dumps(_idea_brief(second), ensure_ascii=False)
        )

        try:
            data, res = await chat_json(
                [
                    {"role": "system", "content": _prompt("compare_ideas.md")},
                    {"role": "user", "content": user},
                ],
                purpose="compare_ideas",
                model=settings_store.effective_model("flash"),
                thinking=False,
                temperature=0.2,
                project_id=project_id,
                job_id=job_id,
                fallback=None,
            )
        except Exception as e:  # noqa: BLE001
            log.warning("对比失败，跳过这一场：%s", e)
            done += 1
            continue

        cost += res.cost_cny
        verdict = str((data or {}).get("winner") or "tie")
        # 把「A/B」还原成真实顺序（考虑交换）
        if verdict == "a":
            winner_i = first_i
        elif verdict == "b":
            winner_i = second_i
        else:
            winner_i = None

        ra, rb = float(a["elo"] or 1500), float(b["elo"] or 1500)
        if winner_i is None:
            score_a = 0.5
        elif winner_i == a_i:
            score_a = 1.0
            wins[a_i] += 1
        else:
            score_a = 0.0
            wins[b_i] += 1
        na, nb = update_elo(ra, rb, score_a)

        # 落库：比较记录 + 双方 Elo
        execute(
            "INSERT OR REPLACE INTO idea_comparison(id, project_id, round, idea_a, idea_b,"
            " winner, judge_model, rubric_json, rationale, swapped,"
            " elo_a_before, elo_a_after, elo_b_before, elo_b_after)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                new_id(), project_id, done + 1, a["id"], b["id"],
                "a" if score_a == 1.0 else ("b" if score_a == 0.0 else "tie"),
                res.model,
                json.dumps(
                    {"a": (data or {}).get("a"), "b": (data or {}).get("b"),
                     "concern": (data or {}).get("concern")},
                    ensure_ascii=False,
                ),
                str((data or {}).get("rationale") or "")[:1000],
                1 if swapped else 0,
                ra, na, rb, nb,
            ),
        )
        execute(
            "UPDATE idea SET elo = ?, matches = matches + 1,"
            " wins = wins + ?, losses = losses + ?, updated_at = ? WHERE id = ?",
            (
                na, 1 if score_a == 1.0 else 0, 1 if score_a == 0.0 else 0, now(), a["id"],
            ),
        )
        execute(
            "UPDATE idea SET elo = ?, matches = matches + 1,"
            " wins = wins + ?, losses = losses + ?, updated_at = ? WHERE id = ?",
            (
                nb, 1 if score_a == 0.0 else 0, 1 if score_a == 1.0 else 0, now(), b["id"],
            ),
        )
        a["elo"], b["elo"] = na, nb
        done += 1

    queue.progress(job_id, 1.0, "完成")
    top = query_one(
        "SELECT title, elo FROM idea WHERE project_id = ? ORDER BY elo DESC LIMIT 1",
        (project_id,),
    )
    return {
        "matches": done,
        "ideas": len(ideas),
        "top": {"title": top["title"], "elo": top["elo"]} if top else None,
        "cost_cny": round(cost, 4),
    }


# ----------------------------------------------------------------------
# 提案
# ----------------------------------------------------------------------
PROPOSAL_PROMPT = """你帮研究者把一个想法扩写成一份可以给导师看的研究提案（Markdown）。

结构固定：
1. `# 标题`
2. `## 一句话`（40 字内）
3. `## 问题`（要解决什么，为什么现在还没解决）
4. `## 已有工作与缺口`（3~5 条，用要点；只引用给定的证据论文）
5. `## 方法`（分 3~5 步，每步一句，写清输入输出）
6. `## 实验计划`（数据集 / 基线 / 指标 / 最小可证伪实验）
7. `## 预期贡献`（2~3 条，要具体到「别人能拿去做什么」）
8. `## 风险与应对`（2~3 条）

要求：
- 全文 800~1400 字，中文，专有名词保留英文。
- 不要写「本文提出了一种新颖的…」这种空话，每句话都要有信息量。
- 证据论文只从给定列表里选，不要编造引用。
- 如果想法本身有硬伤（比如和已有工作高度重合），在「风险与应对」里直接写出来，不要回避。

只输出 Markdown 正文，不要包代码块。"""


async def generate_proposal(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    idea_id = payload["idea_id"]

    row = query_one("SELECT * FROM idea WHERE id = ? AND project_id = ?", (idea_id, project_id))
    if row is None:
        raise ValueError("想法不存在")
    idea = dict(row)

    # 证据：idea_evidence 里挂的论文 + 库内最相近的几篇
    ev_rows = query(
        "SELECT p.id, p.title, p.tldr FROM idea_evidence e JOIN paper p ON p.id = e.paper_id"
        " WHERE e.idea_id = ? LIMIT 8",
        (idea_id,),
    )
    evidence = [dict(r) for r in ev_rows]
    if len(evidence) < 4:
        from . import graph

        extra = graph.similar_papers(
            project_id,
            f"{idea.get('title','')} {idea.get('one_liner','')} {idea.get('method_sketch','')}",
            top_k=6,
        )
        seen = {e["id"] for e in evidence}
        for h in extra:
            if h["id"] not in seen:
                evidence.append({"id": h["id"], "title": h["title"], "tldr": h["tldr"]})

    queue.progress(job_id, 0.3, "写提案")
    user = (
        "【想法】\n"
        + json.dumps(
            {
                "title": idea.get("title"),
                "one_liner": idea.get("one_liner"),
                "problem": idea.get("problem"),
                "gap": idea.get("gap"),
                "method": idea.get("method_sketch"),
                "why_novel": idea.get("why_novel"),
                "risks": idea.get("risks"),
                "novelty_check": (json.loads(idea.get("novelty_report_json") or "{}") or {}).get("check"),
            },
            ensure_ascii=False,
        )
        + "\n\n【可引用的证据论文】\n"
        + json.dumps([{"title": e["title"][:160], "tldr": (e.get("tldr") or "")[:200]} for e in evidence], ensure_ascii=False)
    )

    res = await chat(
        [
            {"role": "system", "content": PROPOSAL_PROMPT},
            {"role": "user", "content": user},
        ],
        purpose="proposal",
        model=settings_store.effective_model("pro"),
        thinking=True,
        reasoning_effort="medium",
        project_id=project_id,
        job_id=job_id,
    )

    md = (res.content or "").strip()
    if md.startswith("```"):
        md = md.strip("`")
        if md.lower().startswith("markdown"):
            md = md[8:]
    if len(md) < 200:
        raise ValueError("提案生成失败，内容过短")

    execute(
        "UPDATE idea SET proposal_md = ?, updated_at = ? WHERE id = ?",
        (md, now(), idea_id),
    )
    queue.progress(job_id, 1.0, "完成")
    return {
        "idea_id": idea_id,
        "chars": len(md),
        "evidence": len(evidence),
        "cost_cny": round(res.cost_cny, 4),
    }


# ----------------------------------------------------------------------
# 查询
# ----------------------------------------------------------------------
def list_ideas(project_id: str) -> list[dict]:
    rows = query(
        "SELECT id, title, one_liner, strategy, elo, matches, wins, losses,"
        " novelty_status, status, feasibility, impact, proposal_md IS NOT NULL AS has_proposal,"
        " created_at FROM idea WHERE project_id = ?"
        " ORDER BY elo DESC, created_at DESC",
        (project_id,),
    )
    return [dict(r) for r in rows]


def idea_detail(project_id: str, idea_id: str) -> dict | None:
    row = query_one("SELECT * FROM idea WHERE id = ? AND project_id = ?", (idea_id, project_id))
    if row is None:
        return None
    d = dict(row)
    for src in ("novelty_report_json",):
        try:
            d[src.replace("_json", "")] = json.loads(d.pop(src) or "{}")
        except (json.JSONDecodeError, TypeError):
            d[src.replace("_json", "")] = {}

    d["evidence"] = [
        dict(r)
        for r in query(
            "SELECT p.id, p.title, p.tldr FROM idea_evidence e JOIN paper p ON p.id = e.paper_id"
            " WHERE e.idea_id = ?",
            (idea_id,),
        )
    ]
    d["comparisons"] = [
        dict(r)
        for r in query(
            "SELECT round, idea_a, idea_b, winner, rationale, elo_a_after, elo_b_after, created_at"
            " FROM idea_comparison WHERE project_id = ? AND (idea_a = ? OR idea_b = ?)"
            " ORDER BY created_at DESC LIMIT 10",
            (project_id, idea_id, idea_id),
        )
    ]
    return d
