"""论文图谱：三层边，全部本地计算，不花 LLM 钱。

为什么是这三层：

1. **引用耦合（coupling）**：A、B 共同引用同一批工作 → 同一条技术脉络。
   比「A 引用 B」有用得多——同一个课题里的论文往往互不引用（平行工作），
   但它们引用的祖宗高度重合。数据来源是 OpenAlex 存下来的 ``referenced_works``，
   不需要额外请求。能直接对上号的（A 的参考文献就是库里的 B）另记 ``cites``。
2. **语义相似（similar）**：标题 + 摘要 + 结构化理解（problem/method/findings）做
   TF-IDF 余弦。没有 embedding 接口，但 60~200 篇的规模用 TF-IDF 足够稳。
3. **概念共现（same_concept）**：结构化抽取时落库的 ``paper_concept``，
   共享概念多说明在解决同一批问题。

三层互补：耦合看「学术血统」，语义看「字面内容」，概念看「问题结构」。
"""

from __future__ import annotations

import json
import logging
import math
import re
from collections import Counter, defaultdict

from ..db import execute, new_id, query, tx
from ..workers import queue

log = logging.getLogger(__name__)

LAYERS = ("coupling", "similar", "same_concept")

# 参数：都调得比较松，宁可多几条边让用户在图上看出来，也别漏
COUPLING_MIN_SHARED = 2
COUPLING_MIN_JACCARD = 0.04
SIMILAR_TOP_K = 6
SIMILAR_MIN = 0.12
# 概念层：至少共享 2 个概念，且 IDF 加权重叠 >= 0.3（通用概念贡献小，自动被压低）
CONCEPT_MIN_SHARED = 2
CONCEPT_MIN_RATIO = 0.3
MAX_EDGES = 600

_STOP = set(
    """a an the of for and or to in on with by from at as is are was were be been being
    this that these those we our it its their they them than then which while such not no
    can could may might will would should do does did have has had also more most very
    using used use based via towards toward into over under between among within without
    paper papers work works approach approaches method methods result results show shows
    shown propose proposed present presents new novel two three one first second
    however thus therefore although because both each other same different
    """.split()
)
_TOKEN = re.compile(r"[a-z][a-z0-9\-]{2,}")


# ----------------------------------------------------------------------
# 取数据
# ----------------------------------------------------------------------
def _load(project_id: str) -> list[dict]:
    rows = query(
        "SELECT p.id, p.title, p.abstract, p.tldr, p.source, p.source_id, p.published_at,"
        " p.citation_count, p.raw_json, i.problem, i.method, i.findings_json, i.limitations_json"
        " FROM paper p LEFT JOIN paper_insight i"
        "   ON i.paper_id = p.id AND i.schema_version = ("
        "     SELECT MAX(schema_version) FROM paper_insight WHERE paper_id = p.id)"
        " WHERE p.project_id = ?",
        (project_id,),
    )
    concepts: dict[str, set[str]] = defaultdict(set)
    for r in query(
        "SELECT pc.paper_id, c.name FROM paper_concept pc"
        " JOIN concept c ON c.id = pc.concept_id JOIN paper p ON p.id = pc.paper_id"
        " WHERE p.project_id = ?",
        (project_id,),
    ):
        concepts[r["paper_id"]].add(r["name"])

    out = []
    for r in rows:
        try:
            raw = json.loads(r["raw_json"] or "{}")
        except (json.JSONDecodeError, TypeError):
            raw = {}
        refs = raw.get("referenced_works") or []
        if not isinstance(refs, list):
            refs = []
        findings = _as_list(r["findings_json"])
        out.append(
            {
                "id": r["id"],
                "title": r["title"] or "",
                "abstract": r["abstract"] or "",
                "tldr": r["tldr"] or "",
                "source": r["source"],
                "source_id": r["source_id"],
                "year": (r["published_at"] or "")[:4],
                "citations": r["citation_count"] or 0,
                "problem": r["problem"] or "",
                "method": r["method"] or "",
                "findings": findings,
                "refs": {str(x) for x in refs if x},
                "concepts": concepts.get(r["id"], set()),
            }
        )
    return out


def _as_list(v) -> list[str]:
    try:
        x = json.loads(v or "[]")
        return [str(i) for i in x if i] if isinstance(x, list) else []
    except (json.JSONDecodeError, TypeError):
        return []


# ----------------------------------------------------------------------
# 第 1 层：引用耦合
# ----------------------------------------------------------------------
def citation_edges(papers: list[dict]) -> dict[tuple[str, str], tuple[str, float]]:
    """返回 {(a,b): (rel, weight)}，a<b 规范化。"""
    edges: dict[tuple[str, str], tuple[str, float]] = {}

    # 直接引用：A 的参考文献里正好是库里的 B
    by_source = {p["source_id"]: p["id"] for p in papers if p["source_id"]}
    for p in papers:
        for ref in p["refs"]:
            other = by_source.get(ref)
            if other and other != p["id"]:
                a, b = sorted((p["id"], other))
                edges[(a, b)] = ("cites", 1.0)

    # 引用耦合：倒排 ref -> papers，两两计数
    holders: dict[str, list[str]] = defaultdict(list)
    for p in papers:
        for ref in p["refs"]:
            holders[ref].append(p["id"])

    shared: Counter[tuple[str, str]] = Counter()
    for pids in holders.values():
        if len(pids) < 2 or len(pids) > 60:  # 太热门的参考文献（所有人都在引）没区分度
            continue
        pids = sorted(set(pids))
        for i in range(len(pids)):
            for j in range(i + 1, len(pids)):
                shared[(pids[i], pids[j])] += 1

    ref_count = {p["id"]: len(p["refs"]) for p in papers}
    for (a, b), n in shared.items():
        if n < COUPLING_MIN_SHARED:
            continue
        union = ref_count[a] + ref_count[b] - n
        jac = n / union if union else 0.0
        if jac < COUPLING_MIN_JACCARD:
            continue
        key = (a, b)
        if key in edges and edges[key][0] == "cites":
            continue  # 直接引用优先
        edges[key] = ("coupling", round(jac, 4))
    return edges


# ----------------------------------------------------------------------
# 第 2 层：语义相似（TF-IDF 余弦，纯 Python）
# ----------------------------------------------------------------------
def tokenize(text: str) -> list[str]:
    return [t for t in _TOKEN.findall(text.lower()) if t not in _STOP and len(t) > 2]


def _tfidf_vectors(docs: list[list[str]]) -> list[dict[str, float]]:
    df: Counter[str] = Counter()
    for toks in docs:
        df.update(set(toks))
    n = len(docs)
    vecs = []
    for toks in docs:
        tf = Counter(toks)
        v = {}
        for t, c in tf.items():
            w = (1 + math.log(c)) * (math.log((n + 1) / (df[t] + 1)) + 1)
            v[t] = w
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        vecs.append({t: x / norm for t, x in v.items()})
    return vecs


def semantic_edges(papers: list[dict]) -> dict[tuple[str, str], tuple[str, float]]:
    docs = []
    for p in papers:
        text = " ".join(
            [p["title"], p["title"], p["abstract"], p["tldr"], p["problem"], p["method"]]
            + p["findings"]
        )
        docs.append(tokenize(text))

    vecs = _tfidf_vectors(docs)
    ids = [p["id"] for p in papers]

    edges: dict[tuple[str, str], tuple[str, float]] = {}
    for i, vi in enumerate(vecs):
        sims = []
        for j, vj in enumerate(vecs):
            if i == j:
                continue
            # 先比长度，短的那个决定上限
            small, big = (vi, vj) if len(vi) <= len(vj) else (vj, vi)
            s = sum(w * big.get(t, 0.0) for t, w in small.items())
            if s >= SIMILAR_MIN:
                sims.append((s, j))
        sims.sort(reverse=True)
        for s, j in sims[:SIMILAR_TOP_K]:
            a, b = sorted((ids[i], ids[j]))
            key = (a, b)
            if key not in edges or edges[key][1] < s:
                edges[key] = ("similar", round(s, 4))
    return edges


# ----------------------------------------------------------------------
# 第 3 层：概念共现
# ----------------------------------------------------------------------
def concept_edges(papers: list[dict]) -> dict[tuple[str, str], tuple[str, float]]:
    """按 IDF 加权的概念重叠。

    直接用「共享几个概念」会被通用概念带偏：「retrieval augmented generation」
    在 36/61 篇里都出现，共享它毫无信息量。用 IDF 加权后，共享一个冷门概念
    （比如只出现在 3 篇里的「abstention」）比共享三个通用概念更能说明相关。
    """
    n = len(papers)
    freq: Counter[str] = Counter()
    for p in papers:
        freq.update(p["concepts"])

    def idf(c: str) -> float:
        return math.log((n + 1) / (freq[c] + 1)) + 0.2  # +0.2 防止出现 0 权重

    edges: dict[tuple[str, str], tuple[str, float]] = {}
    for i in range(n):
        ci = papers[i]["concepts"]
        if not ci:
            continue
        for j in range(i + 1, n):
            cj = papers[j]["concepts"]
            if not cj:
                continue
            shared = ci & cj
            if len(shared) < CONCEPT_MIN_SHARED:
                continue
            num = sum(idf(c) for c in shared)
            den = sum(idf(c) for c in (ci | cj))
            w = num / den if den else 0.0
            if w < CONCEPT_MIN_RATIO:
                continue
            a, b = sorted((papers[i]["id"], papers[j]["id"]))
            edges[(a, b)] = ("same_concept", round(w, 4))
    return edges


# ----------------------------------------------------------------------
# 构建
# ----------------------------------------------------------------------
def _merge(*layers: dict[tuple[str, str], tuple[str, float]]) -> dict[tuple[str, str], tuple[str, float]]:
    """同一对论文只留最强的一条边；引用 > 耦合 > 概念 > 语义。"""
    prio = {"cites": 3, "coupling": 2, "same_concept": 1, "similar": 0}
    out: dict[tuple[str, str], tuple[str, float]] = {}
    for layer in layers:
        for key, (rel, w) in layer.items():
            cur = out.get(key)
            if cur is None or prio[rel] > prio[cur[0]] or (prio[rel] == prio[cur[0]] and w > cur[1]):
                out[key] = (rel, w)
    return out


async def run_build(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    layers = payload.get("layers") or list(LAYERS)

    queue.progress(job_id, 0.1, "读取论文与概念")
    papers = _load(project_id)
    if len(papers) < 2:
        raise ValueError("至少要有 2 篇已理解的论文才能建图")

    found: dict[str, dict[tuple[str, str], tuple[str, float]]] = {}
    if "coupling" in layers:
        queue.progress(job_id, 0.3, "计算引用耦合")
        found["coupling"] = citation_edges(papers)
    if "similar" in layers:
        queue.progress(job_id, 0.55, "计算语义相似")
        found["similar"] = semantic_edges(papers)
    if "same_concept" in layers:
        queue.progress(job_id, 0.75, "计算概念共现")
        found["same_concept"] = concept_edges(papers)

    queue.progress(job_id, 0.9, "写入图谱")
    _save(project_id, papers, found)

    counts = Counter(rel for layer in found.values() for rel, _ in layer.values())
    execute(
        "INSERT INTO graph_run(id, project_id, layers_json, nodes, edges_json, cost_cny)"
        " VALUES (?,?,?,?,?,0)",
        (
            new_id(), project_id, json.dumps(layers, ensure_ascii=False), len(papers),
            json.dumps(dict(counts), ensure_ascii=False),
        ),
    )
    queue.progress(job_id, 1.0, "完成")
    total = sum(len(v) for v in found.values())
    return {"nodes": len(papers), "edges": total, "by_rel": dict(counts), "cost_cny": 0.0}


def _save(
    project_id: str,
    papers: list[dict],
    layers: dict[str, dict[tuple[str, str], tuple[str, float]]],
) -> None:
    """每一层单独存边，界面上可以按层过滤。

    同一对论文在不同层里各有一条边（PRIMARY KEY 带 rel），
    展示时再按优先级去重，这样「只看语义层」也有边可看。
    """
    ids = [p["id"] for p in papers]
    with tx() as conn:
        ph = ",".join("?" * len(ids))
        conn.execute(f"DELETE FROM paper_relation WHERE src_id IN ({ph})", ids)
        for layer_edges in layers.values():
            for (a, b), (rel, w) in layer_edges.items():
                conn.execute(
                    "INSERT OR REPLACE INTO paper_relation(src_id, dst_id, rel, weight, source)"
                    " VALUES (?,?,?,?,?)",
                    (a, b, rel, w, "graph"),
                )


# ----------------------------------------------------------------------
# 查询
# ----------------------------------------------------------------------
def snapshot(project_id: str, layers: list[str] | None = None, limit: int = MAX_EDGES) -> dict:
    papers = _load(project_id)
    by_id = {p["id"]: p for p in papers}

    rels = layers or ["cites", "coupling", "same_concept", "similar"]
    ph = ",".join("?" * len(rels))
    rows = query(
        "SELECT r.src_id, r.dst_id, r.rel, r.weight FROM paper_relation r"
        f" JOIN paper p ON p.id = r.src_id WHERE p.project_id = ? AND r.rel IN ({ph})"
        " ORDER BY r.weight DESC LIMIT ?",
        (project_id, *rels, limit * 3),
    )

    # 同一对论文可能同时有语义边和概念边，展示时只留「最强」的那条，
    # 但层的统计仍然按原始边算，方便用户判断这个图是靠什么连起来的
    prio = {"cites": 3, "coupling": 2, "same_concept": 1, "similar": 0}
    best: dict[tuple[str, str], tuple[str, float]] = {}
    for r in rows:
        if r["src_id"] not in by_id or r["dst_id"] not in by_id:
            continue
        key = (r["src_id"], r["dst_id"])
        cur = best.get(key)
        if cur is None or prio[r["rel"]] > prio[cur[0]] or (
            prio[r["rel"]] == prio[cur[0]] and r["weight"] > cur[1]
        ):
            best[key] = (r["rel"], r["weight"])

    degree: Counter[str] = Counter()
    edges = []
    for (a, b), (rel, w) in sorted(best.items(), key=lambda kv: -kv[1][1])[:limit]:
        degree[a] += 1
        degree[b] += 1
        edges.append({"source": a, "target": b, "rel": rel, "weight": round(w, 4)})

    nodes = []
    for p in papers:
        nodes.append(
            {
                "id": p["id"],
                "title": p["title"],
                "year": p["year"],
                "source": p["source"],
                "citations": p["citations"],
                "degree": degree.get(p["id"], 0),
                "concepts": sorted(p["concepts"])[:6],
                "problem": p["problem"][:200],
            }
        )
    nodes.sort(key=lambda n: (-n["degree"], -n["citations"]))

    last = query(
        "SELECT created_at, edges_json FROM graph_run WHERE project_id = ?"
        " ORDER BY created_at DESC LIMIT 1",
        (project_id,),
    )
    raw: dict = {}
    if last:
        try:
            raw = json.loads(last[0]["edges_json"] or "{}")
        except (json.JSONDecodeError, TypeError):
            raw = {}

    return {
        "nodes": nodes,
        "edges": edges,
        "stats": {
            "papers": len(nodes),
            "edges": len(edges),
            "isolated": sum(1 for n in nodes if n["degree"] == 0),
            "by_rel": _count_rel(edges),
            "raw_by_rel": raw,
            "built_at": last[0]["created_at"] if last else None,
        },
    }


def _count_rel(edges: list[dict]) -> dict:
    c: Counter[str] = Counter(e["rel"] for e in edges)
    return dict(c)


def neighbors(project_id: str, paper_id: str) -> list[dict]:
    rows = query(
        "SELECT r.dst_id AS other, r.rel, r.weight FROM paper_relation r"
        " JOIN paper p ON p.id = r.src_id"
        " WHERE p.project_id = ? AND r.src_id = ?"
        " UNION ALL "
        "SELECT r.src_id AS other, r.rel, r.weight FROM paper_relation r"
        " JOIN paper p ON p.id = r.dst_id"
        " WHERE p.project_id = ? AND r.dst_id = ?"
        " ORDER BY weight DESC",
        (project_id, paper_id, project_id, paper_id),
    )
    out = []
    for r in rows:
        p = query("SELECT id, title FROM paper WHERE id = ?", (r["other"],))
        if p:
            out.append({"id": p[0]["id"], "title": p[0]["title"], "rel": r["rel"], "weight": r["weight"]})
    return out


def similar_papers(project_id: str, text: str, top_k: int = 8) -> list[dict]:
    """给一段文字（比如一条 idea）找库里最像的论文。

    和建图用同一套 TF-IDF，保证「图上的邻居」和「查重结果」口径一致。
    """
    papers = _load(project_id)
    if not papers:
        return []
    docs = []
    for p in papers:
        docs.append(
            tokenize(
                " ".join([p["title"], p["title"], p["abstract"], p["tldr"], p["problem"], p["method"]]
                         + p["findings"])
            )
        )
    docs.append(tokenize(text))
    vecs = _tfidf_vectors(docs)
    q = vecs[-1]

    # 中文查询（比如用户手写的想法）切不出英文词，余弦全为 0。
    # 这种情况下退回「按被引排序」：同一个项目里的论文本来就同主题，
    # 至少能给模型一批真实的候选，而不是空手让它编。
    if not q:
        ranked = sorted(papers, key=lambda p: -(p["citations"] or 0))[:top_k]
        return [
            {
                "id": p["id"],
                "title": p["title"],
                "year": p["year"],
                "source": p["source"],
                "tldr": p["tldr"],
                "problem": p["problem"],
                "method": p["method"],
                "score": 0.0,
                "fallback": True,
            }
            for p in ranked
        ]

    scored = []
    for i, v in enumerate(vecs[:-1]):
        s = sum(w * v.get(t, 0.0) for t, w in q.items())
        if s > 0:
            scored.append((s, i))
    scored.sort(reverse=True)

    out = []
    for s, i in scored[:top_k]:
        p = papers[i]
        out.append(
            {
                "id": p["id"],
                "title": p["title"],
                "year": p["year"],
                "source": p["source"],
                "tldr": p["tldr"],
                "problem": p["problem"],
                "method": p["method"],
                "score": round(s, 4),
            }
        )
    return out
