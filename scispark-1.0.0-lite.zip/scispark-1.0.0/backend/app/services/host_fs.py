"""宿主目录访问：在界面里选文件夹，后端读文件。

为什么要这一层：应用跑在 Docker 里，容器只能看见被挂载进来的目录，
浏览器又没法调用系统的「打开文件夹」对话框。所以做法是

1. docker-compose 把宿主 HOME 只读挂到容器里的 ``HOST_MOUNT``（默认 /host_home）；
2. 界面里浏览、展示的都是「宿主路径」（``/Users/you/papers``），和后端 IO 前
   用 :func:`to_container` 换成容器路径 —— 用户看到的路径和 Finder 里一致；
3. 选中的目录写进 ``app_setting.local_papers_root``，优先级高于 .env，
   换目录不用改配置、不用重启容器。

不在容器里跑（本地 ``make dev``）时没有挂载，此时宿主路径就是真实路径，
:func:`to_container` 直接透传。
"""

from __future__ import annotations

import logging
import os
import sqlite3
import stat
from pathlib import Path

from ..config import settings
from ..db import query, tx
from ..sources import local_reader

log = logging.getLogger(__name__)

ROOT_KEY = "local_papers_root"
COUNT_LIMIT = 300          # 统计子目录里有多少篇论文时最多数这么多
COUNT_DEPTH = 2

_LABELS = {"Desktop": "桌面", "Documents": "文稿", "Downloads": "下载"}


# ----------------------------------------------------------------------
# 路径映射
# ----------------------------------------------------------------------
def is_dir(p: Path | str) -> bool:
    """安全的 is_dir：macOS 的 TCC 会让「文稿 / 桌面」直接抛 PermissionError，
    不能让一个不可读的目录把整个浏览接口带崩。"""
    try:
        return Path(p).is_dir()
    except OSError:
        return False


def _mounts() -> list[tuple[str, str]]:
    """[(宿主前缀, 容器前缀)]，只保留容器里确实存在的挂载点。"""
    host = (settings.host_home_dir or "").strip().rstrip("/")
    cont = (settings.host_mount or "").strip().rstrip("/")
    if host and cont and is_dir(cont):
        return [(host, cont)]
    return []


def norm(p: str) -> str:
    """规范化成绝对路径字符串：折叠 ``..`` / ``.``，去掉结尾斜杠。"""
    p = (p or "").strip()
    if not p:
        return ""
    p = os.path.normpath(p)
    return "/" if p == "/" else p.rstrip("/")


def to_container(host_path: str) -> Path:
    """宿主路径 → 容器内可读路径。越界抛 ValueError。"""
    p = norm(host_path)
    if not p:
        raise ValueError("路径为空")
    mounts = _mounts()
    for host, cont in mounts:
        if p == host:
            return Path(cont)
        if p.startswith(host + "/"):
            return Path(cont) / p[len(host) + 1 :]
    if mounts:
        allowed = "、".join(h for h, _ in mounts)
        raise ValueError(f"这个目录不在可访问范围内（当前只能访问 {allowed}）")
    return Path(p)  # 本地直跑：宿主路径就是真实路径


def to_host(container_path: Path | str) -> str:
    """容器路径 → 宿主路径（给界面显示用）。"""
    s = norm(str(container_path))
    for host, cont in _mounts():
        if s == cont:
            return host
        if s.startswith(cont + "/"):
            return host + s[len(cont) :]
    return s


def is_allowed(host_path: str) -> bool:
    try:
        to_container(host_path)
        return True
    except ValueError:
        return False


def parent_of(host_path: str) -> str | None:
    """上一层目录；已经到挂载根（或文件系统根）时返回 None。"""
    p = norm(host_path)
    mounts = [h for h, _ in _mounts()]
    if p in mounts or p in ("/", ""):
        return None
    parent = norm(os.path.dirname(p))
    if mounts and not any(parent == h or parent.startswith(h + "/") for h in mounts):
        return None
    return parent or None


# ----------------------------------------------------------------------
# 当前根目录
# ----------------------------------------------------------------------
def default_root() -> str:
    """没选过目录时的默认值。

    - 容器模式：宿主 HOME（挂载点对应的那个路径）
    - 原生模式（没有挂载）：直接用本机 HOME，别拿容器里的 /local_papers 凑数
    """
    mounts = _mounts()
    for host, _ in mounts:
        return host
    if not mounts:
        return norm(str(Path.home()))
    return norm(settings.local_papers_dir)


def get_root() -> str:
    try:
        row = query("SELECT value FROM app_setting WHERE key = ?", (ROOT_KEY,))
    except sqlite3.Error:  # 测试环境还没建表
        row = None
    if row:
        v = norm(row[0]["value"] or "")
        if v:
            return v
    return default_root()


def set_root(host_path: str) -> str:
    p = norm(host_path)
    cp = to_container(p)  # 越界直接抛错
    if not is_dir(cp):
        raise ValueError("目录不存在或没有读取权限")
    with tx() as conn:
        conn.execute(
            "INSERT INTO app_setting(key, value, is_secret, updated_at)"
            " VALUES (?,?,0,datetime('now','localtime'))"
            " ON CONFLICT(key) DO UPDATE SET value=excluded.value,"
            " updated_at=excluded.updated_at",
            (ROOT_KEY, p),
        )
    log.info("本地论文目录已切换到 %s", p)
    return p


# ----------------------------------------------------------------------
# 目录浏览
# ----------------------------------------------------------------------
def _count_papers(d: Path) -> int:
    """浅层统计这个目录下有多少篇可读论文，用于给用户提示。"""
    n = 0
    stack: list[tuple[Path, int]] = [(d, 0)]
    while stack and n < COUNT_LIMIT:
        cur, depth = stack.pop()
        try:
            entries = list(cur.iterdir())
        except (PermissionError, OSError):
            continue
        for e in entries:
            if e.name.startswith(".") or e.name in local_reader.SKIP_DIRS:
                continue
            try:
                if is_dir(e):
                    if depth < COUNT_DEPTH:
                        stack.append((e, depth + 1))
                elif e.suffix.lower() in local_reader.SUPPORTED:
                    n += 1
            except OSError:
                continue
    return n


def quick_links() -> list[dict]:
    """常用位置，省得一层层点。"""
    out: list[dict] = []
    for host, cont in _mounts():
        out.append({"label": "主目录", "path": host})
        for name, label in _LABELS.items():
            if is_dir(Path(cont) / name):
                out.append({"label": label, "path": f"{host}/{name}"})
    if not _mounts():
        legacy = norm(settings.local_papers_dir)
        if is_dir(legacy):
            out.append({"label": "默认目录", "path": legacy})
    return out


def browse(host_path: str | None = None) -> dict:
    """列一个目录下的子目录和可读文件（路径全部是宿主路径）。"""
    p = norm(host_path) if host_path else get_root()
    cp = to_container(p)

    if not is_dir(cp):
        return {
            "exists": False,
            "path": p,
            "root": get_root(),
            "parent": parent_of(p),
            "dirs": [],
            "files": [],
            "denied": [],
            "quick": quick_links(),
        }

    dirs, files, denied = [], [], []
    try:
        entries = sorted(cp.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
    except (PermissionError, OSError) as e:
        raise ValueError(f"无法读取目录：{e}") from e

    for e in entries:
        if e.name.startswith(".") or e.name in local_reader.SKIP_DIRS:
            continue
        hp = to_host(e)
        try:
            st = e.stat()
        except OSError:
            # macOS 的隐私保护会让「文稿 / 桌面」这类目录直接 EPERM。
            # 单独列出来告诉用户「有，但没授权」，比默默隐藏好。
            denied.append({"name": e.name, "path": hp})
            continue
        if stat.S_ISDIR(st.st_mode):
            dirs.append({"name": e.name, "path": hp, "rel_path": hp, "papers": _count_papers(e)})
        elif e.suffix.lower() in local_reader.SUPPORTED:
            files.append(
                {
                    "name": e.name,
                    "path": hp,
                    "rel_path": hp,
                    "ext": e.suffix.lower().lstrip("."),
                    "size": st.st_size,
                }
            )

    return {
        "exists": True,
        "path": p,
        "root": get_root(),
        "parent": parent_of(p),
        "dirs": dirs,
        "files": files,
        "denied": denied,
        "quick": quick_links(),
    }


def root_info() -> dict:
    p = get_root()
    try:
        cp = to_container(p)
        exists = is_dir(cp)
    except ValueError:
        exists = False
    return {
        "root": p,
        "exists": exists,
        "parent": parent_of(p),
        "quick": quick_links(),
        "host_home": (_mounts()[0][0] if _mounts() else ""),
        "mounted": bool(_mounts()),
    }
