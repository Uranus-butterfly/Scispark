"""调研编排：扩展检索式 → 多源抓取 → 去重 → 粗排 → AI 精排 → 入库 → 结构化理解。"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import sqlite3
from pathlib import Path

from ..db import execute, fts_index_paper, new_id, now, query, query_one
from ..llm.client import chat_json
from ..sources import arxiv_source, openalex_source
from ..sources.base import PaperRecord
from ..sources.normalize import coarse_rank, dedupe, normalize_title, tokenize
from ..services import settings_store
from ..workers import queue
from . import batches
from .understand import understand_papers

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT_DIR = Path(__file__).resolve().parent.parent / "llm" / "prompts"


def _prompt(name: str) -> str:
    try:
        return prompt_loader.load(name)
    except OSError:
        return "只输出 JSON。"


# ----------------------------------------------------------------------
# 期刊偏好
# ----------------------------------------------------------------------
DEFAULT_VENUE_PREFS: dict = {"preferred": [], "journals_only": False, "min_citations": 0}


def _norm_venue(v: str) -> str:
    return " ".join(re.sub(r"[^a-z0-9]+", " ", (v or "").lower()).split())


def load_venue_prefs(project_id: str) -> dict:
    row = query_one("SELECT venue_prefs_json FROM project WHERE id = ?", (project_id,))
    if row is None or not row["venue_prefs_json"]:
        return dict(DEFAULT_VENUE_PREFS)
    try:
        d = json.loads(row["venue_prefs_json"])
    except (json.JSONDecodeError, TypeError):
        return dict(DEFAULT_VENUE_PREFS)
    out = dict(DEFAULT_VENUE_PREFS)
    if isinstance(d, dict):
        out["preferred"] = [str(x) for x in (d.get("preferred") or []) if str(x).strip()][:20]
        out["journals_only"] = bool(d.get("journals_only"))
        try:
            out["min_citations"] = max(0, int(d.get("min_citations") or 0))
        except (TypeError, ValueError):
            out["min_citations"] = 0
    return out


def save_venue_prefs(project_id: str, prefs: dict) -> dict:
    clean = {
        "preferred": [str(x).strip() for x in (prefs.get("preferred") or []) if str(x).strip()][:20],
        "journals_only": bool(prefs.get("journals_only")),
        "min_citations": max(0, min(10000, int(prefs.get("min_citations") or 0))),
    }
    execute(
        "UPDATE project SET venue_prefs_json = ? WHERE id = ?",
        (json.dumps(clean, ensure_ascii=False), project_id),
    )
    return clean


def is_preprint(rec: PaperRecord) -> bool:
    """arXiv 源、或者 venue 为空 / 含 preprint 字样的，都算预印本。"""
    if rec.source == "arxiv":
        return True
    v = _norm_venue(rec.venue)
    return (not v) or "arxiv" in v or "preprint" in v or "biorxiv" in v or "ssrn" in v


def venue_multiplier(rec: PaperRecord, prefs: dict) -> float:
    """期刊偏好折算成排序权重。

    不做硬过滤（除了用户明确勾的「只要期刊」）：新发表的好论文被引一定是 0，
    直接按影响因子砍掉会漏掉最新的工作，所以只降权不删除。
    """
    mult = 1.0
    wanted = [_norm_venue(x) for x in (prefs.get("preferred") or []) if x.strip()]
    venue = _norm_venue(rec.venue)
    if wanted and venue:
        for w in wanted:
            if w and (w in venue or venue in w):
                mult *= 2.5
                break
    mc = int(prefs.get("min_citations") or 0)
    if mc and (rec.citation_count or 0) < mc:
        mult *= 0.6
    if prefs.get("journals_only") and is_preprint(rec):
        mult *= 0.3
    return mult


# ----------------------------------------------------------------------
# 1. 查询扩展
# ----------------------------------------------------------------------
async def expand_query(project_id: str, query: str, job_id: str | None = None) -> dict:
    system = _prompt("expand_query.md")
    user = f"研究主题：{query}\n\n请输出检索式 JSON。"
    data, _ = await chat_json(
        [{"role": "system", "content": system}, {"role": "user", "content": user}],
        purpose="expand_query",
        model=settings_store.effective_model("flash"),
        thinking=False,
        temperature=0.2,
        project_id=project_id,
        job_id=job_id,
        fallback=None,
    )
    if not isinstance(data, dict) or not data.get("phrases"):
        # 兜底：直接把原文当检索短语
        toks = [t for t in tokenize(query) if len(t) > 2]
        return {
            "phrases": [query.strip()],
            "keywords": toks or tokenize(query),
            "arxiv_cats": [],
            "exclude": [],
        }
    phrases = [str(p) for p in data.get("phrases", []) if str(p).strip()][:5]
    keywords = [str(k).lower() for k in data.get("keywords", []) if str(k).strip()]
    if not keywords:
        keywords = [t for p in phrases for t in tokenize(p)]
    return {
        "phrases": phrases or [query.strip()],
        "keywords": keywords[:15],
        "arxiv_cats": [str(c) for c in data.get("arxiv_cats", []) if str(c).strip()][:3],
        "exclude": [str(e).lower() for e in data.get("exclude", []) if str(e).strip()][:4],
    }


# ----------------------------------------------------------------------
# 2. AI 精排
# ----------------------------------------------------------------------
async def rerank(
    project_id: str,
    query: str,
    records: list[PaperRecord],
    *,
    job_id: str | None = None,
    batch_size: int = 20,
    min_score: float = 4.0,
    on_progress=None,
    venue_prefs: dict | None = None,
) -> list[tuple[PaperRecord, float, str]]:
    system = _prompt("rerank.md")
    scored: list[tuple[PaperRecord, float, str]] = []

    for bi in range(0, len(records), batch_size):
        batch = records[bi : bi + batch_size]
        payload = [
            {
                "id": f"r{i}",
                "title": r.title,
                "abstract": (r.abstract or "")[:700],
                "venue": (r.venue or "")[:80],
                "citations": r.citation_count or 0,
            }
            for i, r in enumerate(batch)
        ]
        pref_note = ""
        if venue_prefs and (venue_prefs.get("preferred") or venue_prefs.get("journals_only")):
            parts = []
            if venue_prefs.get("preferred"):
                parts.append("优先 " + "、".join(venue_prefs["preferred"][:8]) + " 等期刊/会议")
            if venue_prefs.get("journals_only"):
                parts.append("优先正式发表的期刊论文，预印本次之")
            pref_note = "\n\n【用户的发表渠道偏好】" + "；".join(parts) + \
                "\n同等相关度下，符合偏好的可以给更高分，但**不要为了期刊而收录不相关的论文**。"
        user = (
            f"研究主题：{query}{pref_note}\n\n请给下列 {len(payload)} 篇论文打分：\n"
            + json.dumps(payload, ensure_ascii=False)
        )
        data, _ = await chat_json(
            [{"role": "system", "content": system}, {"role": "user", "content": user}],
            purpose="rerank",
            model=settings_store.effective_model("flash"),
            thinking=False,
            temperature=0.0,
            project_id=project_id,
            job_id=job_id,
            fallback=None,
        )
        items = (data or {}).get("items") if isinstance(data, dict) else None
        by_id: dict[str, dict] = {}
        if isinstance(items, list):
            by_id = {str(it.get("id")): it for it in items if isinstance(it, dict)}

        for i, r in enumerate(batch):
            it = by_id.get(f"r{i}")
            if it is None and isinstance(items, list) and i < len(items):
                it = items[i] if isinstance(items[i], dict) else None
            if it is None:
                continue
            try:
                s = float(it.get("score", 0))
            except (TypeError, ValueError):
                continue
            scored.append((r, s, str(it.get("reason") or "")[:120]))

        if on_progress:
            await on_progress(min(1.0, (bi + len(batch)) / len(records)))

    scored.sort(key=lambda x: x[1], reverse=True)
    kept = [x for x in scored if x[1] >= min_score]
    return kept or scored[:20]


# ----------------------------------------------------------------------
# 3. 入库
# ----------------------------------------------------------------------
def upsert_paper(
    project_id: str,
    rec: PaperRecord,
    *,
    relevance: float | None = None,
    reason: str | None = None,
    batch_id: str | None = None,
) -> str | None:
    title_norm = normalize_title(rec.title)
    if not title_norm:
        return None

    existing = query_one(
        "SELECT id, relevance FROM paper WHERE project_id = ? AND title_norm = ?",
        (project_id, title_norm),
    )
    if existing:
        if relevance is not None and (existing["relevance"] is None or relevance > existing["relevance"]):
            execute(
                "UPDATE paper SET relevance = ?, relevance_reason = ? WHERE id = ?",
                (relevance, reason, existing["id"]),
            )
        return existing["id"]

    pid = new_id()
    try:
        execute(
            "INSERT INTO paper(id, project_id, source, source_id, doi, arxiv_id, title, title_norm,"
            " abstract, tldr, tldr_source, authors_json, year, venue, url, pdf_url,"
            " citation_count, published_at, relevance, relevance_reason, status, raw_json, batch_id)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                pid, project_id, rec.source, rec.source_id, rec.doi or None, rec.arxiv_id or None,
                rec.title, title_norm, rec.abstract, rec.tldr or None, rec.tldr_source or None,
                json.dumps(rec.authors, ensure_ascii=False), rec.year, rec.venue or None,
                rec.url or None, rec.pdf_url or None, rec.citation_count or 0,
                rec.published_at or None, relevance, reason,
                "ranked" if relevance is not None else "new",
                json.dumps({"referenced_works": rec.referenced_works[:200]}, ensure_ascii=False),
                batch_id,
            ),
        )
    except sqlite3.IntegrityError:
        row = query_one(
            "SELECT id FROM paper WHERE project_id = ? AND title_norm = ?", (project_id, title_norm)
        )
        return row["id"] if row else None

    fts_index_paper(pid)
    return pid


# ----------------------------------------------------------------------
# 4. 主流程
# ----------------------------------------------------------------------
async def run_ingest(job_id: str, payload: dict) -> dict:
    project_id: str = payload["project_id"]
    query_text: str = payload["query"]
    max_papers: int = int(payload.get("max_papers") or 60)
    do_understand: bool = bool(payload.get("understand", True))
    date_from: str | None = payload.get("date_from")
    date_to: str | None = payload.get("date_to")

    # --- 1 扩展 ---
    queue.progress(job_id, 0.03, "扩展检索式")
    plan = await expand_query(project_id, query_text, job_id)

    # --- 2 检索 ---
    queue.progress(job_id, 0.08, f"检索 arXiv（{len(plan['phrases'])} 组短语）")
    arxiv_recs, arxiv_stats = await arxiv_source.search(
        plan["phrases"], plan["arxiv_cats"], per_query=60,
        date_from=date_from, date_to=date_to,
    )

    queue.progress(job_id, 0.30, "检索 OpenAlex")
    oa_recs, oa_stats = await openalex_source.search(
        plan["phrases"], per_query=50, date_from=date_from, date_to=date_to,
    )

    # --- 3 去重 + 过滤 ---
    queue.progress(job_id, 0.40, "去重与粗排")
    merged = dedupe(arxiv_recs + oa_recs)
    excludes = plan.get("exclude") or []
    if excludes:
        merged = [
            r for r in merged
            if not any(x in (r.title or "").lower() for x in excludes)
        ]

    # 库内已有论文不参与精排，省 token
    existing_norms = {
        row["title_norm"]
        for row in query("SELECT title_norm FROM paper WHERE project_id = ?", (project_id,))
    }
    fresh = [r for r in merged if normalize_title(r.title) not in existing_norms]

    # --- 4 粗排（叠加期刊偏好） ---
    prefs = payload.get("venue_prefs") or load_venue_prefs(project_id)
    if prefs.get("journals_only"):
        before = len(fresh)
        fresh = [r for r in fresh if not is_preprint(r)] or fresh
        if len(fresh) != before:
            queue.progress(job_id, 0.42, f"只要期刊：{before} → {len(fresh)} 篇")

    ranked = coarse_rank(fresh, plan["keywords"])
    if prefs.get("preferred") or prefs.get("min_citations"):
        ranked = sorted(
            ((r, sc * venue_multiplier(r, prefs)) for r, sc in ranked),
            key=lambda x: -x[1],
        )
    # 精排池：至少 60 篇，最多 180 篇（再多收益递减，纯烧 token）
    pool_size = min(max(max_papers * 3, 60), 180)
    pool = [r for r, _ in ranked[:pool_size]]

    # --- 5 精排 ---
    cost_note = []
    final: list[tuple[PaperRecord, float, str]] = []
    if pool:
        queue.progress(job_id, 0.45, f"AI 精排（{len(pool)} 篇）")

        async def _rp(p: float) -> None:
            queue.progress(job_id, 0.45 + 0.25 * p, f"AI 精排 {int(p * 100)}%")

        final = await rerank(
            project_id, query_text, pool, job_id=job_id, on_progress=_rp, venue_prefs=prefs
        )
        final = final[:max_papers]

    # --- 6 入库 ---
    # 每调研一次就开一个批次，这样论文库里能按「哪个方向调研来的」分开看。
    # 批次名默认取检索主题，用户在界面上可以改。
    queue.progress(job_id, 0.72, "写入论文库")
    batch_id = batches.create(
        project_id,
        label=payload.get("batch_label"),
        query_text=query_text,
        date_from=date_from,
        date_to=date_to,
    )
    new_ids: list[str] = []
    for rec, score, reason in final:
        pid = upsert_paper(
            project_id,
            rec,
            relevance=min(1.0, score / 10.0),
            reason=reason,
            batch_id=batch_id,
        )
        if pid:
            new_ids.append(pid)

    # --- 7 理解 ---
    understood: dict = {}
    if do_understand and new_ids:
        queue.progress(job_id, 0.78, f"结构化理解（{len(new_ids)} 篇）")

        async def _up(p: float) -> None:
            queue.progress(job_id, 0.78 + 0.20 * p, f"结构化理解 {int(p * 100)}%")

        understood = await understand_papers(
            project_id, new_ids, job_id=job_id, on_progress=_up
        )

    queue.progress(job_id, 1.0, "完成")
    total_cost = float((understood or {}).get("cost_cny") or 0)
    batches.finish(batch_id, len(new_ids), total_cost)
    return {
        "expanded": plan,
        "batch_id": batch_id,
        "batch_label": payload.get("batch_label") or batches.auto_label(query_text),
        "sources": {
            "arxiv": {**arxiv_stats, "records": len(arxiv_recs)},
            "openalex": {**oa_stats, "records": len(oa_recs)},
        },
        "deduped": len(merged),
        "fresh": len(fresh),
        "pool": len(pool),
        "selected": len(final),
        "inserted": len(new_ids),
        "understood": understood,
        "cost_note": cost_note,
        "finished_at": now(),
    }


async def run_understand_job(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    limit = payload.get("limit")
    paper_ids = payload.get("paper_ids")

    async def _up(p: float) -> None:
        queue.progress(job_id, p, f"结构化理解 {int(p * 100)}%")

    return await understand_papers(
        project_id, paper_ids, limit=limit, job_id=job_id, on_progress=_up
    )


def start_ingest(project_id: str, **kwargs) -> str:
    payload = {"project_id": project_id, **kwargs}
    return queue.submit("ingest", project_id, payload, run_ingest)


def start_understand(project_id: str, **kwargs) -> str:
    payload = {"project_id": project_id, **kwargs}
    return queue.submit("understand", project_id, payload, run_understand_job)
