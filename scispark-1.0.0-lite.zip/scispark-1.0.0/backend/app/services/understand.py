"""批量结构化理解。

设计要点：
- 一批多篇（默认 12），一次调用产出整批，摊薄成本
- 关闭 thinking：抽取任务不需要推理链，reasoning token 按输出价计费，很贵
- limitations 必须带原文 quote，便于人工核对，防幻觉
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from ..db import execute, fts_index_paper, new_id, now, query, query_one, tx
from ..llm.client import chat_json
from ..services import settings_store

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT = Path(__file__).resolve().parent.parent / "llm" / "prompts" / "understand_paper.md"
ABSTRACT_LIMIT = 1400


def _load_prompt() -> str:
    try:
        return prompt_loader.load("understand_paper.md")
    except OSError:
        return "你是资深审稿人。逐篇抽取结构化理解，只输出 JSON。"


def _concept_id(project_id: str, name: str) -> str:
    norm = " ".join(name.strip().lower().split())
    row = query_one(
        "SELECT id FROM concept WHERE project_id = ? AND name_norm = ?", (project_id, norm)
    )
    if row:
        return row["id"]
    cid = new_id()
    execute(
        "INSERT INTO concept(id, project_id, name, name_norm) VALUES (?,?,?,?)",
        (cid, project_id, name.strip(), norm),
    )
    return cid


def _save_one(project_id: str, paper_id: str, item: dict, model: str, tin: int, tout: int) -> None:
    def as_list(v) -> list:
        if isinstance(v, list):
            return [x for x in v if x not in (None, "")]
        if isinstance(v, str) and v.strip():
            return [v.strip()]
        return []

    def as_text(v) -> str:
        if isinstance(v, str):
            return v.strip()
        if isinstance(v, list):
            return "；".join(str(x) for x in v if x)
        return ""

    limitations = as_list(item.get("limitations"))
    findings = as_list(item.get("findings"))
    datasets = as_list(item.get("datasets"))
    claims = item.get("key_claims") or []
    concepts = as_list(item.get("concepts"))

    quality = item.get("quality")
    try:
        quality = float(quality) if quality is not None else None
    except (TypeError, ValueError):
        quality = None

    with tx() as conn:
        conn.execute(
            "INSERT INTO paper_insight(id, paper_id, schema_version, model, problem, method,"
            " datasets_json, findings_json, limitations_json, key_claims_json, concepts_json,"
            " quality, tokens_in, tokens_out)"
            " VALUES (?,?,1,?,?,?,?,?,?,?,?,?,?,?)"
            " ON CONFLICT(paper_id, schema_version) DO UPDATE SET"
            " model=excluded.model, problem=excluded.problem, method=excluded.method,"
            " datasets_json=excluded.datasets_json, findings_json=excluded.findings_json,"
            " limitations_json=excluded.limitations_json, key_claims_json=excluded.key_claims_json,"
            " concepts_json=excluded.concepts_json, quality=excluded.quality,"
            " tokens_in=excluded.tokens_in, tokens_out=excluded.tokens_out",
            (
                new_id(), paper_id, model,
                as_text(item.get("problem")), as_text(item.get("method")),
                json.dumps(datasets, ensure_ascii=False),
                json.dumps(findings, ensure_ascii=False),
                json.dumps(limitations, ensure_ascii=False),
                json.dumps(claims, ensure_ascii=False),
                json.dumps(concepts, ensure_ascii=False),
                quality, tin, tout,
            ),
        )
        conn.execute("DELETE FROM claim WHERE paper_id = ?", (paper_id,))
        for c in claims:
            if not isinstance(c, dict) or not c.get("claim"):
                continue
            ctype = c.get("type") if c.get("type") in ("finding", "limitation", "assumption", "result") else "finding"
            polarity = -1 if ctype == "limitation" else 1
            conn.execute(
                "INSERT INTO claim(id, paper_id, text, claim_type, polarity, quote, confidence)"
                " VALUES (?,?,?,?,?,?,?)",
                (new_id(), paper_id, str(c["claim"])[:800], ctype, polarity,
                 str(c.get("quote") or "")[:800], 0.7),
            )
        conn.execute("UPDATE paper SET status='understood' WHERE id = ?", (paper_id,))

    for name in concepts:
        cid = _concept_id(project_id, str(name))
        execute(
            "INSERT OR IGNORE INTO paper_concept(paper_id, concept_id, role, weight) VALUES (?,?,?,1.0)",
            (paper_id, cid, "uses"),
        )

    execute(
        "UPDATE concept SET paper_count = (SELECT COUNT(*) FROM paper_concept WHERE concept_id = concept.id)"
        " WHERE project_id = ?",
        (project_id,),
    )
    fts_index_paper(paper_id)


async def understand_papers(
    project_id: str,
    paper_ids: list[str] | None = None,
    *,
    limit: int | None = None,
    job_id: str | None = None,
    batch_size: int = 12,
    on_progress=None,
) -> dict:
    """对指定论文（或该项目下所有 status='new'/'ranked' 的论文）做结构化理解。"""
    if paper_ids:
        placeholders = ",".join("?" * len(paper_ids))
        rows = query(
            f"SELECT id, title, abstract, tldr FROM paper WHERE project_id = ? AND id IN ({placeholders})",
            (project_id, *paper_ids),
        )
    else:
        sql = (
            "SELECT id, title, abstract, tldr FROM paper"
            " WHERE project_id = ? AND status IN ('new','ranked') ORDER BY relevance DESC NULLS LAST"
        )
        params: list = [project_id]
        if limit:
            sql += " LIMIT ?"
            params.append(limit)
        rows = query(sql, params)

    # 没有摘要的不能硬理解（模型会编），但也不能让它一直挂在「待理解」上——
    # 标成 skipped 并写清原因，用户才知道是「拿不到正文」而不是「程序坏了」。
    papers: list[dict] = []
    skipped: list[dict] = []
    for r in rows:
        d = dict(r)
        if (d["abstract"] or "").strip():
            papers.append(d)
        elif (d["tldr"] or "").strip():
            d["abstract"] = d["tldr"]  # 有 TLDR 就用 TLDR 顶上
            papers.append(d)
        else:
            skipped.append(d)

    for d in skipped:
        execute(
            "UPDATE paper SET status='skipped', status_reason=? WHERE id=?",
            ("没有摘要（arXiv/OpenAlex 都没有收录摘要），无法做结构化理解", d["id"]),
        )

    if not papers:
        return {
            "understood": 0,
            "failed": 0,
            "skipped": len(skipped),
            "skip_reason": "没有摘要" if skipped else "",
            "cost_cny": 0.0,
        }

    system = _load_prompt()
    model = settings_store.effective_model("flash")
    understood = failed = 0
    cost = 0.0

    for bi in range(0, len(papers), batch_size):
        batch = papers[bi : bi + batch_size]
        payload = [
            {
                "id": p["id"],
                "title": p["title"],
                "abstract": (p["abstract"] or "")[:ABSTRACT_LIMIT],
            }
            for p in batch
        ]
        user = (
            "以下是 %d 篇论文，请逐篇抽取：\n\n%s"
            % (len(payload), json.dumps(payload, ensure_ascii=False, indent=None))
        )

        data, res = await chat_json(
            [{"role": "system", "content": system}, {"role": "user", "content": user}],
            purpose="understand",
            model=model,
            thinking=False,
            temperature=0.1,
            project_id=project_id,
            job_id=job_id,
        )
        cost += res.cost_cny

        items = (data or {}).get("items") if isinstance(data, dict) else None
        if not isinstance(items, list):
            log.warning("理解批次返回格式异常，跳过 %d 篇", len(batch))
            for bp in batch:
                execute(
                    "UPDATE paper SET status='failed', status_reason=? WHERE id=?",
                    ("模型返回格式异常（这一批没解析出来）", bp["id"]),
                )
            failed += len(batch)
            continue

        by_id = {str(it.get("id")): it for it in items if isinstance(it, dict)}
        for idx, p in enumerate(batch):
            item = by_id.get(p["id"])
            if item is None and idx < len(items) and isinstance(items[idx], dict):
                item = items[idx]  # 兜底：按顺序对
            if item is None:
                execute(
                    "UPDATE paper SET status='failed', status_reason=? WHERE id=?",
                    ("模型没有返回这篇的理解结果", p["id"]),
                )
                failed += 1
                continue
            try:
                _save_one(project_id, p["id"], item, res.model, res.input_tokens, res.output_tokens)
                understood += 1
            except Exception as e:  # noqa: BLE001
                log.exception("保存理解失败 %s", p["id"])
                execute(
                    "UPDATE paper SET status='failed', status_reason=? WHERE id=?",
                    (f"保存结果时出错：{type(e).__name__}", p["id"]),
                )
                failed += 1

        if on_progress:
            await on_progress(min(1.0, (bi + len(batch)) / len(papers)))

    return {
        "understood": understood,
        "failed": failed,
        "skipped": len(skipped),
        "total": len(papers),
        "cost_cny": round(cost, 4),
        "finished_at": now(),
    }
