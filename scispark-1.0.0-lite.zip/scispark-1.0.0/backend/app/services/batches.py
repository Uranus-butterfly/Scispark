"""调研批次。

一个项目里每调研一个新方向就开一个批次，论文通过 `paper.batch_id` 归到批次下。
解决的问题：连着调研两个方向后，论文库里 200 篇论文混在一起，分不清哪批是哪个方向来的。

设计取舍：
- **批次是「一次调研动作」的容器，不是「主题」**。同一主题调研两次就是两个批次，
  因为时间范围/期刊偏好可能不同，合并反而丢信息。
- 一篇论文只属于一个批次（首次入库的那批）。老论文被新批次再次检索到时，
  不会改归属——否则「这一批新增了什么」就说不清了。
- 删批次会连它的论文一起删（用户明确要清掉某个方向时最省事），但界面上要二次确认。
"""

from __future__ import annotations

from ..db import execute, new_id, now, query, query_one

LABEL_MAX = 40


def auto_label(query_text: str) -> str:
    """没给名字时，用检索主题当块名。"""
    s = " ".join((query_text or "").split())
    if not s:
        return "未命名调研"
    return s if len(s) <= LABEL_MAX else s[: LABEL_MAX - 1] + "…"


def create(
    project_id: str,
    *,
    label: str | None = None,
    query_text: str = "",
    date_from: str | None = None,
    date_to: str | None = None,
) -> str:
    bid = new_id()
    execute(
        "INSERT INTO search_batch(id, project_id, label, query, date_from, date_to)"
        " VALUES (?,?,?,?,?,?)",
        (
            bid,
            project_id,
            (label or "").strip()[:LABEL_MAX] or auto_label(query_text),
            (query_text or "").strip(),
            date_from,
            date_to,
        ),
    )
    return bid


def finish(batch_id: str, inserted: int, cost_cny: float = 0.0) -> None:
    execute(
        "UPDATE search_batch SET inserted = ?, cost_cny = ? WHERE id = ?",
        (int(inserted), round(float(cost_cny or 0), 4), batch_id),
    )


def list_for(project_id: str) -> list[dict]:
    """按时间倒序列出批次，附带实际论文数（以 paper 表为准，不是 inserted 计数）。"""
    rows = query(
        "SELECT b.id, b.label, b.query, b.date_from, b.date_to, b.inserted,"
        " b.cost_cny, b.created_at,"
        " (SELECT COUNT(*) FROM paper p WHERE p.batch_id = b.id) AS paper_count"
        " FROM search_batch b WHERE b.project_id = ? ORDER BY b.created_at DESC",
        (project_id,),
    )
    out = [dict(r) for r in rows]

    # 没有批次的论文（本地导入、或升级前遗留）单独归一组
    loose = query_one(
        "SELECT COUNT(*) AS c FROM paper WHERE project_id = ? AND batch_id IS NULL",
        (project_id,),
    )
    if loose and loose["c"]:
        out.append(
            {
                "id": None,
                "label": "未分批",
                "query": "",
                "date_from": None,
                "date_to": None,
                "inserted": loose["c"],
                "cost_cny": 0.0,
                "created_at": None,
                "paper_count": loose["c"],
                "loose": True,
            }
        )
    return out


def rename(project_id: str, batch_id: str, label: str) -> dict:
    clean = (label or "").strip()[:LABEL_MAX]
    if not clean:
        raise ValueError("名字不能为空")
    row = query_one(
        "SELECT id FROM search_batch WHERE id = ? AND project_id = ?", (batch_id, project_id)
    )
    if row is None:
        raise ValueError("批次不存在")
    execute("UPDATE search_batch SET label = ? WHERE id = ?", (clean, batch_id))
    return {"id": batch_id, "label": clean}


def remove(project_id: str, batch_id: str) -> dict:
    """删批次连同它的论文。返回删掉了多少篇。"""
    row = query_one(
        "SELECT id FROM search_batch WHERE id = ? AND project_id = ?", (batch_id, project_id)
    )
    if row is None:
        raise ValueError("批次不存在")

    n = query_one(
        "SELECT COUNT(*) AS c FROM paper WHERE project_id = ? AND batch_id = ?",
        (project_id, batch_id),
    )["c"]
    execute("DELETE FROM paper WHERE project_id = ? AND batch_id = ?", (project_id, batch_id))
    execute("DELETE FROM search_batch WHERE id = ?", (batch_id,))
    return {"deleted_papers": n, "at": now()}
