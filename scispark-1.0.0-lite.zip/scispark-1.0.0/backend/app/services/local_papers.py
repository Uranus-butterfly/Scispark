"""本地论文精读：导入 → 抽观点 → 跨篇大纲 → 创新点讨论。"""

from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path

from ..db import execute, fts_index_paper, new_id, now, query, query_one, tx
from ..llm.client import chat_json
from ..services import host_fs, settings_store
from ..sources import local_reader
from ..sources.normalize import normalize_title
from ..workers import queue

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT_DIR = Path(__file__).resolve().parent.parent / "llm" / "prompts"
CONDENSE_BUDGET = 13000
PER_SECTION = 900


def _prompt(name: str) -> str:
    try:
        return prompt_loader.load(name)
    except OSError:
        return "只输出 JSON。"


def safe_path(host_path: str) -> Path:
    """把界面传来的宿主路径换成容器内路径，并限制在允许的挂载范围内。"""
    return host_fs.to_container(host_path)


# ----------------------------------------------------------------------
# 目录浏览
# ----------------------------------------------------------------------
def browse(path: str | None = None) -> dict:
    return host_fs.browse(path)


# ----------------------------------------------------------------------
# 导入 + 抽观点
# ----------------------------------------------------------------------
def _condense(ex: local_reader.Extracted) -> str:
    parts = []
    for name, body in ex.sections:
        parts.append(f"## {name}\n{body[:PER_SECTION]}")
    text = "\n\n".join(parts)
    if len(text) > CONDENSE_BUDGET:
        per = max(300, CONDENSE_BUDGET // max(1, len(ex.sections)))
        parts = [f"## {n}\n{b[:per]}" for n, b in ex.sections]
        text = "\n\n".join(parts)
    return text[:CONDENSE_BUDGET]


def _upsert_local_paper(project_id: str, doc_id: str, ex: local_reader.Extracted, rel_path: str) -> str:
    """在 paper 表建一条 source='local' 的记录，供论文库统一检索。"""
    title = (ex.title or Path(rel_path).stem).strip()[:300]
    abstract = ex.text[:1500]
    norm = normalize_title(title)

    existing = query_one(
        "SELECT id FROM paper WHERE project_id = ? AND title_norm = ?", (project_id, norm)
    )
    if existing:
        return existing["id"]

    pid = new_id()
    try:
        execute(
            "INSERT INTO paper(id, project_id, source, source_id, title, title_norm, abstract,"
            " status, url, raw_json, full_text)"
            " VALUES (?,?,'local',?,?,?,?,'understood',?,?,?)",
            (
                pid, project_id, rel_path, title, norm, abstract,
                f"file://{rel_path}",
                json.dumps({"local_path": rel_path, "pages": ex.pages, "chars": ex.chars}, ensure_ascii=False),
                ex.text,
            ),
        )
    except sqlite3.IntegrityError:
        # 标题撞车：加后缀再试一次
        alt = f"{title} · {doc_id[:6]}"
        execute(
            "INSERT INTO paper(id, project_id, source, source_id, title, title_norm, abstract,"
            " status, url, raw_json, full_text)"
            " VALUES (?,?,'local',?,?,?,?,'understood',?,?,?)",
            (
                pid, project_id, rel_path, alt, normalize_title(alt), abstract,
                f"file://{rel_path}",
                json.dumps({"local_path": rel_path, "pages": ex.pages, "chars": ex.chars}, ensure_ascii=False),
                ex.text,
            ),
        )
    fts_index_paper(pid)
    return pid


_TYPE_MAP = {
    "thesis": "finding",
    "evidence": "result",
    "method": "finding",
    "limitation": "limitation",
    "assumption": "assumption",
    "result": "result",
}


def _save_views(paper_id: str, views: list[dict]) -> int:
    with tx() as conn:
        conn.execute("DELETE FROM claim WHERE paper_id = ?", (paper_id,))
        n = 0
        for v in views:
            if not isinstance(v, dict) or not v.get("claim"):
                continue
            vtype = str(v.get("type") or "thesis")
            ctype = _TYPE_MAP.get(vtype, "finding")
            meta = {
                "section": str(v.get("section") or "")[:80],
                "strength": v.get("strength"),
                "raw_type": vtype,
            }
            conn.execute(
                "INSERT INTO claim(id, paper_id, text, claim_type, polarity, quote,"
                " confidence, meta_json) VALUES (?,?,?,?,?,?,?,?)",
                (
                    new_id(), paper_id, str(v["claim"])[:1000], ctype,
                    -1 if ctype == "limitation" else 1,
                    str(v.get("quote") or "")[:1000],
                    float(v.get("strength") or 0.6),
                    json.dumps(meta, ensure_ascii=False),
                ),
            )
            n += 1
    return n


async def _extract_one(
    project_id: str, doc_id: str, job_id: str | None
) -> dict:
    row = query_one("SELECT * FROM local_doc WHERE id = ?", (doc_id,))
    if row is None:
        return {"ok": False, "error": "文档不存在"}

    path = Path(row["abs_path"])
    try:
        ex = local_reader.extract(path)
    except Exception as e:  # noqa: BLE001
        execute(
            "UPDATE local_doc SET status='failed', error=? WHERE id=?",
            (f"{type(e).__name__}: {e}"[:500], doc_id),
        )
        return {"ok": False, "error": str(e)}

    if len(ex.text) < 500:
        execute(
            "UPDATE local_doc SET status='failed', error='提取到的正文过短（可能是扫描版 PDF）' WHERE id=?",
            (doc_id,),
        )
        return {"ok": False, "error": "正文过短"}

    paper_id = _upsert_local_paper(project_id, doc_id, ex, row["rel_path"])

    system = _prompt("extract_views.md")
    user = f"文件名：{row['file_name']}\n\n以下是论文全文（按章节切分）：\n\n{_condense(ex)}"
    data, res = await chat_json(
        [{"role": "system", "content": system}, {"role": "user", "content": user}],
        purpose="local_views",
        model=settings_store.effective_model("flash"),
        thinking=True,          # 抽观点需要一点推理，值得开
        reasoning_effort="low",
        project_id=project_id,
        job_id=job_id,
        fallback=None,
    )

    views = []
    summary = ""
    outline = []
    stance = ""
    openings: list = []
    if isinstance(data, dict):
        views = data.get("views") or []
        summary = str(data.get("summary") or "")
        outline = data.get("section_outline") or []
        stance = str(data.get("stance") or "")
        openings = data.get("openings") or []

    n_views = _save_views(paper_id, views)
    execute(
        "UPDATE local_doc SET status='extracted', paper_id=?, title=?, pages=?, chars=?,"
        " sections_json=?, error=NULL WHERE id=?",
        (
            paper_id, ex.title[:300], ex.pages, ex.chars,
            json.dumps(
                {
                    "sections": outline,
                    "summary": summary,
                    "stance": stance,
                    "openings": openings,
                    "views": n_views,
                },
                ensure_ascii=False,
            ),
            doc_id,
        ),
    )
    return {"ok": True, "views": n_views, "cost_cny": res.cost_cny, "chars": ex.chars}


async def run_import(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    # paths 是宿主绝对路径（界面文件夹选择器给的）；rel_paths 兼容旧调用
    paths: list[str] = payload.get("paths") or payload.get("rel_paths") or []

    total = len(paths)
    results = []
    cost = 0.0

    for i, hp in enumerate(paths):
        queue.progress(job_id, i / max(1, total), f"读取 {Path(hp).name}（{i + 1}/{total}）")
        try:
            path = safe_path(hp)
        except ValueError as e:
            results.append({"rel": hp, "ok": False, "error": str(e)})
            continue
        if not path.is_file():
            results.append({"rel": hp, "ok": False, "error": "文件不存在"})
            continue

        digest = local_reader.sha256_of(path)
        exists = query_one(
            "SELECT id FROM local_doc WHERE project_id = ? AND sha256 = ?", (project_id, digest)
        )
        if exists:
            doc_id = exists["id"]
            execute(
                "UPDATE local_doc SET rel_path=?, abs_path=?, file_name=? WHERE id=?",
                (hp, str(path), path.name, doc_id),
            )
        else:
            doc_id = new_id()
            st = path.stat()
            execute(
                "INSERT INTO local_doc(id, project_id, rel_path, abs_path, file_name, ext,"
                " size_bytes, sha256, status) VALUES (?,?,?,?,?,?,?,?,'new')",
                (doc_id, project_id, hp, str(path), path.name, path.suffix.lower(), st.st_size, digest),
            )

        res = await _extract_one(project_id, doc_id, job_id)
        cost += float(res.get("cost_cny") or 0)
        results.append({"rel": hp, **res})

    ok = sum(1 for r in results if r.get("ok"))
    queue.progress(job_id, 1.0, "完成")
    return {"total": total, "ok": ok, "failed": total - ok, "cost_cny": round(cost, 4), "items": results}


# ----------------------------------------------------------------------
# 跨篇大纲
# ----------------------------------------------------------------------
def _parse_meta(raw: str | None) -> dict:
    try:
        v = json.loads(raw or "{}")
        return v if isinstance(v, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def _collect_views(project_id: str, doc_ids: list[str] | None = None) -> list[dict]:
    sql = (
        "SELECT d.id, d.file_name, d.sections_json, d.paper_id, d.title"
        " FROM local_doc d WHERE d.project_id = ? AND d.status = 'extracted'"
    )
    params: list = [project_id]
    if doc_ids:
        ph = ",".join("?" * len(doc_ids))
        sql += f" AND d.id IN ({ph})"
        params.extend(doc_ids)
    sql += " ORDER BY d.created_at"
    rows = query(sql, params)

    out = []
    for r in rows:
        claims = query(
            "SELECT text, claim_type, quote, meta_json FROM claim WHERE paper_id = ?"
            " ORDER BY claim_type, rowid",
            (r["paper_id"],),
        )
        meta = _parse_meta(r["sections_json"])
        views = []
        for c in claims:
            cm = _parse_meta(c["meta_json"])
            views.append(
                {
                    "claim": c["text"],
                    "type": cm.get("raw_type") or c["claim_type"],
                    "section": cm.get("section", ""),
                }
            )
        out.append(
            {
                "doc_id": r["id"],
                "file_name": r["file_name"],
                "title": r["title"] or r["file_name"],
                "summary": meta.get("summary", ""),
                "stance": meta.get("stance", ""),
                "openings": meta.get("openings", []),
                "views": views,
            }
        )
    return out


async def run_outline(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    doc_ids = payload.get("doc_ids")

    queue.progress(job_id, 0.1, "汇总观点")
    docs = _collect_views(project_id, doc_ids)
    if not docs:
        raise ValueError("还没有抽取过观点的本地论文")

    queue.progress(job_id, 0.35, "生成跨篇大纲")
    system = _prompt("build_outline.md")
    user = "以下是这批论文的观点汇总：\n\n" + json.dumps(docs, ensure_ascii=False)

    data, res = await chat_json(
        [{"role": "system", "content": system}, {"role": "user", "content": user}],
        purpose="local_outline",
        model=settings_store.effective_model("flash"),
        thinking=True,
        reasoning_effort="high",
        project_id=project_id,
        job_id=job_id,
        fallback=None,
    )
    if not isinstance(data, dict) or not data.get("sections"):
        raise ValueError("大纲生成失败，模型未返回合法结构")

    oid = new_id()
    execute(
        "INSERT INTO outline(id, project_id, kind, title, body_json, source_docs_json, model, cost_cny)"
        " VALUES (?,?,'outline',?,?,?,?,?)",
        (
            oid, project_id, str(data.get("title") or "文献大纲")[:200],
            json.dumps(data, ensure_ascii=False),
            json.dumps([d["file_name"] for d in docs], ensure_ascii=False),
            res.model, res.cost_cny,
        ),
    )
    queue.progress(job_id, 1.0, "完成")
    return {"outline_id": oid, "docs": len(docs), "cost_cny": round(res.cost_cny, 4)}


# ----------------------------------------------------------------------
# 创新点讨论
# ----------------------------------------------------------------------
async def run_discuss(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    outline_id = payload.get("outline_id")

    if outline_id:
        row = query_one("SELECT * FROM outline WHERE id = ? AND project_id = ?", (outline_id, project_id))
    else:
        row = query_one(
            "SELECT * FROM outline WHERE project_id = ? ORDER BY created_at DESC LIMIT 1",
            (project_id,),
        )
    if row is None:
        raise ValueError("还没有大纲，先生成大纲")

    body = json.loads(row["body_json"] or "{}")
    queue.progress(job_id, 0.2, "整理证据")

    docs = _collect_views(project_id)
    compact = [
        {"file_name": d["file_name"], "summary": d["summary"], "stance": d["stance"],
         "views": d["views"][:12]}
        for d in docs
    ]

    queue.progress(job_id, 0.45, "AI 讨论创新点")
    system = _prompt("discuss_ideas.md")
    user = (
        "【跨篇大纲】\n" + json.dumps(body, ensure_ascii=False)
        + "\n\n【各篇观点摘要】\n" + json.dumps(compact, ensure_ascii=False)
    )

    data, res = await chat_json(
        [{"role": "system", "content": system}, {"role": "user", "content": user}],
        purpose="local_discuss",
        model=settings_store.effective_model("pro"),   # 这一步值得用强模型
        thinking=True,
        reasoning_effort="high",
        project_id=project_id,
        job_id=job_id,
        fallback=None,
    )
    if not isinstance(data, dict) or not data.get("ideas"):
        raise ValueError("创新点生成失败，模型未返回合法结构")

    saved = []
    for it in data["ideas"][:6]:
        if not isinstance(it, dict) or not it.get("title"):
            continue
        iid = new_id()
        execute(
            "INSERT INTO idea(id, project_id, strategy, title, one_liner, problem, gap,"
            " method_sketch, why_novel, risks, feasibility, impact, status, created_by,"
            " novelty_report_json)"
            " VALUES (?,?,'local_discussion',?,?,?,?,?,?,?,?,?,'candidate','ai',?)",
            (
                iid, project_id, str(it["title"])[:200],
                str(it.get("one_liner") or "")[:400],
                str(it.get("gap") or "")[:800],
                str(it.get("gap") or "")[:800],
                "\n".join(str(s) for s in (it.get("how") or []))[:2000],
                str(it.get("why_new") or "")[:1500],
                str(it.get("risks") or "")[:1000],
                float(it.get("feasibility") or 3),
                float(it.get("impact") or 3),
                json.dumps(
                    {
                        "next_step": it.get("next_step"),
                        "collision": it.get("collision"),
                        "novelty": it.get("novelty"),
                        "evidence": it.get("evidence") or [],
                        "source": "local_papers",
                        "outline_id": row["id"],
                    },
                    ensure_ascii=False,
                ),
            ),
        )
        saved.append(iid)

    # 讨论正文另存一条 kind='discussion' 记录，便于回看历史
    execute(
        "INSERT INTO outline(id, project_id, kind, title, body_json, source_docs_json, model, cost_cny)"
        " VALUES (?,?,'discussion',?,?,?,?,?)",
        (
            new_id(), project_id, "创新点讨论",
            json.dumps(
                {
                    "judgement": data.get("judgement"),
                    "discussion": data.get("discussion") or [],
                    "counterpoints": data.get("counterpoints") or [],
                    "ideas": saved,
                    "parent_outline": row["id"],
                },
                ensure_ascii=False,
            ),
            json.dumps([], ensure_ascii=False),
            res.model, res.cost_cny,
        ),
    )

    queue.progress(job_id, 1.0, "完成")
    return {"ideas": len(saved), "cost_cny": round(res.cost_cny, 4)}


def start_import(project_id: str, paths: list[str]) -> str:
    return queue.submit(
        "local_import", project_id, {"project_id": project_id, "paths": paths}, run_import
    )


def start_outline(project_id: str, doc_ids: list[str] | None = None) -> str:
    return queue.submit(
        "local_outline", project_id, {"project_id": project_id, "doc_ids": doc_ids}, run_outline
    )


def start_discuss(project_id: str, outline_id: str | None = None) -> str:
    return queue.submit(
        "local_discuss", project_id, {"project_id": project_id, "outline_id": outline_id}, run_discuss
    )


# ----------------------------------------------------------------------
# 查询
# ----------------------------------------------------------------------
def list_docs(project_id: str) -> list[dict]:
    rows = query(
        "SELECT id, rel_path, file_name, ext, size_bytes, pages, chars, title, status,"
        " error, paper_id, sections_json, created_at FROM local_doc"
        " WHERE project_id = ? ORDER BY created_at DESC",
        (project_id,),
    )
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["meta"] = json.loads(d.pop("sections_json") or "{}")
        except (json.JSONDecodeError, TypeError):
            d["meta"] = {}
        out.append(d)
    return out


def latest_outline(project_id: str) -> dict | None:
    row = query_one(
        "SELECT * FROM outline WHERE project_id = ? AND kind = 'outline'"
        " ORDER BY created_at DESC LIMIT 1",
        (project_id,),
    )
    if row is None:
        return None
    return {
        "id": row["id"],
        "title": row["title"],
        "body": json.loads(row["body_json"] or "{}"),
        "docs": json.loads(row["source_docs_json"] or "[]"),
        "created_at": row["created_at"],
        "cost_cny": row["cost_cny"],
    }


def latest_discussion(project_id: str) -> dict | None:
    row = query_one(
        "SELECT * FROM outline WHERE project_id = ? AND kind = 'discussion'"
        " ORDER BY created_at DESC LIMIT 1",
        (project_id,),
    )
    if row is None:
        return None
    body = json.loads(row["body_json"] or "{}")
    ideas = []
    for iid in body.get("ideas") or []:
        r = query_one("SELECT * FROM idea WHERE id = ?", (iid,))
        if r:
            d = dict(r)
            try:
                d["extra"] = json.loads(d.pop("novelty_report_json") or "{}")
            except (json.JSONDecodeError, TypeError):
                d["extra"] = {}
            ideas.append(d)
    return {
        "id": row["id"],
        "judgement": body.get("judgement"),
        "discussion": body.get("discussion") or [],
        "counterpoints": body.get("counterpoints") or [],
        "ideas": ideas,
        "created_at": row["created_at"],
    }


def delete_doc(project_id: str, doc_id: str) -> None:
    row = query_one("SELECT paper_id FROM local_doc WHERE id = ? AND project_id = ?", (doc_id, project_id))
    if row is None:
        raise ValueError("文档不存在")
    execute("DELETE FROM local_doc WHERE id = ?", (doc_id,))
    if row["paper_id"]:
        execute("DELETE FROM paper WHERE id = ?", (row["paper_id"],))
