"""共创对话：一边聊，一边长出问题树。

设计要点（参考 CoQuest CHI'24 的交互模型，代码全部重写）：

1. **对话不是目的，树才是**。每轮对话的产出不是「一段回复」，而是「回复 + 树上的新节点」。
   用户看树就知道自己想到哪一步、哪些路已经走过。
2. **AI 的思考必须外显**。每个节点挂五段：text（在想什么）/ reasoning（为什么）/
   plan（打算怎么引导）/ criticism（这判断可能哪里不对）/ speak（所以打算怎么说）。
   写 criticism 是硬要求——没有自我怀疑的「思考过程」只是装饰。
3. **阶段由状态机管**，不让模型自由跳。发散阶段急着收敛是这类工具最常见的失败模式。
4. **引用必须是真的**。给模型的候选论文带真实 id，返回的 id 逐一校验，
   编的 id 直接丢弃——宁可这条节点没有证据，也不能给用户一个点不开的引用。
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from ..db import execute, new_id, now, query, query_one, tx
from ..llm.client import chat_json
from ..services import graph, settings_store

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT_DIR = Path(__file__).resolve().parent.parent / "llm" / "prompts"
STATES = ["diverging", "narrowing", "converging", "done"]
NODE_TYPES = {"rq", "hypothesis", "narrowing", "use_case", "idea"}
CANDIDATE_PAPERS = 10
HISTORY_TURNS = 8


def _prompt(name: str) -> str:
    try:
        return prompt_loader.load(name)
    except OSError:
        return "只输出 JSON。"


# ----------------------------------------------------------------------
# 状态机
# ----------------------------------------------------------------------
def next_state(current: str, proposed: str | None) -> str:
    """每轮最多前进一步，允许后退一步。

    防的是模型「一轮就宣布收敛」——发散阶段被急着收窄，
    是这类工具最常见的失败模式。
    """
    if proposed not in STATES:
        return current
    if current not in STATES:
        return "diverging"
    i, j = STATES.index(current), STATES.index(proposed)
    if j > i + 1:
        j = i + 1
    if j < i - 1:
        j = i
    return STATES[j]


# ----------------------------------------------------------------------
# 上下文
# ----------------------------------------------------------------------
def _root(conversation_id: str) -> dict | None:
    row = query_one(
        "SELECT * FROM rq_node WHERE conversation_id = ? AND parent_id IS NULL"
        " ORDER BY created_at LIMIT 1",
        (conversation_id,),
    )
    return dict(row) if row else None


def tree(conversation_id: str) -> list[dict]:
    rows = query(
        "SELECT id, parent_id, node_type, title, body, author, status, path, depth,"
        " ai_thoughts_json, ai_suggestions_json, paper_filter_json, conversation_id,"
        " created_at FROM rq_node WHERE conversation_id = ?"
        " ORDER BY depth, sort_order, created_at",
        (conversation_id,),
    )
    out = []
    for r in rows:
        d = dict(r)
        for src, dst, default in (
            ("ai_thoughts_json", "thoughts", {}),
            ("ai_suggestions_json", "suggestions", []),
            ("paper_filter_json", "papers", []),
        ):
            raw = d.pop(src, None)
            try:
                d[dst] = json.loads(raw) if raw else default
            except (json.JSONDecodeError, TypeError):
                d[dst] = default
        out.append(d)
    return out


def _tree_brief(conversation_id: str) -> list[dict]:
    """给模型看的紧凑版：只要 id / parent / type / title。"""
    return [
        {
            "id": n["id"],
            "parent": n["parent_id"] or "root",
            "type": n["node_type"],
            "title": n["title"],
        }
        for n in tree(conversation_id)
    ]


def _history(conversation_id: str) -> list[dict]:
    rows = query(
        "SELECT role, content FROM message WHERE conversation_id = ?"
        " ORDER BY created_at DESC, rowid DESC LIMIT ?",
        (conversation_id, HISTORY_TURNS * 2),
    )
    return [{"role": r["role"], "content": r["content"] or ""} for r in reversed(rows)]


def _candidates(project_id: str, text: str) -> list[dict]:
    """按当前话题从库里挑相关论文给模型当引用候选。"""
    hits = graph.similar_papers(project_id, text, top_k=CANDIDATE_PAPERS)
    if not hits:
        rows = query(
            "SELECT p.id, p.title, p.tldr, i.problem,"
            " substr(COALESCE(p.published_at,''), 1, 4) AS year"
            " FROM paper p LEFT JOIN paper_insight i ON i.paper_id = p.id"
            "   AND i.schema_version = (SELECT MAX(schema_version) FROM paper_insight WHERE paper_id = p.id)"
            " WHERE p.project_id = ? ORDER BY p.citation_count DESC LIMIT ?",
            (project_id, CANDIDATE_PAPERS),
        )
        return [dict(r) for r in rows]
    return [
        {
            "id": h["id"],
            "title": h["title"],
            "tldr": h["tldr"],
            "problem": h["problem"],
            "year": h["year"],
        }
        for h in hits
    ]


def _valid_paper_ids(project_id: str, ids) -> list[str]:
    """只留真实存在的论文 id——模型编的 id 一律丢掉。"""
    if not ids:
        return []
    wanted = {str(x) for x in ids if x}
    if not wanted:
        return []
    rows = query(
        "SELECT id FROM paper WHERE project_id = ? AND id IN (%s)" % ",".join("?" * len(wanted)),
        (project_id, *wanted),
    )
    return [r["id"] for r in rows]


# ----------------------------------------------------------------------
# 写入
# ----------------------------------------------------------------------
def _save_nodes(
    project_id: str, conversation_id: str, default_parent: str | None, nodes: list[dict]
) -> list[str]:
    """把模型给的节点落库，返回真实 id 列表（按插入顺序）。"""
    if not nodes:
        return []

    existing = {r["id"]: r for r in query(
        "SELECT id, path, depth FROM rq_node WHERE conversation_id = ?", (conversation_id,)
    )}
    id_map: dict[str, str] = {}
    created: list[str] = []

    with tx() as conn:
        for i, n in enumerate(nodes[:3]):
            if not isinstance(n, dict) or not str(n.get("title") or "").strip():
                continue

            parent_raw = str(n.get("parent") or "root")
            parent_id = id_map.get(parent_raw, parent_raw)
            if parent_id in ("root", "null", ""):
                parent_id = default_parent
            if parent_id and parent_id not in existing:
                parent_id = default_parent
            if not parent_id:
                continue

            p = existing[parent_id]
            nid = new_id()
            path = f"{p['path']}/{nid}"
            depth = int(p["depth"]) + 1

            ntype = str(n.get("type") or "rq")
            if ntype not in NODE_TYPES:
                ntype = "rq"

            papers = _valid_paper_ids(project_id, n.get("papers"))

            conn.execute(
                "INSERT INTO rq_node(id, project_id, parent_id, path, depth, node_type, title,"
                " body, author, paper_filter_json, conversation_id, sort_order)"
                " VALUES (?,?,?,?,?,?,?,?,'ai',?,?,?)",
                (
                    nid, project_id, parent_id, path, depth, ntype,
                    str(n["title"])[:200], str(n.get("body") or "")[:800],
                    json.dumps(papers, ensure_ascii=False), conversation_id, i,
                ),
            )
            existing[nid] = {"id": nid, "path": path, "depth": depth}
            temp = str(n.get("temp_id") or "")
            if temp:
                id_map[temp] = nid
            created.append(nid)

    return created


def _add_message(
    conversation_id: str,
    role: str,
    content: str,
    content_json: dict | None = None,
    model: str | None = None,
    cost: float = 0.0,
) -> str:
    mid = new_id()
    execute(
        "INSERT INTO message(id, conversation_id, role, content, content_json, model, cost_cny)"
        " VALUES (?,?,?,?,?,?,?)",
        (
            mid, conversation_id, role, content,
            json.dumps(content_json, ensure_ascii=False) if content_json else None,
            model, cost,
        ),
    )
    return mid


# ----------------------------------------------------------------------
# 对话
# ----------------------------------------------------------------------
async def _run_turn(project_id: str, conversation_id: str, user_text: str) -> dict:
    conv = query_one("SELECT * FROM conversation WHERE id = ?", (conversation_id,))
    if conv is None:
        raise ValueError("对话不存在")
    root = _root(conversation_id)
    if root is None:
        raise ValueError("问题树没有根节点")

    state = conv["mode"] or "diverging"
    cands = _candidates(project_id, user_text)

    ctx = {
        "研究主题": query_one("SELECT topic FROM project WHERE id = ?", (project_id,))["topic"],
        "当前阶段": state,
        "当前问题树": _tree_brief(conversation_id),
        "候选论文": [
            {
                "id": c["id"],
                "title": (c["title"] or "")[:160],
                "tldr": (c.get("tldr") or "")[:200],
                "problem": (c.get("problem") or "")[:200],
                "year": c.get("year") or "",
            }
            for c in cands
        ],
    }

    messages = [{"role": "system", "content": _prompt("chat_turn.md")}]
    messages += _history(conversation_id)
    messages.append(
        {
            "role": "user",
            "content": f"【上下文】\n{json.dumps(ctx, ensure_ascii=False)}\n\n【用户刚说】\n{user_text}",
        }
    )

    data, res = await chat_json(
        messages,
        purpose="chat_turn",
        model=settings_store.effective_model("flash"),
        thinking=True,
        reasoning_effort="low",
        project_id=project_id,
        fallback=None,
    )
    if not isinstance(data, dict) or not data.get("reply"):
        raise ValueError("模型没有返回有效回复")

    # 1. 落节点（父节点默认是当前焦点，没有就挂根上）
    focus_prev = conv["rq_node_id"] or root["id"]
    created = _save_nodes(project_id, conversation_id, focus_prev, data.get("nodes") or [])

    # 2. 焦点：模型给的就用，否则用最后一个新节点
    focus = str(data.get("focus") or "")
    if focus and focus not in created:
        # 可能是 temp_id 或旧 id，做一次兜底校验
        if query_one("SELECT id FROM rq_node WHERE id = ? AND conversation_id = ?", (focus, conversation_id)) is None:
            focus = created[-1] if created else focus_prev
    if not focus:
        focus = created[-1] if created else focus_prev

    # 3. 状态推进（最多一格）
    new_state = next_state(state, data.get("state"))

    # 4. 消息
    thoughts = data.get("thoughts") or {}
    payload = {
        "thoughts": thoughts if isinstance(thoughts, dict) else {},
        "suggestions": [str(s)[:60] for s in (data.get("suggestions") or [])][:3],
        "nodes": created,
        "papers": _valid_paper_ids(project_id, data.get("papers") or []),
        "focus": focus,
        "state": new_state,
    }
    mid = _add_message(
        conversation_id, "assistant", str(data["reply"])[:4000], payload, res.model, res.cost_cny
    )

    # 5. 把 thoughts 也挂到焦点节点上，点开节点能看到「AI 当时怎么想的」
    if focus:
        execute(
            "UPDATE rq_node SET ai_thoughts_json = ?, ai_suggestions_json = ?, updated_at = ?"
            " WHERE id = ?",
            (
                json.dumps(payload["thoughts"], ensure_ascii=False),
                json.dumps(payload["suggestions"], ensure_ascii=False),
                now(), focus,
            ),
        )

    execute(
        "UPDATE conversation SET mode = ?, rq_node_id = ?, updated_at = ? WHERE id = ?",
        (new_state, focus, now(), conversation_id),
    )

    return {
        "message_id": mid,
        "reply": str(data["reply"]),
        "state": new_state,
        "thoughts": payload["thoughts"],
        "suggestions": payload["suggestions"],
        "nodes": created,
        "papers": payload["papers"],
        "focus": focus,
        "cost_cny": round(res.cost_cny, 4),
    }


async def start(project_id: str, topic: str | None = None) -> dict:
    proj = query_one("SELECT name, topic FROM project WHERE id = ?", (project_id,))
    if proj is None:
        raise ValueError("项目不存在")
    topic = (topic or proj["topic"] or proj["name"] or "").strip()
    if not topic:
        raise ValueError("项目还没有研究主题")

    conversation_id = new_id()
    root_id = new_id()
    execute(
        "INSERT INTO conversation(id, project_id, rq_node_id, title, mode)"
        " VALUES (?,?,?,?,'diverging')",
        (conversation_id, project_id, root_id, topic[:80]),
    )
    execute(
        "INSERT INTO rq_node(id, project_id, path, depth, node_type, title, body, author,"
        " status, conversation_id) VALUES (?,?,?,0,'rq',?,?,'user','open',?)",
        (root_id, project_id, f"/{root_id}", topic[:200], "项目起点", conversation_id),
    )

    kickoff = f"我想研究：{topic}。请帮我看看这个方向该怎么往下走。"
    _add_message(conversation_id, "user", kickoff)
    result = await _run_turn(project_id, conversation_id, kickoff)
    return {"conversation_id": conversation_id, **result}


async def turn(project_id: str, conversation_id: str, text: str) -> dict:
    text = (text or "").strip()
    if not text:
        raise ValueError("说点什么再发")
    if len(text) > 2000:
        text = text[:2000]
    _add_message(conversation_id, "user", text)
    return await _run_turn(project_id, conversation_id, text)


# ----------------------------------------------------------------------
# 查询
# ----------------------------------------------------------------------
def conversation_view(conversation_id: str) -> dict | None:
    conv = query_one("SELECT * FROM conversation WHERE id = ?", (conversation_id,))
    if conv is None:
        return None
    rows = query(
        "SELECT id, role, content, content_json, model, cost_cny, created_at FROM message"
        " WHERE conversation_id = ? ORDER BY created_at, rowid",
        (conversation_id,),
    )
    messages = []
    for r in rows:
        d = dict(r)
        try:
            d["meta"] = json.loads(d.pop("content_json") or "{}")
        except (json.JSONDecodeError, TypeError):
            d["meta"] = {}
        messages.append(d)

    return {
        "id": conv["id"],
        "title": conv["title"],
        "state": conv["mode"],
        "focus": conv["rq_node_id"],
        "created_at": conv["created_at"],
        "messages": messages,
        "tree": tree(conversation_id),
        "cost_cny": round(sum(float(m["cost_cny"] or 0) for m in messages), 4),
    }


def latest(project_id: str) -> dict | None:
    # 排除脑图（mode='mindmap'）——那是另一张画布，混进来会把树显示错
    row = query_one(
        "SELECT id FROM conversation WHERE project_id = ? AND mode != 'mindmap'"
        " ORDER BY updated_at DESC LIMIT 1",
        (project_id,),
    )
    return conversation_view(row["id"]) if row else None
