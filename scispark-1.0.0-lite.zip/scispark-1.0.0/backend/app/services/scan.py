"""进展扫描：按时间窗扫一遍「这段时间发生了什么」。

和 P1 的调研不同：调研是「把这个领域搞懂」，扫描是「这段时间变了什么」。
所以流程上多两步、少一步：

- 多：**先把库里已有的排掉**（只关心增量），**最后要写判断**（不是摘要堆叠）。
- 少：不做大规模精排——时间窗内本来就没多少篇，粗排 + 一次精排足够。

开关设计：`watch_topic.enabled` 默认关。关着的时候不扫描、也不自动巡检；
打开之后才允许「选一个时间窗，扫这段时间」。用户要的是「我想用时再开」，
不是常驻后台烧钱。
"""

from __future__ import annotations

import json
import logging
from datetime import date, datetime, timedelta
from pathlib import Path

from ..db import execute, new_id, now, query, query_one
from ..llm.client import chat_json
from ..services import settings_store
from ..sources import arxiv_source, openalex_source
from ..sources.normalize import coarse_rank, dedupe, normalize_title
from ..workers import queue
from . import ingest, understand

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT_DIR = Path(__file__).resolve().parent.parent / "llm" / "prompts"

WINDOWS = {"week": 7, "month": 30, "quarter": 90, "half_year": 180, "year": 365}
DEFAULT_MAX_READ = 20
POOL_SIZE = 60
MIN_REPORT_PAPERS = 1


def _prompt(name: str) -> str:
    try:
        return prompt_loader.load(name)
    except OSError:
        return "只输出 JSON。"


# ----------------------------------------------------------------------
# 时间窗
# ----------------------------------------------------------------------
def resolve_window(
    window: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    today: date | None = None,
) -> tuple[str, str]:
    """返回 (start, end)，ISO 日期字符串。显式日期优先于预设窗口。"""
    today = today or date.today()
    end = (date_to or today.isoformat())[:10]
    if date_from:
        return date_from[:10], end
    days = WINDOWS.get(window or "month", 30)
    start = (today - timedelta(days=days)).isoformat()
    return start, end


# ----------------------------------------------------------------------
# 监控主题
# ----------------------------------------------------------------------
def ensure_topic(project_id: str) -> dict:
    """一个项目一个监控主题，没有就按项目主题建一个（默认关）。"""
    row = query_one(
        "SELECT * FROM watch_topic WHERE project_id = ? ORDER BY created_at LIMIT 1",
        (project_id,),
    )
    if row:
        return dict(row)

    proj = query_one("SELECT name, topic FROM project WHERE id = ?", (project_id,))
    if proj is None:
        raise ValueError("项目不存在")
    tid = new_id()
    execute(
        "INSERT INTO watch_topic(id, project_id, name, query, enabled) VALUES (?,?,?,?,0)",
        (tid, project_id, (proj["name"] or "关注方向")[:80], proj["topic"] or proj["name"] or ""),
    )
    return dict(query_one("SELECT * FROM watch_topic WHERE id = ?", (tid,)))


def topic_view(project_id: str) -> dict:
    t = ensure_topic(project_id)
    last = query_one(
        "SELECT id, window_start, window_end, status, items_new, items_read, cost_cny,"
        " created_at, finished_at, report_json FROM scan_run"
        " WHERE project_id = ? ORDER BY created_at DESC LIMIT 1",
        (project_id,),
    )
    runs = query(
        "SELECT id, window_start, window_end, status, items_found, items_new, items_read,"
        " cost_cny, created_at, finished_at FROM scan_run WHERE project_id = ?"
        " ORDER BY created_at DESC LIMIT 20",
        (project_id,),
    )
    return {
        "topic": {
            "id": t["id"],
            "name": t["name"],
            "query": t["query"],
            "enabled": bool(t["enabled"]),
            "auto_patrol": bool(t["auto_patrol"]),
            "last_scan_at": t["last_scan_at"],
        },
        "runs": [dict(r) for r in runs],
        "latest_report": _parse_report(last["report_json"]) if last else None,
        "latest_run": dict(last) if last else None,
    }


def update_topic(project_id: str, *, enabled: bool | None = None, query_text: str | None = None) -> dict:
    t = ensure_topic(project_id)
    sets, params = [], []
    if enabled is not None:
        sets.append("enabled = ?")
        params.append(1 if enabled else 0)
    if query_text is not None and query_text.strip():
        sets.append("query = ?")
        params.append(query_text.strip()[:300])
    if sets:
        sets.append("updated_at = ?")
        params.append(now())
        execute(f"UPDATE watch_topic SET {', '.join(sets)} WHERE id = ?", (*params, t["id"]))
    return topic_view(project_id)


def _parse_report(raw: str | None) -> dict | None:
    if not raw:
        return None
    try:
        d = json.loads(raw)
        return d if isinstance(d, dict) else None
    except (json.JSONDecodeError, TypeError):
        return None


# ----------------------------------------------------------------------
# 扫描
# ----------------------------------------------------------------------
async def run_scan(job_id: str, payload: dict) -> dict:
    project_id = payload["project_id"]
    topic = ensure_topic(project_id)
    if not topic["enabled"]:
        raise ValueError("监控没开启，先在页面上打开开关")

    start, end = resolve_window(
        payload.get("window"), payload.get("date_from"), payload.get("date_to")
    )
    max_read = int(payload.get("max_read") or DEFAULT_MAX_READ)
    max_read = max(5, min(40, max_read))
    query_text = (payload.get("query") or topic["query"] or "").strip()

    run_id = new_id()
    execute(
        "INSERT INTO scan_run(id, project_id, watch_topic_id, window_start, window_end,"
        " status, progress, step) VALUES (?,?,?,?,?,'fetching',0,'准备检索')",
        (run_id, project_id, topic["id"], start, end),
    )

    try:
        # --- 1 检索式 ---
        queue.progress(job_id, 0.05, "扩展检索式")
        plan = await ingest.expand_query(project_id, query_text, job_id)
        _set_run(run_id, step="检索 arXiv / OpenAlex", progress=0.1)

        arxiv_recs, a_stats = await arxiv_source.search(
            plan["phrases"], plan["arxiv_cats"], per_query=50, date_from=start, date_to=end
        )
        oa_recs, o_stats = await openalex_source.search(
            plan["phrases"], per_query=50, date_from=start, date_to=end
        )

        # --- 2 去重 + 排除库里已有的 ---
        queue.progress(job_id, 0.28, "去重，排除已读过的")
        merged = dedupe(arxiv_recs + oa_recs)
        excludes = plan.get("exclude") or []
        if excludes:
            merged = [r for r in merged if not any(x in (r.title or "").lower() for x in excludes)]

        known_norm = {
            r["title_norm"] for r in query("SELECT title_norm FROM paper WHERE project_id = ?", (project_id,))
        }
        fresh = [r for r in merged if normalize_title(r.title) not in known_norm]

        _set_run(
            run_id,
            items_found=len(merged),
            items_new=len(fresh),
            step=f"找到 {len(merged)} 篇，其中 {len(fresh)} 篇是新的",
            progress=0.35,
        )

        # --- 3 粗排 + 精排 ---
        queue.progress(job_id, 0.4, "排序")
        ranked = coarse_rank(fresh, plan["keywords"])
        pool = [r for r, _ in ranked[:POOL_SIZE]]

        final: list = []
        if pool:
            async def _rp(p: float) -> None:
                queue.progress(job_id, 0.4 + 0.25 * p, f"AI 精排 {int(p * 100)}%")

            final = await ingest.rerank(
                project_id, query_text, pool, job_id=job_id, on_progress=_rp, min_score=4.0
            )
            final = final[:max_read]

        # --- 4 入库 + 理解 ---
        _set_run(run_id, step=f"读 {len(final)} 篇", progress=0.68)
        new_ids: list[str] = []
        for rec, score, reason in final:
            pid = ingest.upsert_paper(
                project_id, rec, relevance=min(1.0, score / 10.0), reason=reason
            )
            if pid:
                new_ids.append(pid)

        understood: dict = {}
        if new_ids:
            async def _up(p: float) -> None:
                queue.progress(job_id, 0.68 + 0.22 * p, f"结构化理解 {int(p * 100)}%")

            understood = await understand.understand_papers(
                project_id, new_ids, job_id=job_id, on_progress=_up
            )

        # --- 5 写报告 ---
        queue.progress(job_id, 0.92, "写简报")
        report = await _write_report(
            project_id, job_id, start, end, new_ids, len(merged), len(fresh)
        )

        _set_run(
            run_id,
            status="done",
            progress=1.0,
            step="完成",
            items_read=len(new_ids),
            report_json=json.dumps(report, ensure_ascii=False),
            finished_at=now(),
        )
        execute("UPDATE watch_topic SET last_scan_at = ? WHERE id = ?", (now(), topic["id"]))

        queue.progress(job_id, 1.0, "完成")
        return {
            "run_id": run_id,
            "window": [start, end],
            "found": len(merged),
            "new": len(fresh),
            "read": len(new_ids),
            "headline": report.get("headline"),
            "cost_cny": round(float(report.get("cost_cny") or 0), 4),
            "understood": understood,
            "sources": {"arxiv": a_stats, "openalex": o_stats},
        }

    except Exception as e:  # noqa: BLE001
        _set_run(run_id, status="failed", error=f"{type(e).__name__}: {e}"[:500], finished_at=now())
        raise


def _set_run(run_id: str, **fields) -> None:
    if not fields:
        return
    cols = ", ".join(f"{k} = ?" for k in fields)
    execute(f"UPDATE scan_run SET {cols} WHERE id = ?", (*fields.values(), run_id))


async def _write_report(
    project_id: str,
    job_id: str | None,
    start: str,
    end: str,
    paper_ids: list[str],
    found: int,
    fresh: int,
) -> dict:
    if len(paper_ids) < MIN_REPORT_PAPERS:
        return {
            "headline": "这段时间没有符合条件的新论文",
            "overview": f"{start} ~ {end} 之间检索到 {found} 篇，排除库里已有的之后没有新的相关论文。"
            "可能是时间窗太短，或者这个方向确实安静。",
            "themes": [],
            "notable": [],
            "whats_new": [],
            "open_questions": [],
            "watch_next": [],
            "cost_cny": 0.0,
        }

    ph = ",".join("?" * len(paper_ids))
    rows = query(
        f"SELECT p.id, p.title, p.abstract, p.tldr, p.published_at, p.citation_count,"
        f" i.problem, i.method, i.findings_json, i.limitations_json"
        f" FROM paper p LEFT JOIN paper_insight i ON i.paper_id = p.id"
        f"   AND i.schema_version = (SELECT MAX(schema_version) FROM paper_insight WHERE paper_id = p.id)"
        f" WHERE p.id IN ({ph})",
        paper_ids,
    )

    items = []
    for r in rows:
        try:
            findings = json.loads(r["findings_json"] or "[]")
        except (json.JSONDecodeError, TypeError):
            findings = []
        try:
            limits = json.loads(r["limitations_json"] or "[]")
        except (json.JSONDecodeError, TypeError):
            limits = []
        items.append(
            {
                "id": r["id"],
                "title": (r["title"] or "")[:180],
                "date": (r["published_at"] or "")[:10],
                "tldr": (r["tldr"] or "")[:200],
                "problem": (r["problem"] or "")[:200],
                "method": (r["method"] or "")[:200],
                "findings": [str(x)[:120] for x in findings[:3]],
                "limitations": [str(x)[:120] for x in limits[:2]],
            }
        )

    # 已有积累：给模型一个「库里有啥」的粗略印象，才能说「相比已有，新在哪」
    kb = query(
        "SELECT title FROM paper WHERE project_id = ? AND id NOT IN (%s)"
        " ORDER BY citation_count DESC LIMIT 25" % ph,
        (project_id, *paper_ids),
    )

    user = (
        f"【时间窗】{start} ~ {end}\n"
        f"【检索概况】窗口内找到 {found} 篇，排除已读后新增 {fresh} 篇，精读 {len(items)} 篇\n\n"
        f"【本期新论文】\n{json.dumps(items, ensure_ascii=False)}\n\n"
        f"【项目已有积累（标题抽样，用于对比）】\n"
        + json.dumps([r["title"][:120] for r in kb], ensure_ascii=False)
    )

    data, res = await chat_json(
        [
            {"role": "system", "content": _prompt("scan_report.md")},
            {"role": "user", "content": user},
        ],
        purpose="scan_report",
        model=settings_store.effective_model("pro"),
        thinking=True,
        reasoning_effort="medium",
        project_id=project_id,
        job_id=job_id,
        fallback=None,
    )
    report = data if isinstance(data, dict) else {}

    # 校验论文 id，编的丢掉
    valid = set(paper_ids)
    for t in report.get("themes") or []:
        if isinstance(t, dict):
            t["paper_ids"] = [x for x in (t.get("paper_ids") or []) if x in valid]
    report["notable"] = [
        n for n in (report.get("notable") or []) if isinstance(n, dict) and n.get("paper_id") in valid
    ]
    report["window"] = [start, end]
    report["counts"] = {"found": found, "new": fresh, "read": len(items)}
    report["cost_cny"] = round(res.cost_cny, 4)
    return report


def start_scan(project_id: str, **kwargs) -> str:
    return queue.submit("scan", project_id, {"project_id": project_id, **kwargs}, run_scan)
