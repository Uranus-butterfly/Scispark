"""研究脑图：用户和 AI 在同一张画布上共同长出一棵思路树。

和「共创对话」的区别：
- 共创对话是**线性**的（你一句我一句），树是对话的副产品。
- 脑图是**画布优先**的：用户可以自己加节点、拖动、改写，AI 只是在你指的地方展开。

所以数据上是同一个 `rq_node` 表，但 `conversation.mode='mindmap'`，
节点带坐标（pos_x / pos_y），布局由用户拖动决定，不由算法决定。
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from ..db import execute, new_id, now, query, query_one, tx
from ..llm.client import chat_json
from ..services import graph, settings_store

log = logging.getLogger(__name__)

from ..llm import prompt_loader

PROMPT_DIR = Path(__file__).resolve().parent.parent / "llm" / "prompts"
NODE_TYPES = {"rq", "hypothesis", "narrowing", "use_case", "idea"}
CANDIDATES = 8

# 新节点的默认位置（前端会按实际需要重排/拖动）
DEFAULT_DX = 240
DEFAULT_DY = 96


def _prompt(name: str) -> str:
    try:
        return prompt_loader.load(name)
    except OSError:
        return "只输出 JSON。"


# ----------------------------------------------------------------------
# 地图
# ----------------------------------------------------------------------
def _latest_map(project_id: str) -> dict | None:
    row = query_one(
        "SELECT * FROM conversation WHERE project_id = ? AND mode = 'mindmap'"
        " ORDER BY updated_at DESC LIMIT 1",
        (project_id,),
    )
    return dict(row) if row else None


def get_map(project_id: str) -> dict | None:
    m = _latest_map(project_id)
    if m is None:
        return None
    return {"id": m["id"], "title": m["title"], "nodes": nodes_of(m["id"]), "updated_at": m["updated_at"]}


def nodes_of(map_id: str) -> list[dict]:
    rows = query(
        "SELECT id, parent_id, node_type, title, body, author, status, depth,"
        " ai_thoughts_json, paper_filter_json, pos_x, pos_y, created_at"
        " FROM rq_node WHERE conversation_id = ? ORDER BY created_at",
        (map_id,),
    )
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["papers"] = json.loads(d.pop("paper_filter_json") or "[]")
        except (json.JSONDecodeError, TypeError):
            d["papers"] = []
        try:
            d["thoughts"] = json.loads(d.pop("ai_thoughts_json") or "{}")
        except (json.JSONDecodeError, TypeError):
            d["thoughts"] = {}
        d["pos"] = {"x": d.pop("pos_x", None), "y": d.pop("pos_y", None)}
        out.append(d)
    return out


def create_map(project_id: str, title: str | None = None) -> dict:
    proj = query_one("SELECT name, topic FROM project WHERE id = ?", (project_id,))
    if proj is None:
        raise ValueError("项目不存在")
    text = (title or proj["topic"] or proj["name"] or "").strip()
    if not text:
        raise ValueError("项目还没有研究主题")

    map_id = new_id()
    root_id = new_id()
    execute(
        "INSERT INTO conversation(id, project_id, rq_node_id, title, mode)"
        " VALUES (?,?,?,?,'mindmap')",
        (map_id, project_id, root_id, text[:80]),
    )
    execute(
        "INSERT INTO rq_node(id, project_id, path, depth, node_type, title, body, author,"
        " status, conversation_id, pos_x, pos_y) VALUES (?,?,?,0,'rq',?,'','user','open',?,?,?)",
        (root_id, project_id, f"/{root_id}", text[:200], map_id, 450.0, 300.0),
    )
    return get_map(project_id)  # type: ignore[return-value]


def _check_map(project_id: str, map_id: str) -> dict:
    row = query_one(
        "SELECT * FROM conversation WHERE id = ? AND project_id = ? AND mode = 'mindmap'",
        (map_id, project_id),
    )
    if row is None:
        raise ValueError("脑图不存在")
    return dict(row)


def _next_pos(parent: dict | None, index: int) -> tuple[float, float]:
    if parent is None:
        return 450.0 + index * 40, 300.0 + index * 40
    px = float(parent["pos_x"] or 450)
    py = float(parent["pos_y"] or 300)
    return px + DEFAULT_DX, py + index * DEFAULT_DY


def add_node(
    project_id: str,
    map_id: str,
    parent_id: str,
    title: str,
    body: str = "",
    node_type: str = "rq",
) -> dict:
    _check_map(project_id, map_id)
    title = (title or "").strip()
    if not title:
        raise ValueError("节点标题不能为空")
    parent = query_one(
        "SELECT * FROM rq_node WHERE id = ? AND conversation_id = ?", (parent_id, map_id)
    )
    if parent is None:
        raise ValueError("父节点不存在")

    siblings = query(
        "SELECT COUNT(*) AS n FROM rq_node WHERE conversation_id = ? AND parent_id = ?",
        (map_id, parent_id),
    )[0]["n"]
    x, y = _next_pos(dict(parent), siblings)

    nid = new_id()
    execute(
        "INSERT INTO rq_node(id, project_id, parent_id, path, depth, node_type, title, body,"
        " author, status, conversation_id, pos_x, pos_y)"
        " VALUES (?,?,?,?,?,?,?,?,'user','open',?,?,?)",
        (
            nid, project_id, parent_id, f"{parent['path']}/{nid}", int(parent["depth"]) + 1,
            node_type if node_type in NODE_TYPES else "rq",
            title[:200], (body or "")[:1000], map_id, x, y,
        ),
    )
    execute("UPDATE conversation SET updated_at = ? WHERE id = ?", (now(), map_id))
    return dict(query_one("SELECT * FROM rq_node WHERE id = ?", (nid,)))


def update_node(project_id: str, map_id: str, node_id: str, **fields) -> dict:
    _check_map(project_id, map_id)
    row = query_one(
        "SELECT id FROM rq_node WHERE id = ? AND conversation_id = ?", (node_id, map_id)
    )
    if row is None:
        raise ValueError("节点不存在")

    allowed = {"title", "body", "status", "node_type", "pos_x", "pos_y"}
    sets, params = [], []
    for k, v in fields.items():
        if k not in allowed or v is None:
            continue
        if k == "title":
            v = str(v)[:200]
        elif k == "body":
            v = str(v)[:2000]
        elif k == "node_type" and v not in NODE_TYPES:
            continue
        elif k in ("pos_x", "pos_y"):
            try:
                v = float(v)
            except (TypeError, ValueError):
                continue
        sets.append(f"{k} = ?")
        params.append(v)
    if sets:
        sets.append("updated_at = ?")
        params.extend([now(), node_id])
        execute(f"UPDATE rq_node SET {', '.join(sets)} WHERE id = ?", tuple(params))
        execute("UPDATE conversation SET updated_at = ? WHERE id = ?", (now(), map_id))
    return dict(query_one("SELECT * FROM rq_node WHERE id = ?", (node_id,)))


def delete_node(project_id: str, map_id: str, node_id: str) -> None:
    _check_map(project_id, map_id)
    row = query_one(
        "SELECT id, parent_id, path FROM rq_node WHERE id = ? AND conversation_id = ?",
        (node_id, map_id),
    )
    if row is None:
        raise ValueError("节点不存在")
    if row["parent_id"] is None:
        raise ValueError("根节点不能删")
    # 连同子孙一起删（path 是物化路径，前缀匹配即可）
    execute(
        "DELETE FROM rq_node WHERE conversation_id = ? AND (id = ? OR path LIKE ?)",
        (map_id, node_id, f"{row['path']}/%"),
    )
    execute("UPDATE conversation SET updated_at = ? WHERE id = ?", (now(), map_id))


# ----------------------------------------------------------------------
# AI 展开
# ----------------------------------------------------------------------
def _candidates(project_id: str, text: str) -> list[dict]:
    hits = graph.similar_papers(project_id, text, top_k=CANDIDATES)
    if not hits:
        rows = query(
            "SELECT id, title, tldr FROM paper WHERE project_id = ?"
            " ORDER BY citation_count DESC LIMIT ?",
            (project_id, CANDIDATES),
        )
        return [{"id": r["id"], "title": (r["title"] or "")[:150], "tldr": (r["tldr"] or "")[:180]} for r in rows]
    return [
        {"id": h["id"], "title": (h["title"] or "")[:150], "tldr": (h["tldr"] or "")[:180]}
        for h in hits
    ]


def _valid_papers(project_id: str, ids) -> list[str]:
    wanted = {str(x) for x in (ids or []) if x}
    if not wanted:
        return []
    rows = query(
        "SELECT id FROM paper WHERE project_id = ? AND id IN (%s)" % ",".join("?" * len(wanted)),
        (project_id, *wanted),
    )
    return [r["id"] for r in rows]


async def expand_node(
    project_id: str, map_id: str, node_id: str, mode: str = "explore"
) -> dict:
    _check_map(project_id, map_id)
    node = query_one(
        "SELECT * FROM rq_node WHERE id = ? AND conversation_id = ?", (node_id, map_id)
    )
    if node is None:
        raise ValueError("节点不存在")

    prompt_file = "mindmap_ideas.md" if mode == "ideas" else "mindmap_expand.md"
    cands = _candidates(project_id, f"{node['title']} {node['body'] or ''}")

    ancestors = query(
        "SELECT title, node_type FROM rq_node WHERE conversation_id = ? AND depth < ?"
        " ORDER BY depth",
        (map_id, node["depth"]),
    )
    user = (
        f"【研究方向（从上到下的路径）】\n"
        + " → ".join(r["title"] for r in ancestors)
        + f"\n\n【当前节点】\n类型：{node['node_type']}\n标题：{node['title']}\n说明：{node['body'] or '（空）'}"
        + f"\n\n【可引用的论文】\n{json.dumps(cands, ensure_ascii=False)}"
    )

    data, res = await chat_json(
        [
            {"role": "system", "content": _prompt(prompt_file)},
            {"role": "user", "content": user},
        ],
        purpose=f"mindmap_{mode}",
        model=settings_store.effective_model("flash"),
        thinking=True,
        reasoning_effort="low",
        project_id=project_id,
        fallback=None,
    )
    if not isinstance(data, dict) or not data.get("nodes"):
        raise ValueError("模型没有返回可用的节点")

    created: list[str] = []
    siblings = query(
        "SELECT COUNT(*) AS n FROM rq_node WHERE conversation_id = ? AND parent_id = ?",
        (map_id, node_id),
    )[0]["n"]
    # 同一父节点下已有的标题，用来去重（用户连点两次不该长出一堆重复节点）
    existing_titles = {
        (r["title"] or "").strip()
        for r in query(
            "SELECT title FROM rq_node WHERE conversation_id = ? AND parent_id = ?",
            (map_id, node_id),
        )
    }

    with tx() as conn:
        for i, item in enumerate((data.get("nodes") or [])[:4]):
            if not isinstance(item, dict) or not str(item.get("title") or "").strip():
                continue
            title = str(item["title"]).strip()
            if title in existing_titles:
                continue
            existing_titles.add(title)

            nid = new_id()
            # 「出创新点」模式下强制标成 idea——模型经常照样返回 rq，
            # 那样在图上就分不出「问题」和「做法」了
            ntype = "idea" if mode == "ideas" else str(item.get("type") or "rq")
            x, y = _next_pos(dict(node), siblings + i)
            conn.execute(
                "INSERT INTO rq_node(id, project_id, parent_id, path, depth, node_type, title,"
                " body, author, status, ai_thoughts_json, paper_filter_json, conversation_id,"
                " pos_x, pos_y) VALUES (?,?,?,?,?,?,?,?,'ai','open',?,?,?,?,?)",
                (
                    nid, project_id, node_id, f"{node['path']}/{nid}", int(node["depth"]) + 1,
                    ntype if ntype in NODE_TYPES else "rq",
                    title[:200], str(item.get("body") or "")[:1000],
                    json.dumps({"text": str(item.get("why") or "")[:400]}, ensure_ascii=False),
                    json.dumps(_valid_papers(project_id, item.get("papers")), ensure_ascii=False),
                    map_id, x, y,
                ),
            )
            created.append(nid)

    execute("UPDATE conversation SET updated_at = ? WHERE id = ?", (now(), map_id))
    return {
        "created": created,
        "note": str(data.get("note") or ""),
        "nodes": nodes_of(map_id),
        "cost_cny": round(res.cost_cny, 4),
    }


async def seed(project_id: str, map_id: str) -> dict:
    """AI 在根节点下给几个方向。"""
    root = query_one(
        "SELECT * FROM rq_node WHERE conversation_id = ? AND parent_id IS NULL", (map_id,)
    )
    if root is None:
        raise ValueError("脑图没有根节点")
    return await expand_node(project_id, map_id, root["id"], mode="explore")
