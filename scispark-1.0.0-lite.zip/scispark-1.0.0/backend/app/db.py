"""SQLite 连接与通用数据访问。

设计要点：
- 单文件 + WAL，单进程多线程（uvicorn 单 worker）足够。
- 不用 ORM：需要 FTS5、JSON1、外部内容表，手写 SQL 更透明。
- 每次请求用 `get_conn()` 取一个线程局部连接；写操作用 `tx()` 上下文。
"""

from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from .config import settings

_local = threading.local()
_SCHEMA = Path(__file__).with_name("schema.sql")
SCHEMA_VERSION = 7


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def new_id() -> str:
    return uuid.uuid4().hex


def _connect() -> sqlite3.Connection:
    settings.ensure_dirs()
    conn = sqlite3.connect(str(settings.db_file), timeout=30.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    # 用 DELETE 而非 WAL：macOS Docker Desktop 的 bind mount 文件系统对 WAL 需要的
    # -shm 共享内存映射支持不良，且与宿主 Spotlight 索引抢锁时会偶发 disk I/O error /
    # database is locked。DELETE 是 SQLite 默认日志模式，最兼容各类文件系统，单用户
    # 工具性能完全够用。
    conn.execute("PRAGMA journal_mode=DELETE")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def get_conn() -> sqlite3.Connection:
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = _connect()
        _local.conn = conn
    return conn


@contextmanager
def tx():
    """写事务。异常回滚。"""
    conn = get_conn()
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise


# ------------------------------------------------------------------
# 查询辅助
# ------------------------------------------------------------------
def query(sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
    return list(get_conn().execute(sql, tuple(params)).fetchall())


def query_one(sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
    return get_conn().execute(sql, tuple(params)).fetchone()


def execute(sql: str, params: Iterable[Any] = ()) -> int:
    with tx() as conn:
        cur = conn.execute(sql, tuple(params))
        return cur.rowcount


def row_to_dict(row: sqlite3.Row | None, json_fields: Iterable[str] = ()) -> dict | None:
    if row is None:
        return None
    d = dict(row)
    for f in json_fields:
        if f in d and isinstance(d[f], str):
            try:
                d[f] = json.loads(d[f])
            except (json.JSONDecodeError, TypeError):
                pass
    return d


# ------------------------------------------------------------------
# 初始化与迁移
# ------------------------------------------------------------------
def init_db() -> None:
    settings.ensure_dirs()
    conn = get_conn()
    conn.executescript(_SCHEMA.read_text(encoding="utf-8"))
    _ensure_columns(conn)
    row = conn.execute("SELECT MAX(version) AS v FROM schema_version").fetchone()
    current = row["v"] or 0
    if current < SCHEMA_VERSION:
        if current < 7:
            _backfill_batches(conn)
        with tx() as c:
            c.execute(
                "INSERT OR REPLACE INTO schema_version(version, note) VALUES (?, ?)",
                (SCHEMA_VERSION, "search batches"),
            )


def _backfill_batches(conn: sqlite3.Connection) -> None:
    """把升级前就存在的论文归到一个「早期导入」批次。

    只在版本升级时跑一次。**不能每次启动都跑**——本地论文（source='local'）
    也是没有批次的，每次启动都扫的话，它们会被反复塞进这个批次里。
    """
    try:
        projects = conn.execute(
            "SELECT DISTINCT project_id FROM paper WHERE batch_id IS NULL"
        ).fetchall()
    except sqlite3.Error:
        return  # 老库还没补上 batch_id 列，跳过

    for r in projects:
        pid = r[0]
        n = conn.execute(
            "SELECT COUNT(*) FROM paper WHERE project_id = ? AND batch_id IS NULL", (pid,)
        ).fetchone()[0]
        if not n:
            continue
        bid = new_id()
        conn.execute(
            "INSERT INTO search_batch(id, project_id, label, query, inserted) VALUES (?,?,?,?,?)",
            (bid, pid, "早期导入", "", n),
        )
        conn.execute(
            "UPDATE paper SET batch_id = ? WHERE project_id = ? AND batch_id IS NULL",
            (bid, pid),
        )


# 增量加列（CREATE TABLE IF NOT EXISTS 不会给已有表补字段）
_EXTRA_COLUMNS: list[tuple[str, str, str]] = [
    ("claim", "meta_json", "TEXT NOT NULL DEFAULT '{}'"),
    ("paper", "full_text", "TEXT"),
    ("outline", "kind", "TEXT NOT NULL DEFAULT 'outline'"),
    ("scan_run", "report_json", "TEXT"),
    ("idea", "proposal_md", "TEXT"),
    ("rq_node", "pos_x", "REAL"),
    ("rq_node", "pos_y", "REAL"),
    ("paper", "status_reason", "TEXT"),
    ("project", "venue_prefs_json", "TEXT"),
    ("project", "name_en", "TEXT"),
    ("paper", "batch_id", "TEXT"),
]


def _ensure_columns(conn: sqlite3.Connection) -> None:
    for table, column, ddl in _EXTRA_COLUMNS:
        try:
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
        except sqlite3.Error:
            continue
        if not cols or column in cols:
            continue
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
        except sqlite3.Error:
            pass

    # 索引必须等 batch_id 真的加上之后再建（schema.sql 里建会因列不存在而报错）
    try:
        conn.execute("CREATE INDEX IF NOT EXISTS ix_paper_batch ON paper(project_id, batch_id)")
    except sqlite3.Error:
        pass


def db_stats() -> dict:
    conn = get_conn()
    tables = [
        r["name"]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' "
            "AND name NOT LIKE 'paper_fts%' ORDER BY name"
        )
    ]
    counts = {}
    for t in tables:
        try:
            counts[t] = conn.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            counts[t] = -1
    size = settings.db_file.stat().st_size if settings.db_file.exists() else 0
    return {"tables": counts, "db_bytes": size, "path": str(settings.db_file)}


# ------------------------------------------------------------------
# FTS5 维护（应用层显式调用，不用触发器）
# ------------------------------------------------------------------
def fts_index_paper(paper_id: str) -> None:
    row = query_one(
        "SELECT id, title, abstract, tldr FROM paper WHERE id = ?", (paper_id,)
    )
    if row is None:
        return
    ins = query_one(
        "SELECT problem, method, findings_json, limitations_json FROM paper_insight "
        "WHERE paper_id = ? ORDER BY schema_version DESC LIMIT 1",
        (paper_id,),
    )
    insight = ""
    if ins is not None:
        parts: list[str] = []
        for key in ("problem", "method"):
            if ins[key]:
                parts.append(str(ins[key]))
        for key in ("findings_json", "limitations_json"):
            try:
                parts.extend(str(x) for x in json.loads(ins[key] or "[]"))
            except (json.JSONDecodeError, TypeError):
                pass
        insight = " ".join(parts)

    with tx() as conn:
        conn.execute("DELETE FROM paper_fts WHERE paper_id = ?", (paper_id,))
        conn.execute(
            "INSERT INTO paper_fts(paper_id, title, abstract, tldr, insight) VALUES (?,?,?,?,?)",
            (row["id"], row["title"] or "", row["abstract"] or "", row["tldr"] or "", insight),
        )


def fts_delete_paper(paper_id: str) -> None:
    with tx() as conn:
        conn.execute("DELETE FROM paper_fts WHERE paper_id = ?", (paper_id,))


def fts_rebuild() -> int:
    with tx() as conn:
        conn.execute("DELETE FROM paper_fts")
    ids = [r["id"] for r in query("SELECT id FROM paper")]
    for pid in ids:
        fts_index_paper(pid)
    return len(ids)


def fts_search(q: str, limit: int = 50, project_id: str | None = None) -> list[dict]:
    """BM25 检索。返回 [{paper_id, score}]，score 越大越相关。

    列权重对应 (paper_id, title, abstract, tldr, insight)；paper_id 不参与打分。
    """
    sql = (
        "SELECT paper_id, -bm25(paper_fts, 0.0, 3.0, 1.0, 2.0, 1.5) AS score "
        "FROM paper_fts WHERE paper_fts MATCH ? ORDER BY score DESC LIMIT ?"
    )
    try:
        rows = query(sql, (q, limit))
    except sqlite3.OperationalError:
        return []
    if not project_id:
        return [{"paper_id": r["paper_id"], "score": r["score"]} for r in rows]
    allowed = {
        r["id"] for r in query("SELECT id FROM paper WHERE project_id = ?", (project_id,))
    }
    return [
        {"paper_id": r["paper_id"], "score": r["score"]}
        for r in rows
        if r["paper_id"] in allowed
    ]
