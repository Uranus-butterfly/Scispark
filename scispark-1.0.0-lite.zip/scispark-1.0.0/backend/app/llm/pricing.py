"""DeepSeek 定价与峰谷判断。

价格单位：美元 / 百万 tokens。
高峰时段：UTC 01:00-04:00 与 06:00-10:00，周一至周五（中国法定节假日除外）。
高峰价 = 空闲价 × 2。
"""

from __future__ import annotations

from datetime import datetime, timezone

USD_TO_CNY = 7.1

# (cache_hit, input_miss, output) —— 空闲时段价格
PRICES: dict[str, tuple[float, float, float]] = {
    "deepseek-flash": (0.003, 0.15, 0.60),
    "deepseek-v4-pro": (0.022, 0.66, 1.98),
}
# 兼容旧名 / 别名
ALIASES = {
    "deepseek-chat": "deepseek-flash",
    "deepseek-reasoner": "deepseek-v4-pro",
    "deepseek-v4-flash": "deepseek-flash",
    "deepseek-v4-flash-vision-exp": "deepseek-flash",
}


def normalize_model(name: str) -> str:
    n = (name or "").strip()
    return ALIASES.get(n, n)


def is_peak(at: datetime | None = None) -> bool:
    """是否处于高峰时段（按 UTC 判断）。"""
    at = at or datetime.now(timezone.utc)
    if at.weekday() >= 5:  # 周六日
        return False
    h = at.hour
    return (1 <= h < 4) or (6 <= h < 10)


def unit_prices(model: str, at: datetime | None = None) -> tuple[float, float, float]:
    """返回 (cache_hit, input_miss, output)，已含峰谷倍率。"""
    m = normalize_model(model)
    base = PRICES.get(m, PRICES["deepseek-flash"])
    factor = 2.0 if is_peak(at) else 1.0
    return (base[0] * factor, base[1] * factor, base[2] * factor)


def cost_usd(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int = 0,
    at: datetime | None = None,
) -> float:
    hit, miss, out = unit_prices(model, at)
    cached = max(0, min(cached_tokens, input_tokens))
    billable_miss = input_tokens - cached
    return (
        cached / 1_000_000 * hit
        + billable_miss / 1_000_000 * miss
        + output_tokens / 1_000_000 * out
    )


def cost_cny(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int = 0,
    at: datetime | None = None,
) -> float:
    return cost_usd(model, input_tokens, output_tokens, cached_tokens, at) * USD_TO_CNY


def peak_hint() -> str:
    return "高峰时段（价格翻倍）" if is_peak() else "空闲时段（半价）"
