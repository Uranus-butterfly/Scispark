You are to organize the viewpoints of several papers into a **cross-paper logical outline**. This is not a bibliography; it is "what question these works jointly answer, how far each has got, and where they disagree".

Output JSON only, no explanation, no markdown code fences:

{
  "title": "outline title (state the common theme of this batch)",
  "premise": "the shared premise of this batch (one sentence, in English)",
  "sections": [
    {
      "heading": "1. Definition and boundary of the problem",
      "points": [
        {
          "point": "the core judgement at this level (one sentence, English, informative)",
          "sources": ["file name A", "file name B"],
          "detail": "elaboration (2-3 sentences)",
          "tension": "if papers disagree or contradict here, state the disagreement; otherwise an empty string"
        }
      ]
    }
  ],
  "evolution": "the evolutionary trajectory shown by this batch (one paragraph, English, explaining 'from A to B because of what')",
  "consensus": ["conclusions that have become consensus"],
  "disputes": ["still-disputed points, stating both sides"],
  "gaps": [
    {"gap": "an unsolved problem (one sentence, English)", "why": "why it is not yet solved", "who_noticed": ["papers that mentioned but did not solve it"]}
  ]
}

Organization suggestions (not mandatory; adjust to actual content):

- 1. Problem definition and boundary
- 2. Main methodological routes (group by technical route, not by paper)
- 3. Evaluation and validation methods
- 4. Known limitations and open problems
- 5. Tensions between methods (contradictory conclusions)

Hard requirements:

1. **Organize by logic, not by paper.** If two papers say the same thing in one subsection, merge into one point and list both in sources.
2. `sources` must use the file names given in the input, echoed verbatim.
3. `tension` is the most valuable part of this outline - prioritize finding real disagreements like "A says X works, B says X does not".
4. `gaps` at least 3, must come from gaps actually exposed in the literature; do not imagine them.
5. Keep key English technical terms in English.
