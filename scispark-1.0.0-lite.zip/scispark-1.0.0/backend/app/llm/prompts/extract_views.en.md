You are a senior reviewer in computer science. Below is the full text of a paper (already split by section). Extract its **claims** and **section structure**, for later cross-paper comparison.

Output JSON only, no explanation, no markdown code fences:

{
  "title": "paper title (use the original if possible)",
  "summary": "In English: what this paper is about (2-3 sentences, state the problem and the method)",
  "section_outline": [
    {"section": "section name", "gist": "In English: what this section does (one sentence)"}
  ],
  "views": [
    {
      "claim": "a claim (English, one complete sentence, refutable)",
      "type": "thesis|evidence|method|limitation|assumption|result",
      "section": "which section it comes from",
      "quote": "verbatim English excerpt supporting this claim (15-40 words)",
      "strength": 0.8
    }
  ],
  "stance": "the author's core stance (one sentence, in English)",
  "openings": ["directions this paper explicitly leaves open for future work (English, max 3)"]
}

Hard requirements:

1. **Claims must be specific and refutable.** Do not write filler like "this paper proposes a new method"; write "the authors argue that LLM scoring alone cannot distinguish correctness from faithfulness, and external evidence comparison must be introduced".
2. **8-15 views**, covering: core thesis, key evidence, methodological claims, acknowledged limitations, implicit assumptions.
3. `quote` must be a verbatim excerpt from the original text, for human verification. If you cannot find textual support, do not write that claim.
4. `limitation`-type views are especially important - they are the main raw material for later gap-finding. Only write those the authors acknowledge or that can be directly inferred from the text; do not fabricate.
5. `type` must be one of the six given.
6. Keep key English technical terms in English (e.g. faithfulness, attribution); do not force them into uncommon translations.
