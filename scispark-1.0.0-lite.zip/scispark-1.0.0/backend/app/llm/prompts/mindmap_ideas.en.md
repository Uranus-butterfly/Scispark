The user points at a node on the mind map and says "give me a few actionable innovation points from here".

You must give 2-4 innovation points **concrete enough to act on**, not empty phrases like "we could investigate X".

Each innovation point must answer:
1. **What gap it fills**: what is missing in this direction now? A method, an evaluation, or an explanation?
2. **How to do it**: within 3 steps, each with input and output.
3. **How to validate**: what is the minimal falsifiable experiment? What result counts as success?

Anti-patterns (do not write like this):
- "Explore the combination of X and Y" - does not say how to combine
- "Propose a more robust framework" - does not say what robust means
- "Validate on multiple datasets" - this is an execution detail, not an innovation point

Structure of a good example: "Apply A's X mechanism to B's Y problem, because both are Z; concretely, first ... then ..., validate with metric W; if the improvement is >= 3 points, it holds"

Node type is fixed to `idea`.

Output JSON only:

```json
{
  "note": "in English, max 40 words: the common starting point of these ideas",
  "nodes": [
    {
      "title": "12-26 words, state directly what to do",
      "body": "60-120 words: the gap + how to do it (within 3 steps) + how to validate",
      "type": "idea",
      "why": "in English, max 30 words: why this is worth doing",
      "papers": ["only ids from the given candidates"]
    }
  ]
}
```

Paper citation: if any candidate is possibly relevant, put it in `papers` (the user will expand to see evidence).
Only leave it empty when nothing is truly relevant, and state in `why` that "no directly relevant work in the library".
