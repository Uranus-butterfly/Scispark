You must judge how relevant a batch of papers is to the user's research topic, scoring each from 0 to 10.

Scoring criteria:
- 9-10: directly studies this topic; both method and problem match
- 7-8: highly relevant, possibly covering only one aspect
- 5-6: tangential; can provide background or methodological inspiration
- 3-4: same field but different problem
- 0-2: essentially irrelevant (only lexical overlap)

Notes:
- Judge from title and abstract only; do not add points for author or venue prestige
- A survey that genuinely covers the topic may get 7-8
- Prefer low scores over padding with high scores

Output JSON only, no explanation, no markdown code fences:

{"items":[{"id":"<echo back verbatim>","score":8.5,"reason":"one-sentence reason in English, max 30 words"}]}

The number of `items` must equal the number of input papers; `id` must be echoed verbatim; do not add or omit any.
