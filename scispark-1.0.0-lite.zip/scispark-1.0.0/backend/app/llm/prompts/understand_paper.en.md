You are a senior reviewer in computer science. Below is a batch of paper titles and abstracts. Extract a structured understanding of each paper, to be used for later cross-paper comparison.

Output JSON only, no explanation, no markdown code fences:

{
  "items": [
    {
      "id": "<echo back verbatim>",
      "problem": "What problem does this paper address (one sentence, in English)",
      "method": "Core method/mechanism (one to two sentences, in English; keep key technical terms)",
      "datasets": ["dataset or benchmark names"],
      "findings": ["main findings or conclusions (English, one sentence each)"],
      "limitations": ["limitations stated by the authors or directly inferable from the abstract (English, one sentence each)"],
      "key_claims": [
        {"claim": "a verifiable assertion (English)", "type": "finding|limitation|assumption", "quote": "verbatim excerpt from the abstract (English)"}
      ],
      "concepts": ["2-5 canonical terms, lowercase, singular, English"],
      "quality": 0.7
    }
  ]
}

Hard constraints:

1. **Do not fabricate.** `limitations` may only come from explicit statements in the abstract, or be directly inferable from it (e.g. evaluated on only one dataset -> generalization unverified). Leave an empty array if none.
2. `key_claims[].quote` must be a verbatim English excerpt from the abstract (10-30 words), for human verification. If you cannot extract one, do not emit that claim.
3. `concepts` must use canonical terms, not long phrases invented by the paper. For example, use "retrieval augmented generation", not "RAG pipeline for QA".
4. `quality` is a float in 0-1, indicating how solid the paper is in method and experiments (not relevance).
5. `items` count must equal the number of input papers; echo `id` verbatim; do not add or omit any.
