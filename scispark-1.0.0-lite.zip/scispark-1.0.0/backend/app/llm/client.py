"""DeepSeek 客户端。

统一收口：缓存 → 预算 → 请求（带重试）→ 记账 → 回填缓存。
上层只关心 content / usage / cost。
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from ..config import settings
from . import budget, cache, pricing
from ..services import settings_store

_client: httpx.AsyncClient | None = None
_sem = asyncio.Semaphore(8)


class LLMError(RuntimeError):
    def __init__(self, message: str, status: int | None = None, body: str | None = None):
        super().__init__(message)
        self.status = status
        self.body = body


@dataclass
class LLMResult:
    content: str
    model: str
    reasoning: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    cached_tokens: int = 0
    cost_cny: float = 0.0
    cache_hit: bool = False
    latency_ms: int = 0
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def usage(self) -> dict:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cached_tokens": self.cached_tokens,
            "cost_cny": round(self.cost_cny, 6),
            "cache_hit": self.cache_hit,
        }


def get_client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        _client = httpx.AsyncClient(
            base_url=settings_store.effective_base_url(),
            timeout=httpx.Timeout(180.0, connect=15.0),
            headers={"Content-Type": "application/json"},
        )
    return _client


async def close_client() -> None:
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None


def _mock_result(model: str, purpose: str, mock_response: str | None) -> LLMResult:
    content = mock_response if mock_response is not None else json.dumps(
        {"mock": True, "purpose": purpose, "note": "LLM_MODE=mock，未真实调用"}, ensure_ascii=False
    )
    return LLMResult(
        content=content,
        model=model,
        input_tokens=0,
        output_tokens=0,
        cost_cny=0.0,
        cache_hit=False,
    )


async def chat(
    messages: list[dict[str, str]],
    *,
    model: str | None = None,
    purpose: str = "general",
    thinking: bool | None = None,
    reasoning_effort: str | None = None,
    json_mode: bool = False,
    temperature: float | None = 0.3,
    max_tokens: int | None = None,
    project_id: str | None = None,
    job_id: str | None = None,
    mock_response: str | None = None,
    max_retries: int = 3,
) -> LLMResult:
    mdl = pricing.normalize_model(model or settings_store.effective_model("flash"))

    # thinking 默认关（批处理省输出 token），显式传 True 才开
    use_thinking = settings.thinking_default if thinking is None else thinking

    payload: dict[str, Any] = {
        "model": mdl,
        "messages": messages,
        "thinking": {"type": "enabled" if use_thinking else "disabled"},
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    if use_thinking:
        # thinking 模式不支持 temperature / penalty，传了也无效果
        if reasoning_effort:
            payload["reasoning_effort"] = reasoning_effort
    else:
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens:
            payload["max_tokens"] = max_tokens
    if max_tokens and use_thinking:
        payload["max_tokens"] = max_tokens

    # 1) mock 模式
    if settings_store.is_mock():
        return _mock_result(mdl, purpose, mock_response)

    # 2) 缓存
    ckey = cache.make_key(mdl, payload)
    hit = cache.get(ckey)
    if hit is not None:
        res = LLMResult(
            content=hit.get("content", ""),
            model=mdl,
            reasoning=hit.get("reasoning", ""),
            input_tokens=int(hit.get("input_tokens", 0)),
            output_tokens=int(hit.get("output_tokens", 0)),
            cached_tokens=int(hit.get("cached_tokens", 0)),
            cost_cny=0.0,
            cache_hit=True,
            latency_ms=0,
            raw=hit.get("raw", {}),
        )
        budget.record(
            project_id=project_id, job_id=job_id, purpose=purpose, model=mdl,
            prompt_hash=ckey, input_tokens=res.input_tokens,
            cached_tokens=res.cached_tokens, output_tokens=res.output_tokens,
            cost_cny=0.0, latency_ms=0, cache_hit=True,
        )
        return res

    # 3) 预算
    budget.check()

    # 4) 请求
    api_key = settings_store.effective_api_key()
    if not api_key:
        raise LLMError("未配置 DeepSeek API Key，请到设置页填写。")

    t0 = time.time()
    last_err: Exception | None = None
    data: dict | None = None

    async with _sem:
        for attempt in range(max_retries):
            try:
                r = await get_client().post(
                    "/chat/completions",
                    json=payload,
                    headers={"Authorization": f"Bearer {api_key}"},
                )
                if r.status_code in (429, 500, 502, 503, 504):
                    raise LLMError(f"HTTP {r.status_code}", r.status_code, r.text[:500])
                if r.status_code >= 400:
                    raise LLMError(
                        f"DeepSeek 返回 {r.status_code}", r.status_code, r.text[:800]
                    )
                data = r.json()
                break
            except (httpx.HTTPError, LLMError) as e:
                last_err = e
                if isinstance(e, LLMError) and e.status and 400 <= e.status < 500 and e.status != 429:
                    break  # 4xx（非限流）不重试
                if attempt < max_retries - 1:
                    await asyncio.sleep(1.5 * (2**attempt))
    latency = int((time.time() - t0) * 1000)

    if data is None:
        msg = f"调用失败：{last_err}"
        budget.record(
            project_id=project_id, job_id=job_id, purpose=purpose, model=mdl,
            prompt_hash=ckey, input_tokens=0, cached_tokens=0, output_tokens=0,
            cost_cny=0.0, latency_ms=latency, cache_hit=False, ok=False, error=msg,
        )
        raise LLMError(msg, getattr(last_err, "status", None), getattr(last_err, "body", None))

    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    content = message.get("content") or ""
    reasoning = message.get("reasoning_content") or ""
    usage = data.get("usage") or {}

    in_tok = int(usage.get("prompt_tokens") or 0)
    out_tok = int(usage.get("completion_tokens") or 0)
    cached_tok = int(
        usage.get("prompt_cache_hit_tokens")
        or (usage.get("prompt_tokens_details") or {}).get("cached_tokens")
        or 0
    )
    cost = pricing.cost_cny(mdl, in_tok, out_tok, cached_tok)

    res = LLMResult(
        content=content, model=mdl, reasoning=reasoning,
        input_tokens=in_tok, output_tokens=out_tok, cached_tokens=cached_tok,
        cost_cny=cost, cache_hit=False, latency_ms=latency, raw=data,
    )

    budget.record(
        project_id=project_id, job_id=job_id, purpose=purpose, model=mdl,
        prompt_hash=ckey, input_tokens=in_tok, cached_tokens=cached_tok,
        output_tokens=out_tok, cost_cny=cost, latency_ms=latency, cache_hit=False,
    )
    cache.put(ckey, {
        "content": content, "reasoning": reasoning,
        "input_tokens": in_tok, "output_tokens": out_tok, "cached_tokens": cached_tok,
        "raw": {"id": data.get("id"), "model": data.get("model")},
    })
    return res


def _strip_fence(text: str) -> str:
    t = text.strip()
    if t.startswith("```"):
        t = t.split("\n", 1)[1] if "\n" in t else t
        if t.rstrip().endswith("```"):
            t = t.rstrip()[:-3]
    return t.strip()


async def chat_json(
    messages: list[dict[str, str]],
    *,
    fallback: dict | None = None,
    **kwargs,
) -> tuple[dict | None, LLMResult]:
    """要求返回 JSON；解析失败时带错误信息重试一次，仍失败返回 fallback。"""
    kwargs["json_mode"] = True
    res = await chat(messages, **kwargs)
    text = _strip_fence(res.content)
    try:
        return json.loads(text), res
    except json.JSONDecodeError as e:
        repair = messages + [
            {"role": "assistant", "content": res.content[:2000]},
            {
                "role": "user",
                "content": f"上面的输出不是合法 JSON（{e}）。请只输出修正后的合法 JSON，不要任何解释、不要 markdown 代码块。",
            },
        ]
        kwargs.pop("mock_response", None)
        res2 = await chat(repair, **kwargs)
        try:
            return json.loads(_strip_fence(res2.content)), res2
        except json.JSONDecodeError:
            return fallback, res2


async def test_connection() -> dict:
    """设置页的连通性测试。"""
    if settings_store.is_mock():
        return {
            "ok": True,
            "message": "当前是 mock 模式，未真实调用（零成本）",
            "model": "mock",
            "latency_ms": 0,
            "cost_cny": 0.0,
        }
    if not settings_store.effective_api_key():
        return {
            "ok": False,
            "message": "没有拿到 API Key：输入框为空，数据库里也没有已保存的 Key。"
            "填好后直接点「测试连接」即可（会自动保存）。",
        }
    try:
        res = await chat(
            [{"role": "user", "content": "回复两个字：正常"}],
            purpose="ping",
            thinking=False,
            temperature=0,
            max_tokens=16,
            max_retries=1,
            mock_response="正常",
        )
        return {
            "ok": True,
            "message": f"连接正常（模型 {res.model}）",
            "model": res.model,
            "latency_ms": res.latency_ms,
            "cost_cny": round(res.cost_cny, 6),
        }
    except LLMError as e:
        return {"ok": False, "message": str(e)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "message": f"{type(e).__name__}: {e}"}
