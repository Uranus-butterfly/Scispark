"""按当前「调研结果语言」加载 prompt。

约定：
- 中文版：<name>.md（保持原文件名，向后兼容）
- 英文版：<name>.en.md
- 语言由 settings_store 的 result_language 决定（zh | en）
- 英文版不存在时回退中文版，保证漏翻某个 prompt 也不会崩

这样各服务不用关心语言，只管 `prompt_loader.load("xxx.md")`。
"""

from __future__ import annotations

from pathlib import Path

PROMPT_DIR = Path(__file__).resolve().parent / "prompts"


def current_lang() -> str:
    """当前结果语言：en 或 zh。读失败一律按 zh 处理。"""
    try:
        # 延迟导入：services.settings_store 依赖 db/config，不依赖 llm，
        # 放在函数内可避免模块级循环导入。
        from ..services import settings_store

        lang = (settings_store.get("result_language") or "zh").strip().lower()
    except Exception:
        lang = "zh"
    return "en" if lang == "en" else "zh"


def load(name: str) -> str:
    """加载 prompt 正文。

    name 形如 "understand_paper.md"；英文优先读 "understand_paper.en.md"。
    两个都不存在时抛 OSError，由调用方的兜底文案接住。
    """
    if current_lang() == "en":
        en = PROMPT_DIR / name.replace(".md", ".en.md")
        if en.exists():
            return en.read_text(encoding="utf-8")
    return (PROMPT_DIR / name).read_text(encoding="utf-8")
