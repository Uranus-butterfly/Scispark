"""LLM 响应缓存。

按 sha256(model + 采样参数 + messages) 落盘，命中直接返回，不再请求。
开发期反复调 prompt 时，只有真正改动的那一次会花钱。
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from ..config import settings


def make_key(model: str, payload: dict[str, Any]) -> str:
    # 只把影响输出的字段纳入 hash，避免无关字段导致缓存失效
    relevant = {
        "model": model,
        "messages": payload.get("messages"),
        "thinking": payload.get("thinking"),
        "response_format": payload.get("response_format"),
        "temperature": payload.get("temperature"),
        "max_tokens": payload.get("max_tokens"),
        "reasoning_effort": payload.get("reasoning_effort"),
        "top_p": payload.get("top_p"),
    }
    blob = json.dumps(relevant, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _path(key: str):
    return settings.cache_dir / key[:2] / f"{key}.json"


def get(key: str) -> dict | None:
    if not settings.cache_enabled:
        return None
    p = _path(key)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def put(key: str, value: dict) -> None:
    if not settings.cache_enabled:
        return
    p = _path(key)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


def stats() -> dict:
    files = list(settings.cache_dir.glob("*/*.json")) if settings.cache_dir.exists() else []
    total = sum(f.stat().st_size for f in files)
    return {"entries": len(files), "bytes": total, "dir": str(settings.cache_dir)}


def clear() -> int:
    files = list(settings.cache_dir.glob("*/*.json")) if settings.cache_dir.exists() else []
    for f in files:
        f.unlink(missing_ok=True)
    return len(files)
