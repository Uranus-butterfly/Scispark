"""日预算熔断与花费统计。

每次调用前检查当日累计花费，超限直接抛 BudgetExceeded，
防止写错循环把余额烧光 —— 这比任何省钱技巧都重要。
"""

from __future__ import annotations

from ..config import settings
from ..db import query_one


class BudgetExceeded(RuntimeError):
    pass


def spent_today_cny() -> float:
    row = query_one(
        "SELECT COALESCE(SUM(cost_cny),0) AS s FROM llm_call_log "
        "WHERE date(created_at) = date('now','localtime')"
    )
    return float(row["s"]) if row else 0.0


def spent_month_cny() -> float:
    row = query_one(
        "SELECT COALESCE(SUM(cost_cny),0) AS s FROM llm_call_log "
        "WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m','now','localtime')"
    )
    return float(row["s"]) if row else 0.0


def remaining_cny() -> float:
    return max(0.0, settings.daily_budget_cny - spent_today_cny())


def check(estimated_cny: float = 0.0) -> None:
    """调用前检查。estimated_cny 是本次预计花费。"""
    limit = settings.daily_budget_cny
    if limit <= 0:
        return
    used = spent_today_cny()
    if used >= limit:
        raise BudgetExceeded(
            f"今日预算已用完：已花 ¥{used:.3f} / 上限 ¥{limit:.2f}。"
            f"可在设置页调高 DAILY_BUDGET_CNY，或等到明天。"
        )
    if estimated_cny and used + estimated_cny > limit * 1.5:
        raise BudgetExceeded(
            f"本次调用预计 ¥{estimated_cny:.3f}，会超出今日预算（已花 ¥{used:.3f} / 上限 ¥{limit:.2f}）。"
        )


def summary() -> dict:
    return {
        "today_cny": round(spent_today_cny(), 4),
        "month_cny": round(spent_month_cny(), 4),
        "limit_cny": settings.daily_budget_cny,
        "remaining_cny": round(remaining_cny(), 4),
    }


def record(
    *,
    project_id: str | None,
    job_id: str | None,
    purpose: str,
    model: str,
    prompt_hash: str,
    input_tokens: int,
    cached_tokens: int,
    output_tokens: int,
    cost_cny: float,
    latency_ms: int,
    cache_hit: bool,
    ok: bool = True,
    error: str | None = None,
) -> None:
    from ..db import execute, new_id

    execute(
        "INSERT INTO llm_call_log(id, project_id, job_id, purpose, model, prompt_hash,"
        " input_tokens, cached_tokens, output_tokens, cost_cny, latency_ms, cache_hit, ok, error)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            new_id(), project_id, job_id, purpose, model, prompt_hash,
            input_tokens, cached_tokens, output_tokens, cost_cny,
            latency_ms, 1 if cache_hit else 0, 1 if ok else 0, error,
        ),
    )
