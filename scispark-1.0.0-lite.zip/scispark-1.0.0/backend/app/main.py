"""SciSpark 后端入口。"""

from __future__ import annotations

import logging
import os
import signal
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import settings
from .db import db_stats, init_db
from .llm import client

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("scispark")


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.ensure_dirs()
    init_db()
    log.info("数据库就绪: %s", settings.db_file)
    log.info("数据目录: %s", settings.data_path)
    yield
    await client.close_client()


app = FastAPI(title="SciSpark 科研创新助手", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def cache_headers(request, call_next):
    """静态资源缓存策略。

    index.html 必须每次都问服务器，否则改完前端用户会一直看到旧界面
    （构建产物文件名带 hash，但浏览器缓存的旧 index.html 指向的还是旧文件）。
    assets 下的文件名带 hash，可以放心长缓存。
    """
    resp = await call_next(request)
    path = request.url.path
    if path.startswith("/assets/"):
        resp.headers["Cache-Control"] = "public, max-age=31536000, immutable"
    elif path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    else:
        resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp

# ---------------- API 路由 ----------------
from .api import chat, graph, ideas, jobs, local, mindmap, papers, projects, scan  # noqa: E402
from .api import settings as settings_api  # noqa: E402

app.include_router(projects.router)
app.include_router(settings_api.router)
app.include_router(papers.router)
app.include_router(jobs.router)
app.include_router(local.router)
app.include_router(graph.router)
app.include_router(chat.router)
app.include_router(scan.router)
app.include_router(ideas.router)
app.include_router(mindmap.router)


@app.get("/api/health")
def health():
    # app 字段是启动器用来判断「这个端口上跑的是不是 SciSpark」的标记：
    # 8000 常被别的软件占用，只探测端口通不通会误判。
    return {"ok": True, "app": "scispark", "version": app.version}


def _is_local(request: Request) -> bool:
    """判断请求是不是来自本机。

    容器模式下客户端 IP 是 Docker 网关（172.17.0.1 这类），不是 127.0.0.1，
    所以除了回环还要放行私有网段。端口默认只绑 127.0.0.1，外部本来就进不来。
    """
    import ipaddress

    host = (request.client.host if request.client else "") or ""
    if host in ("localhost", ""):
        return host == "localhost"
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_private


@app.post("/api/system/shutdown")
async def shutdown(request: Request):
    """关闭服务（界面上那个「关闭」按钮调的就是这个）。

    只接受本机请求：应用默认只监听 127.0.0.1，但如果有人把端口暴露出去，
    这个接口会变成一个远程关机按钮，所以这里再挡一道。

    用 SIGTERM 而不是 os._exit：让 uvicorn 走正常的 lifespan 收尾
    （关 httpx 连接、提交 SQLite WAL），不会留下半截写入。
    """
    if not _is_local(request):
        raise HTTPException(403, "只允许从本机关闭")

    def _kill() -> None:
        os.kill(os.getpid(), signal.SIGTERM)

    # 留一点时间把响应发出去，否则前端拿不到 200
    threading.Timer(0.6, _kill).start()
    return {"ok": True, "message": "服务正在关闭"}


@app.get("/api/stats")
def stats():
    return {"db": db_stats(), "data_dir": str(settings.data_path)}


# ---------------- 前端静态资源 ----------------
STATIC = Path(settings.static_dir) if settings.static_dir else Path("static")

if (STATIC / "assets").is_dir():
    app.mount("/assets", StaticFiles(directory=str(STATIC / "assets")), name="assets")


@app.get("/{full_path:path}")
def spa(full_path: str):
    """SPA 兜底：静态文件优先，其余回 index.html。"""
    if full_path.startswith("api/"):
        return JSONResponse({"detail": "Not Found"}, status_code=404)
    candidate = STATIC / full_path
    if full_path and candidate.is_file():
        return FileResponse(candidate)
    index = STATIC / "index.html"
    if index.is_file():
        return FileResponse(index)
    return JSONResponse(
        {
            "detail": "前端未构建",
            "hint": "开发模式请访问 http://localhost:5173；或先执行 npm run build",
        },
        status_code=503,
    )
