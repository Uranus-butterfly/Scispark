"""全局配置：环境变量 + .env 读取。

运行时可被 app_setting 表覆盖（见 services/settings_store.py），
这里只提供「默认值 + 路径」。
"""

from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(".env", "../.env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ---- DeepSeek ----
    deepseek_api_key: str = ""
    deepseek_base_url: str = "https://api.deepseek.com"
    model_flash: str = "deepseek-flash"
    model_pro: str = "deepseek-v4-pro"
    # thinking 模式：只有需要推理的环节开；批处理一律关（省输出 token）
    thinking_default: bool = False

    # ---- 数据源 ----
    openalex_api_key: str = ""
    openalex_mailto: str = ""
    arxiv_base_url: str = "https://export.arxiv.org/api/query"

    # ---- 路径 ----
    data_dir: str = "/data"
    db_path: str = ""
    static_dir: str = ""
    # 本地论文目录（容器内挂载点，作为兜底默认值）
    local_papers_dir: str = "/local_papers"
    # 界面里选文件夹：宿主 HOME 的路径 + 它在容器里的挂载点。
    # 两个都配了才会做「宿主路径 ↔ 容器路径」映射，否则按本地直跑处理。
    host_home_dir: str = ""
    host_mount: str = "/host_home"

    # ---- 成本控制 ----
    daily_budget_cny: float = 5.0
    llm_mode: str = "live"  # live | mock
    cache_enabled: bool = True

    # ---- 语言 ----
    # ui_language：界面文案语言（前端 i18n 读取）
    # result_language：调研结果（LLM 输出）语言，决定加载哪套 prompt
    ui_language: str = "zh"
    result_language: str = "zh"

    # ---- 其他 ----
    timezone: str = "Asia/Shanghai"
    log_level: str = "INFO"

    # ---------- 派生 ----------
    @property
    def data_path(self) -> Path:
        return Path(self.data_dir)

    @property
    def db_file(self) -> Path:
        return Path(self.db_path) if self.db_path else self.data_path / "app.db"

    @property
    def cache_dir(self) -> Path:
        return self.data_path / "llm_cache"

    @property
    def reports_dir(self) -> Path:
        return self.data_path / "reports"

    @property
    def backups_dir(self) -> Path:
        return self.data_path / "backups"

    @property
    def local_papers_path(self) -> Path:
        return Path(self.local_papers_dir)

    def ensure_dirs(self) -> None:
        for p in (self.data_path, self.cache_dir, self.reports_dir, self.backups_dir):
            p.mkdir(parents=True, exist_ok=True)


settings = Settings()
