#!/usr/bin/env python3
"""打包成可以直接发给别人的 zip。

原则：**只打运行需要的东西**，任何跟这台电脑相关的都排除掉
（data/、.env、.venv、node_modules、我自己的截图脚本、AI 工作区记录……）。

产物：dist/scispark-<版本>.zip，解压后双击「启动」就能用。

用法：
  python3 tools/package.py              # 构建前端 + 打包
  python3 tools/package.py --no-build   # 用现有的 frontend/dist 直接打包
"""

from __future__ import annotations

import argparse
import fnmatch
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"

# 只在「项目根目录下」才排除的目录
# （frontend/dist 是要带上的前端产物，不能跟着根目录的 dist 一起排掉）
TOP_EXCLUDE = {
    ".git",
    ".github",
    ".docker",
    ".venv",
    ".workbuddy-ai",
    "data",
    "dist",
    "local_papers",
    "coquest-main",
}

# 任何层级出现都排除
ANY_EXCLUDE = {"node_modules", "__pycache__", ".pytest_cache", ".idea", ".vscode", "_cache"}

# 文件 / 通配
EXCLUDE_FILES = {
    ".env",
    ".DS_Store",
    "*.pyc",
    "*.db-wal",
    "*.db-shm",
    "*.log",
    "tools/shot.js",  # 开发时截图用的，绑定了本机 Chrome 路径
    "docs/*.pdf",     # 手册以 HTML 形式分发（浏览器打印即可得 PDF）
    "tools/build_manual.py",
    "tools/build_vendor.py",  # 只是给维护者重建 vendor/ 用的
}

EXCLUDE_PREFIXES = (".tmp-",)


def version() -> str:
    f = ROOT / "VERSION"
    return f.read_text(encoding="utf-8").strip() if f.exists() else "0.0.0"


def build_frontend() -> None:
    npm = shutil.which("npm")
    if not npm:
        print("没有 npm，跳过构建（用现有的 frontend/dist）")
        return
    print("▸ 构建前端…")
    r = subprocess.run([npm, "run", "build"], cwd=ROOT / "frontend")
    if r.returncode != 0:
        sys.exit("前端构建失败")


def keep(rel: Path, vendor_platforms: set[str] | None = None) -> bool:
    parts = rel.parts
    if parts[0] in TOP_EXCLUDE:
        return False
    # vendor/<平台>/site-packages 是首次启动时展开出来的，不随包分发；
    # 但 runtime/lib/python3.12/site-packages/pip 必须保留（离线安装要用）
    if len(parts) >= 3 and parts[0] == "vendor" and parts[2] == "site-packages":
        return False
    # 只打指定平台，方便出单平台的小包
    if (
        len(parts) >= 2
        and parts[0] == "vendor"
        and vendor_platforms is not None
        and parts[1] not in vendor_platforms
        and parts[1].endswith(("-arm64", "-x64"))
    ):
        return False
    if any(p in ANY_EXCLUDE for p in parts[:-1]):
        return False
    # 父目录也可能带前缀（.tmp-chrome-xxx/ 之类）
    if any(p.startswith(EXCLUDE_PREFIXES) for p in parts[:-1]):
        return False
    if rel.name.startswith(EXCLUDE_PREFIXES):
        return False
    # 沙箱/编辑器会在根目录留下 8 位随机名临时文件，一并排掉
    if len(parts) == 1 and re.fullmatch(r"[a-z0-9_]{8}", rel.name):
        return False

    posix = rel.as_posix()
    for pat in EXCLUDE_FILES:
        if fnmatch.fnmatch(posix, pat) or fnmatch.fnmatch(rel.name, pat):
            return False
    return True


def main() -> None:
    ap = argparse.ArgumentParser(description="打包发布 zip")
    ap.add_argument("--no-build", action="store_true", help="不重新构建前端")
    ap.add_argument("--no-vendor", action="store_true", help="不带离线运行时（出轻量包）")
    ap.add_argument("--no-screenshots", action="store_true",
                    help="不带 docs/screenshots 截图（轻量包传 GitHub 时用）")
    ap.add_argument("--platforms", nargs="+", default=None,
                    help="只带指定平台的离线运行时，如 --platforms win-x64")
    ap.add_argument("--suffix", default="", help="产物文件名后缀，如 -offline")
    args = ap.parse_args()

    vendor_platforms = set(args.platforms) if args.platforms else None

    if not args.no_build:
        build_frontend()

    dist_index = ROOT / "frontend" / "dist" / "index.html"
    if not dist_index.exists():
        sys.exit("找不到 frontend/dist/index.html —— 先构建前端，或去掉 --no-build")

    ver = version()
    name = f"scispark-{ver}"
    if not DIST.exists():
        DIST.mkdir()
    print("▸ 打包…")
    zip_path = DIST / f"{name}{args.suffix}.zip"
    count = 0
    # 直接写进 zip，不在 dist 里落临时目录（避免留下删不掉的 _stage）
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for path in sorted(ROOT.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if args.no_vendor and rel.parts[0] == "vendor":
                continue
            if args.no_screenshots and rel.as_posix().startswith("docs/screenshots/"):
                continue
            if not keep(rel, vendor_platforms):
                continue
            zf.write(path, f"{name}/{rel.as_posix()}")
            count += 1
        # 空目录补上，免得用户解压后缺 local_papers / data
        zf.writestr(f"{name}/data/.gitkeep", "")
        zf.writestr(f"{name}/local_papers/.gitkeep", "")
        # 轻量包没带运行时，首次启动会联网装依赖；README 描述的是完整版，这里补一句
        if args.no_vendor:
            zf.writestr(
                f"{name}/README-轻量版说明.txt",
                "【轻量版 · 给 GitHub / 网盘分发用】\n\n"
                "这个包不含 vendor/ 运行环境，所以体积很小。\n"
                "第一次双击「启动」时，会自动用系统 Python 3.10+ 建 .venv，\n"
                "并从 PyPI 下载约 150 MB 后端依赖（约 1~2 分钟，只此一次）。\n"
                "之后启动不再下载。\n\n"
                "如果希望「解压即可、完全不联网」，请用完整版\n"
                "scispark-<版本>.zip（约 133 MB，内置 macOS / Windows 双平台运行时）。\n\n"
                "注意：README.md 里「什么都不用装」描述的是完整版；\n"
                "轻量版请看上面这一段。\n",
            )
            count += 1

    size = zip_path.stat().st_size / 1024 / 1024
    print(f"\n✓ {count} 个文件 → {zip_path}（{size:.1f} MB）")

    # 保险：确认包里没有敏感文件
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
    bad = [
        n for n in names
        if n.rsplit("/", 1)[-1] == ".env" or n.endswith("/data/app.db")
    ]
    if bad:
        print("⚠️ 包里有不该带的东西：", bad[:5])
        sys.exit(2)
    print("✓ 已确认不含 .env / 个人数据库")


if __name__ == "__main__":
    main()
