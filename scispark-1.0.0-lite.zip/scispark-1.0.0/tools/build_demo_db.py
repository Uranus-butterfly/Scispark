#!/usr/bin/env python3
"""从本机数据库生成一份「可以发到 GitHub」的演示数据库。

为什么是复制而不是就地清理：就地清理会删掉使用者自己的项目和 API Key。
这里读 data/app.db，写 demo/app.db，原库一个字节都不动。

清洗内容：
  1. 只保留指定的项目（默认保留最早创建的那个，也就是开发时用的演示项目）
  2. 删掉所有密钥 / 邮箱 / 本机路径类的 app_setting
  3. 删掉本地论文导入记录（local_doc 和 source='local' 的 paper，它们的
     source_id / url 里存着绝对路径）
  4. 清空任务日志、LLM 调用日志、抓取日志（噪声，且可能夹带路径）
  5. 全库扫一遍 /Users/ 和盘符路径，把漏网的打印出来
  6. VACUUM 压缩

用法：
  python3 tools/build_demo_db.py                    # 自动选最早的项目
  python3 tools/build_demo_db.py --keep <project_id>
  python3 tools/build_demo_db.py --src data/app.db --dst demo/app.db
"""

from __future__ import annotations

import argparse
import re
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# 这些设置要么是密钥，要么是本机路径，一律不进演示库
DROP_SETTINGS = {
    "deepseek_api_key",
    "openalex_api_key",
    "openalex_mailto",
    "local_papers_root",
}

PATH_PATTERNS = [
    re.compile(r"/Users/[A-Za-z0-9._-]+"),
    re.compile(r"/home/[A-Za-z0-9._-]+"),
    re.compile(r"[A-Za-z]:\\\\?Users\\\\[^\"\\s]+"),
    re.compile(r"/host_home/"),
]


def pick_project(conn: sqlite3.Connection) -> str:
    row = conn.execute("SELECT id FROM project ORDER BY created_at LIMIT 1").fetchone()
    if row is None:
        print("数据库里没有项目，无法生成演示库", file=sys.stderr)
        sys.exit(1)
    return row[0]


def scrub(conn: sqlite3.Connection, keep: str) -> dict:
    stats: dict[str, int] = {}

    # 1. 只留一个项目
    # 注意：sqlite3 默认 foreign_keys=OFF，不显式打开的话 ON DELETE CASCADE 不生效，
    # 项目删了但论文/概念全留在库里（踩过）。
    conn.execute("PRAGMA foreign_keys = ON")
    others = [r[0] for r in conn.execute("SELECT id FROM project WHERE id != ?", (keep,))]
    for pid in others:
        conn.execute(
            "DELETE FROM rq_node WHERE conversation_id IN"
            " (SELECT id FROM conversation WHERE project_id = ?)",
            (pid,),
        )
        conn.execute("DELETE FROM project WHERE id = ?", (pid,))
        # 双保险：万一某张表没有外键约束，按 project_id 再清一遍
        for table in (
            "paper", "concept", "conversation", "idea", "outline",
            "scan_run", "watch_topic", "gap", "graph_run", "job",
        ):
            try:
                conn.execute(f"DELETE FROM {table} WHERE project_id = ?", (pid,))
            except sqlite3.Error:
                pass
    stats["deleted_projects"] = len(others)

    # 2. 密钥 / 路径类设置
    for key in DROP_SETTINGS:
        conn.execute("DELETE FROM app_setting WHERE key = ?", (key,))

    # 3. 本地论文（source_id / url 里有绝对路径）
    conn.execute("DELETE FROM local_doc")
    conn.execute("DELETE FROM paper WHERE source = 'local'")

    # 4. 日志类
    for table in ("job", "llm_call_log", "fetch_log", "notification"):
        try:
            n = conn.execute(f"DELETE FROM {table}").rowcount
            stats[f"cleared_{table}"] = n
        except sqlite3.Error:
            pass

    conn.commit()
    return stats


def scan_paths(conn: sqlite3.Connection) -> list[str]:
    """全库扫一遍，找还没清干净的本机路径。"""
    hits: list[str] = []
    tables = [
        r[0]
        for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            " AND name NOT LIKE '%_fts%'"
        )
    ]
    for table in tables:
        cols = [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]
        text_cols = [c for c in cols if c.lower() not in ("id",)]
        for row in conn.execute(f'SELECT rowid, * FROM "{table}"'):
            for i, val in enumerate(row[1:], start=1):
                if not isinstance(val, str) or len(val) < 6:
                    continue
                for pat in PATH_PATTERNS:
                    m = pat.search(val)
                    if m:
                        col = text_cols[i - 1] if i - 1 < len(text_cols) else "?"
                        hits.append(f"{table}.{col}: {m.group(0)[:80]}")
                        break
    return hits


def main() -> None:
    ap = argparse.ArgumentParser(description="生成可发布的演示数据库")
    ap.add_argument("--src", default=str(ROOT / "data" / "app.db"))
    ap.add_argument("--dst", default=str(ROOT / "demo" / "app.db"))
    ap.add_argument("--keep", default=None, help="要保留的 project id（默认保留最早的）")
    args = ap.parse_args()

    src, dst = Path(args.src), Path(args.dst)
    if not src.exists():
        print(f"找不到源数据库：{src}", file=sys.stderr)
        sys.exit(1)

    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()

    # 用 backup API 复制，WAL 模式下也能拿到一致快照
    with sqlite3.connect(src) as s, sqlite3.connect(dst) as d:
        s.backup(d)

    conn = sqlite3.connect(dst)
    try:
        keep = args.keep or pick_project(conn)
        name = conn.execute("SELECT name FROM project WHERE id = ?", (keep,)).fetchone()
        print(f"保留项目：{name[0] if name else keep}  ({keep[:8]})")

        stats = scrub(conn, keep)
        for k, v in stats.items():
            print(f"  {k}: {v}")

        # 演示库里的调研批次改个项目主题的名字，
        # 别让新用户第一次打开就看到「早期导入」这种开发期措辞
        row = conn.execute("SELECT topic FROM project WHERE id = ?", (keep,)).fetchone()
        if row and row[0]:
            conn.execute(
                "UPDATE search_batch SET label = ? WHERE project_id = ?",
                (row[0][:40], keep),
            )
            # 清洗时删掉了一些论文（本地导入那批），inserted 计数要跟着实际篇数走
            conn.execute(
                "UPDATE search_batch SET inserted ="
                " (SELECT COUNT(*) FROM paper WHERE paper.batch_id = search_batch.id)"
            )
            conn.commit()

        conn.execute("VACUUM")
        hits = scan_paths(conn)

        size = dst.stat().st_size / 1024 / 1024
        n_paper = conn.execute("SELECT COUNT(*) FROM paper").fetchone()[0]
        n_concept = conn.execute("SELECT COUNT(*) FROM concept").fetchone()[0]
        print(f"\n演示库：{dst}（{size:.1f} MB，{n_paper} 篇论文，{n_concept} 个概念）")

        if hits:
            print(f"\n⚠️ 还有 {len(hits)} 处疑似本机路径：")
            for h in hits[:20]:
                print("   ", h)
            sys.exit(2)
        print("✓ 没有发现本机路径残留")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
