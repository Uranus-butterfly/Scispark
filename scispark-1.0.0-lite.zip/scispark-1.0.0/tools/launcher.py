#!/usr/bin/env python3
"""SciSpark 一键启动（两种模式，自动选）。

  · Docker 模式：机器上有 Docker 就用它，环境完全隔离，最省心。
  · 原生模式：没有 Docker 也能跑——自动建 .venv、装 Python 依赖、直接起 uvicorn。
    前提是装了 Python 3.10+；前端已经是构建好的静态文件，不需要 Node。

做四件事，做完直接打开浏览器：
  1. 选模式（有 Docker 用 Docker；没有就原生；也可以用 --native / --docker 指定）
  2. 检查 .env（没有就从 .env.example 生成，并填好宿主目录）
  3. 启动（容器 / 本地进程）
  4. 等健康检查通过，打开 http://localhost:8000

关闭：界面上点左下角「关闭 SciSpark」，或者双击「停止」脚本。

命令行参数：
  python3 tools/launcher.py            # 启动（自动选模式；已在跑就直接开浏览器）
  python3 tools/launcher.py --native   # 强制不用 Docker
  python3 tools/launcher.py --docker   # 强制用 Docker
  python3 tools/launcher.py --rebuild  # 强制重新构建镜像（会重新下载依赖，慢）
  python3 tools/launcher.py --stop     # 停止
  python3 tools/launcher.py --logs     # 跟踪日志
  python3 tools/launcher.py --status   # 只看状态
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# 端口不写死：8000 被别的软件占了（很常见，比如 C-Lodop 打印服务）就自动往后找。
# 前端走相对路径 /api，所以换端口对它完全透明。
PORT = 8000
URL = f"http://localhost:{PORT}"
HEALTH = f"{URL}/api/health"

IS_MAC = platform.system() == "Darwin"
IS_WIN = platform.system() == "Windows"
IS_TTY = sys.stdout.isatty()

VENV = ROOT / ".venv"
VENV_PY = VENV / ("Scripts/python.exe" if IS_WIN else "bin/python")
PID_FILE = ROOT / "data" / ".server.pid"
REQ = ROOT / "backend" / "requirements.txt"
DIST = ROOT / "frontend" / "dist"


# ----------------------------------------------------------------------
# 输出
# ----------------------------------------------------------------------
def c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if IS_TTY else text


def step(msg: str) -> None:
    print(f"\n{c('36;1', '▸')} {c('1', msg)}")


def ok(msg: str) -> None:
    print(f"  {c('32', '✓')} {msg}")


def warn(msg: str) -> None:
    print(f"  {c('33', '!')} {msg}")


def fail(msg: str) -> None:
    print(f"  {c('31', '✗')} {msg}")


def info(msg: str) -> None:
    print(f"  {c('90', msg)}")


def die(msg: str, hint: str = "") -> None:
    fail(msg)
    if hint:
        print(f"    {c('90', hint)}")
    print()
    sys.exit(1)


# ----------------------------------------------------------------------
# 基础检查
# ----------------------------------------------------------------------
def compose_cmd() -> list[str]:
    """优先 docker compose（v2 插件），退回 docker-compose。"""
    if shutil.which("docker"):
        r = subprocess.run(
            ["docker", "compose", "version"], capture_output=True, text=True
        )
        if r.returncode == 0:
            return ["docker", "compose"]
    if shutil.which("docker-compose"):
        return ["docker-compose"]
    die(
        "没找到 docker compose",
        "装 Docker Desktop：https://www.docker.com/products/docker-desktop/",
    )
    return []


def docker_alive() -> bool:
    try:
        r = subprocess.run(
            ["docker", "info"], capture_output=True, text=True, timeout=15
        )
        return r.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def ensure_docker() -> None:
    step("检查 Docker")
    if not shutil.which("docker"):
        die(
            "这台机器上没装 Docker",
            "装 Docker Desktop：https://www.docker.com/products/docker-desktop/",
        )

    if docker_alive():
        ver = subprocess.run(
            ["docker", "version", "--format", "{{.Server.Version}}"],
            capture_output=True,
            text=True,
        ).stdout.strip()
        ok(f"Docker 在运行（{ver or 'unknown'}）")
        return

    if not IS_MAC:
        die("Docker 守护进程没在运行", "先启动 Docker Desktop / dockerd，再跑一次")

    warn("Docker 没启动，正在帮你打开 Docker Desktop…")
    subprocess.run(["open", "-a", "Docker"], capture_output=True)

    deadline = time.time() + 180
    dots = 0
    while time.time() < deadline:
        if docker_alive():
            ok("Docker 已就绪")
            return
        time.sleep(3)
        dots += 1
        if IS_TTY:
            print(f"\r  {c('90', '等待 Docker 启动' + '·' * (dots % 4) + '   ')}", end="")
    print()
    die(
        "等了 3 分钟 Docker 还没起来",
        "手动打开 Docker Desktop，等图标变绿后再跑一次",
    )


def ensure_demo_data() -> None:
    """第一次启动时，把演示库铺到 data/app.db。

    发布包里带一个清洗过的 demo/app.db（只含一个演示项目），
    用户自己的 data/ 永远不会被打包，所以这里只在「data 里还没有库」时复制。
    """
    db = ROOT / "data" / "app.db"
    demo = ROOT / "demo" / "app.db"
    if db.exists() or not demo.exists():
        return
    (ROOT / "data").mkdir(parents=True, exist_ok=True)
    shutil.copy2(demo, db)
    ok("已铺好演示数据（含一个「RAG 评测方法」项目，可直接看效果）")


def silence_spotlight() -> None:
    """macOS 的 Spotlight 会索引 data/（含 app.db 与几百个 llm_cache JSON），
    它和 Docker 的 bind mount 抢文件锁，会把 SQLite 写操作搞成偶发的
    disk I/O error / database is locked，新建项目等写操作直接 500。

    两种启动模式（Docker / 原生）都受影响，所以这里统一处理：
      1) 在 data/ 放 .metadata_never_index，让 Spotlight 永久跳过这个目录；
      2) 踢掉正在索引的 mdworker，让它重启后尊重上面的排除标记。
    非 macOS 直接返回（Windows/Linux 没有 Spotlight 这个问题）。
    """
    if not IS_MAC:
        return
    data = ROOT / "data"
    try:
        data.mkdir(parents=True, exist_ok=True)
        (data / ".metadata_never_index").touch()
    except OSError:
        pass
    # 踢掉正在索引的 worker；mdworker 是 Spotlight 的工作进程，被 kill 后会自动
    # 重启，重启时会读到 .metadata_never_index 从而跳过 data/。无害。
    try:
        subprocess.run(["pkill", "-f", "mdworker"], capture_output=True)
    except (OSError, FileNotFoundError):
        pass


def ensure_env() -> None:
    step("检查配置")
    env = ROOT / ".env"
    example = ROOT / ".env.example"

    if not env.exists():
        if not example.exists():
            warn("没有 .env.example，跳过（用默认配置启动）")
            return
        text = example.read_text(encoding="utf-8")
        # 把示例里的占位路径换成本机真实的 HOME，选择文件夹才用得上
        home = str(Path.home())
        text = text.replace("HOST_HOME_DIR=/Users/你的用户名", f"HOST_HOME_DIR={home}")
        env.write_text(text, encoding="utf-8")
        ok(f"已生成 .env（HOST_HOME_DIR={home}）")
        warn("还没填 DeepSeek API Key —— 启动后在网页「设置」里填就行")
        return

    ok(".env 已存在")
    raw = env.read_text(encoding="utf-8")
    if "HOST_HOME_DIR" not in raw:
        with env.open("a", encoding="utf-8") as f:
            f.write(f"\n# 界面里选文件夹用\nHOST_HOME_DIR={Path.home()}\n")
        ok("补上了 HOST_HOME_DIR")


def port_in_use(port: int = 8000) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.6)
        return s.connect_ex(("127.0.0.1", port)) == 0


def set_port(port: int) -> None:
    """切换服务端口，同步更新 URL / HEALTH。"""
    global PORT, URL, HEALTH
    PORT = port
    URL = f"http://localhost:{port}"
    HEALTH = f"{URL}/api/health"


def is_scispark(port: int) -> bool:
    """判断某个端口上跑的是不是 SciSpark 自己。

    只探测「端口有没有人监听」是不够的：8000 上很可能是别的软件
    （比如 C-Lodop 打印服务、各种开发服务器），那种情况下直接打开浏览器
    会让用户看到一个完全无关的网页，还以为装错了。
    这里认 /api/health 返回的 JSON 特征。
    """
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=2) as r:
            if r.status != 200:
                return False
            data = json.loads(r.read().decode("utf-8", "replace"))
    except (urllib.error.URLError, OSError, TimeoutError, ValueError):
        return False
    if not isinstance(data, dict):
        return False
    # 新版带 app 标记；老版本只有 ok + version，也认
    return data.get("app") == "scispark" or (data.get("ok") is True and "version" in data)


def find_free_port(start: int = 8000, tries: int = 20) -> int:
    """从 start 开始找第一个没人监听的端口。"""
    for p in range(start, start + tries):
        if not port_in_use(p):
            return p
    return start


def image_exists() -> bool:
    r = subprocess.run(
        ["docker", "images", "-q", "scispark:latest"], capture_output=True, text=True
    )
    return bool((r.stdout or "").strip())


def check_resources() -> None:
    """检查 Docker 分配的 CPU / 内存，不足时只提醒、不阻止启动。"""
    try:
        r = subprocess.run(
            ["docker", "info", "--format", "{{.NCPU}}|{{.MemTotal}}"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if r.returncode != 0:
            return
        ncpu_s, mem_s = (r.stdout or "").strip().split("|")
        ncpu = int(ncpu_s)
        mem_gb = int(mem_s) / (1024**3)
    except (ValueError, OSError, subprocess.SubprocessError):
        return

    if ncpu >= 4 and mem_gb >= 5.5:
        return

    warn(f"你的 Docker 目前只分配了 {ncpu} 核 / {mem_gb:.1f} GB 内存")
    info("推荐 4 核 / 6 GB。不足也能用，只是第一次准备环境会慢一些，个别时候可能失败。")
    info(
        "想调高：Docker Desktop → 右上角齿轮（Settings）→ Resources → 调 CPU / Memory → Apply & Restart"
    )
    info("现在先继续试试，不影响启动。")


def ensure_frontend_dist() -> None:
    """镜像直接 COPY frontend/dist，缺失时尝试用 npm 构建，否则给出明确提示。"""
    if (ROOT / "frontend" / "dist" / "index.html").exists():
        return

    warn("没找到构建好的前端（frontend/dist）")
    npm = shutil.which("npm")
    if npm:
        info("正在用 npm 构建前端（约 1~2 分钟）")
        if not (ROOT / "frontend" / "node_modules").exists():
            subprocess.run([npm, "install"], cwd=ROOT / "frontend")
        r = subprocess.run([npm, "run", "build"], cwd=ROOT / "frontend")
        if r.returncode == 0 and (ROOT / "frontend" / "dist" / "index.html").exists():
            ok("前端已构建")
            return
    die(
        "前端还没构建",
        "发布包一般自带构建产物；如果你是 git clone 的源码，先装 Node 18+ 再运行 "
        "`npm --prefix frontend install && npm --prefix frontend run build`，然后重新启动。",
    )


def container_state(compose: list[str]) -> str:
    r = subprocess.run(
        [*compose, "ps", "--format", "{{.State}}"], capture_output=True, text=True
    )
    return (r.stdout or "").strip()


# ----------------------------------------------------------------------
# 启停
# ----------------------------------------------------------------------
def compose_up(compose: list[str], build: bool) -> None:
    step("构建并启动" if build else "启动容器")
    # 端口可能因为 8000 被占用而换成别的，交给 compose 的 ${APP_PORT:-8000} 用
    os.environ["APP_PORT"] = str(PORT)
    if build:
        # 把「在下载什么」讲清楚，避免用户以为在往电脑里塞不明软件
        info("第一次启动要先准备运行环境（只做这一次，以后都是秒开）：")
        info("  · 一个 Python 运行环境，约 50 MB，来自 Docker 官方镜像")
        info("  · 后端依赖库，约 150 MB，来自清华 PyPI 镜像")
        info("  · 都是公开可信的开源包，不会往你电脑里装别的东西")
        info("  预计 1~2 分钟，取决于网速。下面这段是下载进度，可以不用管它。")
        info("  这些运行环境存在 Docker 里（不在这个文件夹），data/ 才是你的数据。")
        print()
        # 先单独构建：继承 stdio，让下载进度实时可见
        rc = subprocess.run([*compose, "build"], cwd=ROOT).returncode
        if rc != 0:
            die_start()

    # 再启动容器。这一步捕获输出：Windows 上「磁盘没授权给 Docker」这类错误
    # 只出现在这里，拿到原文才能给针对性指引。
    r = subprocess.run([*compose, "up", "-d"], cwd=ROOT, capture_output=True, text=True)
    out = ((r.stdout or "") + (r.stderr or "")).strip()
    if out:
        print(out)
    if r.returncode != 0:
        handle_up_error(out)
    ok("容器已启动")


def handle_up_error(out: str) -> None:
    """根据 docker 的报错原文，给针对性的、外行也能照做的指引。"""
    low = out.lower()

    # Windows Docker：项目所在磁盘没有授权给 Docker（File Sharing）
    if "is not shared from the host" in low or "file sharing" in low:
        drive = Path(ROOT).drive or "项目所在的盘"
        fail("启动没成功：Docker 没有授权访问这个文件夹所在的磁盘")
        print()
        print("  这是 Windows 版 Docker 的安全设置：它只允许访问你明确授权的磁盘。")
        print(f"  你的项目现在在：{ROOT}")
        print()
        print("  任选一种解决：")
        print(
            f"  {c('1', '1.')} 打开 Docker Desktop → 右上角齿轮（Settings）→ Resources → File Sharing"
        )
        print(f"     → 添加 {drive} → 点 Apply & Restart，然后再双击「启动」")
        print()
        print(
            f"  {c('1', '2.')} 更省事的办法：把整个 scispark 文件夹移到 C:\\Users\\你的用户名\\ 下面"
        )
        print("     （用户目录默认已授权），再双击「启动」")
        print()
        print("  数据不会丢：它就在 data/ 里，跟着文件夹一起走。")
        print()
        sys.exit(1)

    # 端口被占用（启动器已经自动挑过空闲端口，走到这里通常是别的容器占着）
    if (
        "port is already allocated" in low
        or "address already in use" in low
        or ("bind" in low and str(PORT) in low)
    ):
        fail(f"启动没成功：{PORT} 端口也被占用了")
        print()
        print("  一般是之前启动的 SciSpark 容器还在跑。先双击「停止」脚本，再重新启动。")
        print("  还不行就重启一次电脑，再双击「启动」。")
        print()
        sys.exit(1)

    die_start()


def die_start() -> None:
    """启动失败时给外行也能照做的指引，不堆术语。"""
    fail("启动没成功")
    print()
    print("  别急，按下面顺序试，大多数情况第 1 步就能解决：")
    print()
    print(f"  {c('1', '1.')} 关掉 Docker Desktop，再重新打开")
    print("     屏幕右上角找鲸鱼图标 → Quit Docker Desktop；再双击 Docker 图标重新打开。")
    print("     等它不再转圈、图标变绿之后，再双击「启动」。")
    print()
    print(f"  {c('1', '2.')} 如果你之前开过 SciSpark：先双击「停止」脚本，再重新启动。")
    print()
    print(f"  {c('1', '3.')} 如果上面提示「内存不足 / 资源不足」：")
    print("     打开 Docker Desktop → 点右上角齿轮（Settings）→ 左边选 Resources")
    print("     → 把 Memory 拉到 6 GB 以上、CPU 拉到 4 核以上 → 点 Apply & Restart")
    print()
    print(f"  {c('1', '4.')} 如果还是不行：请联系开发人员（把上面这一整段文字截图发给他们）。")
    print()
    sys.exit(1)


def wait_healthy(timeout: int = 180) -> bool:
    step("等应用就绪")
    deadline = time.time() + timeout
    dots = 0
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(HEALTH, timeout=3) as r:
                if r.status == 200:
                    print()
                    ok("健康检查通过")
                    return True
        except (urllib.error.URLError, OSError, TimeoutError):
            pass
        time.sleep(1.5)
        dots += 1
        if IS_TTY:
            print(f"\r  {c('90', '启动中' + '·' * (dots % 4) + '   ')}", end="")
    print()
    return False


def open_browser() -> None:
    step("打开界面")
    if IS_MAC:
        subprocess.run(["open", URL], capture_output=True)
    elif platform.system() == "Windows":
        os.startfile(URL)  # type: ignore[attr-defined]
    else:
        subprocess.run(["xdg-open", URL], capture_output=True)
    ok(URL)


def summary(mode: str = "docker") -> None:
    print()
    print(c("1", "─" * 52))
    print(f"  {c('32;1', 'SciSpark 已就绪')}  →  {c('36', URL)}")
    print()
    info("首次使用：进「设置」填 DeepSeek API Key，测试连接通过即可")
    info("看花费：make cost   看日志：make logs   停止：双击「停止.command」")
    if mode == "native":
        if VENDOR_SITE:
            info("数据在 data/；运行环境是包内自带的 vendor/（删掉整个文件夹就等于卸载）")
        else:
            info("数据在 data/；运行环境在 .venv/（删掉整个文件夹就等于卸载）")
    else:
        info("数据在 data/；运行环境在 Docker 里（清理：python3 tools/launcher.py --clean）")
    print(c("1", "─" * 52))
    print()


# ----------------------------------------------------------------------
# 子命令
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------
# 模式选择
# ----------------------------------------------------------------------
def docker_ready() -> bool:
    """Docker 装没装、守护进程起没起。"""
    return bool(shutil.which("docker")) and docker_alive()


def pick_mode(args: argparse.Namespace) -> str:
    step("选择运行方式")
    if getattr(args, "native", False):
        ok("按你的要求用「原生模式」（不需要 Docker）")
        return "native"
    if getattr(args, "docker", False):
        ok("按你的要求用「Docker 模式」")
        return "docker"

    if docker_ready():
        ok("检测到 Docker，用 Docker 模式（环境隔离，最省心）")
        return "docker"

    if shutil.which("docker"):
        warn("装了 Docker 但没启动，改用原生模式（不想等也可以手动开 Docker 再试）")
    else:
        info("没检测到 Docker，用原生模式（需要 Python 3.10+，会自动装依赖）")
    return "native"


# ----------------------------------------------------------------------
# 首次安装向导
# ----------------------------------------------------------------------
INSTALL_MARKER = ROOT / "data" / ".install_mode"


def saved_mode() -> str | None:
    """读取上次选定的安装方式（docker / native）。"""
    try:
        v = INSTALL_MARKER.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return v if v in ("docker", "native") else None


def save_mode(mode: str) -> None:
    try:
        INSTALL_MARKER.parent.mkdir(parents=True, exist_ok=True)
        INSTALL_MARKER.write_text(mode, encoding="utf-8")
    except OSError:
        pass


def detect_mode() -> str | None:
    """推断安装方式：有记录用记录；否则优先认 Docker 镜像，再看 .venv。"""
    m = saved_mode()
    if m:
        return m
    # 镜像比 .venv 更能说明「之前真的用 Docker 装过」，优先认它
    if docker_ready() and image_exists():
        return "docker"
    if VENV.exists():
        return "native"
    return None


def ask_install_mode() -> str:
    """（已废弃）旧的首次安装向导。

    现在不再问了：直接把程序装在用户解压出来的这个文件夹里（原生模式），
    不依赖 Docker、不受 Docker 磁盘授权限制，删掉文件夹就等于卸载。
    只在当前 Python 太旧、装不了原生模式时才回退到 Docker。
    保留这个函数只是为了兼容老的调用方。
    """
    return choose_mode(argparse.Namespace(native=False, docker=False))


def choose_mode(args: argparse.Namespace) -> str:
    """决定怎么跑，不再打断用户。优先级：命令行参数 > 上次的选择 > 自动判断。"""
    if getattr(args, "native", False):
        ok("按参数要求用「独立安装」（不用 Docker）")
        return "native"
    if getattr(args, "docker", False):
        ok("按参数要求用「Docker 模式」")
        return "docker"

    saved = saved_mode()
    if saved:
        ok("沿用上次的安装方式：" + ("Docker" if saved == "docker" else "独立安装（装在当前文件夹）"))
        return saved

    # 发布包里带了自带运行时 → 直接就地运行，不用装 Python、不用联网
    if vendor_runtime():
        ok("使用包内自带的运行环境（不用装 Python，也不用下载依赖）")
        info(f"运行环境就在 {VENDOR / platform_key()}，删掉整个文件夹就等于卸载")
        save_mode("native")
        return "native"

    # 这台机器之前用 Docker 装过（镜像还在）→ 沿用，避免老用户下次启动突然重装一遍
    if docker_ready() and image_exists():
        ok("检测到之前用 Docker 装过，继续用 Docker 模式")
        save_mode("docker")
        return "docker"

    # 首次启动：默认就地安装（.venv 就在这个文件夹里），
    # 最符合「解压到哪就装在哪」，也不用管 Docker 的磁盘授权
    if sys.version_info >= (3, 10):
        ok(f"直接装在这个文件夹里（Python {platform.python_version()}，不需要 Docker）")
        info(f"依赖会装进 {ROOT / '.venv'}，删掉这个文件夹就等于卸载")
        save_mode("native")
        return "native"

    if docker_ready():
        warn(f"当前 Python {platform.python_version()} 太旧（需要 3.10+），改用 Docker 模式")
        save_mode("docker")
        return "docker"

    die(
        f"这台电脑的 Python 版本太低（{platform.python_version()}，需要 3.10 以上）",
        "装一个 Python 3.10+ 再双击「启动」；或者装 Docker Desktop 后重新启动（会自动用 Docker 模式）",
    )
    return "native"  # 不会执行到



# ----------------------------------------------------------------------
# 原生模式
# ----------------------------------------------------------------------
VENDOR = ROOT / "vendor"
VENDOR_SITE: Path | None = None  # 由 ensure_venv 设置，native_env 会把它加进 PYTHONPATH


def platform_key() -> str:
    """包内运行时的目录名，和 vendor/ 下的子目录一致。"""
    s = platform.system()
    m = platform.machine().lower()
    if s == "Darwin":
        return "macos-arm64" if m in ("arm64", "aarch64") else "macos-x64"
    if s == "Windows":
        return "win-x64" if m in ("amd64", "x86_64") else "win-arm64"
    return "linux-arm64" if m in ("arm64", "aarch64") else "linux-x64"


def vendor_runtime() -> tuple[Path, Path] | None:
    """包内自带的 Python 运行时 → (解释器, site-packages)；没有就返回 None。

    这样第一次启动完全不用联网：解释器和依赖都在压缩包里。
    """
    d = VENDOR / platform_key()
    if not d.is_dir():
        return None
    py = d / "runtime" / ("python.exe" if IS_WIN else "bin/python3")
    if not py.exists():
        return None
    return py, d / "site-packages"


def clear_quarantine() -> None:
    """macOS 从 zip 解压出来的可执行文件会带 com.apple.quarantine。

    这个标记不只是拦双击：内核会在 exec 时**直接 SIGKILL** 未放行的二进制，
    连报错都没有。包内自带的 Python 一旦带这个标记，第一次启动就莫名其妙卡住。
    .command 脚本里已经清过一次，这里再兜底，保证直接跑 launcher.py 也行。
    """
    if not IS_MAC or not shutil.which("xattr"):
        return
    probe = VENDOR / platform_key() / "runtime" / "bin" / "python3"
    if not probe.exists():
        return
    r = subprocess.run(
        ["xattr", "-p", "com.apple.quarantine", str(probe)],
        capture_output=True,
    )
    if r.returncode != 0:  # 没有隔离标记，不用扫全目录
        return
    info("首次运行：清除 macOS 给解压文件加的隔离标记")
    subprocess.run(
        ["xattr", "-dr", "com.apple.quarantine", str(ROOT)],
        capture_output=True,
    )


def ensure_venv() -> Path:
    global VENDOR_SITE
    import hashlib

    step("准备运行环境")

    v = vendor_runtime()
    if v:
        py, site = v
        VENDOR_SITE = site
        ok(f"使用包内自带的 Python 运行时（{platform_key()}），不需要联网")
        if (site / "fastapi").is_dir():
            ok("依赖已就绪")
            return py

        wheels = site.parent / "wheels"
        info("首次启动：把随包带的依赖展开到 vendor（约 30 秒，不联网、不下载）")
        r = subprocess.run(
            [
                str(py), "-m", "pip", "install", "-q", "--no-index",
                "--find-links", str(wheels), "--target", str(site),
                "--disable-pip-version-check", "-r", str(REQ),
            ]
        )
        if r.returncode != 0 or not (site / "fastapi").is_dir():
            warn("包内依赖展开失败，回退到联网安装")
            VENDOR_SITE = None
        else:
            ok("依赖已就绪")
            return py

    if sys.version_info < (3, 10):
        die(
            f"这台电脑的 Python 版本太低（{platform.python_version()}，需要 3.10+）",
            "用带离线运行时的发布包（解压即可，不需要装 Python）；"
            "或者装个 Docker Desktop 用容器模式",
        )

    if not VENV_PY.exists():
        info("第一次运行，创建 .venv（不会污染系统 Python）")
        r = subprocess.run([sys.executable, "-m", "venv", str(VENV)])
        if r.returncode != 0 or not VENV_PY.exists():
            die(
                "创建虚拟环境失败",
                "Debian/Ubuntu 需要先 apt install python3-venv；"
                "Windows 请用 python.org 的安装包（勾选 Add to PATH）",
            )

    want = hashlib.sha256(REQ.read_bytes()).hexdigest()[:16] if REQ.exists() else "none"
    marker = VENV / ".deps-ok"
    if marker.exists() and marker.read_text(encoding="utf-8").strip() == want:
        ok("依赖已就绪")
        return VENV_PY

    info("安装 Python 依赖（首次约 1~3 分钟）：")
    info("  · 从清华 PyPI 镜像下载后端依赖，约 150 MB")
    info("  · 都是公开可信的开源包，只装进这个文件夹的 .venv，不碰系统 Python")
    info("  下面会显示每个包的下载进度，可以不用管它。")
    print()
    subprocess.run(
        [str(VENV_PY), "-m", "pip", "install", "--upgrade", "pip"],
        capture_output=True,
    )
    mirror = os.environ.get("PIP_INDEX_URL", "https://pypi.tuna.tsinghua.edu.cn/simple")
    base = [str(VENV_PY), "-m", "pip", "install", "--progress-bar", "on", "-r", str(REQ)]
    r = subprocess.run([*base, "-i", mirror])
    if r.returncode != 0:
        warn("镜像源装不上，改用官方源重试")
        r = subprocess.run(base)
    if r.returncode != 0:
        die("依赖安装失败", "检查网络；或设 PIP_INDEX_URL 指向可用镜像")

    marker.write_text(want, encoding="utf-8")
    ok("依赖安装完成")
    return VENV_PY


def ensure_dist() -> None:
    """原生模式没有容器帮忙构建前端，这里要确保静态文件在。"""
    if (DIST / "index.html").exists():
        ok("前端静态文件已就绪")
        return

    step("构建前端")
    npm = shutil.which("npm")
    if not npm:
        die(
            "找不到已构建的前端，也没有 npm",
            "两条路：1) 用 Docker 模式（会自动构建）；"
            "2) 装 Node 18+ 后重跑，或直接用发布包里带 dist 的版本",
        )
    info("用 npm 构建（首次约 1~2 分钟）")
    if not (ROOT / "frontend" / "node_modules").exists():
        subprocess.run([npm, "install"], cwd=ROOT / "frontend")
    r = subprocess.run([npm, "run", "build"], cwd=ROOT / "frontend")
    if r.returncode != 0 or not (DIST / "index.html").exists():
        die("前端构建失败", "看上面的 npm 输出")


def native_env() -> dict:
    env = dict(os.environ)
    env.update(
        {
            "DATA_DIR": str(ROOT / "data"),
            "DB_PATH": str(ROOT / "data" / "app.db"),
            "STATIC_DIR": str(DIST),
            "LOCAL_PAPERS_DIR": str(ROOT / "local_papers"),
            # 原生模式下没有容器挂载，这两个留空让 host_fs 走「路径直通」
            "HOST_HOME_DIR": str(Path.home()),
            "HOST_MOUNT": str(ROOT / ".no-mount"),
            "TZ": os.environ.get("TZ", "Asia/Shanghai"),
            "PYTHONUNBUFFERED": "1",
            "PYTHONPATH": (
                f"{VENDOR_SITE}{os.pathsep}{ROOT / 'backend'}"
                if VENDOR_SITE
                else str(ROOT / "backend")
            ),
        }
    )
    return env


def start_native(no_browser: bool = False) -> None:
    py = ensure_venv()
    ensure_dist()

    step("启动服务")
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    log_file = open(ROOT / "data" / "server.log", "ab", buffering=0)
    proc = subprocess.Popen(
        [
            str(py), "-m", "uvicorn", "app.main:app",
            "--host", "127.0.0.1", "--port", str(PORT), "--proxy-headers",
        ],
        cwd=ROOT / "backend",
        env=native_env(),
        stdout=log_file,
        stderr=subprocess.STDOUT,
    )
    PID_FILE.write_text(str(proc.pid), encoding="utf-8")
    ok(f"进程已启动（PID {proc.pid}），日志：data/server.log")

    if not wait_healthy():
        proc.terminate()
        die("服务没能在 3 分钟内就绪", "看 data/server.log 里的报错")

    if not no_browser:
        open_browser()
    summary("native")
    print(c("90", "  服务在前台运行：点界面左下角「关闭 SciSpark」或按 Ctrl+C 结束。\n"))

    try:
        proc.wait()
    except KeyboardInterrupt:
        print()
        warn("正在停止…")
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
    finally:
        PID_FILE.unlink(missing_ok=True)
    print(c("90", "  已停止，数据都在 data/ 里。\n"))


def stop_native() -> bool:
    if not PID_FILE.exists():
        return False
    try:
        pid = int(PID_FILE.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        PID_FILE.unlink(missing_ok=True)
        return False

    step("停止本地进程")
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True)
        else:
            os.kill(pid, 15)
    except (ProcessLookupError, OSError):
        pass
    PID_FILE.unlink(missing_ok=True)
    ok("已停止（数据保留在 ./data）")
    return True


# ----------------------------------------------------------------------
# 命令
# ----------------------------------------------------------------------
def container_belongs_here() -> bool:
    """这个文件夹的容器在跑吗？（用挂载路径判断，避免把别的目录的实例当自己）"""
    try:
        r = subprocess.run(
            ["docker", "inspect", "scispark", "--format", "{{range .Mounts}}{{.Source}}\n{{end}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if r.returncode != 0:
            return False
        sources = (r.stdout or "").strip()
        return str((ROOT / "data").resolve()) in sources
    except (OSError, subprocess.SubprocessError):
        return False


def cmd_start(args: argparse.Namespace) -> None:
    # ---- 先确定用哪个端口 ----
    # 8000 上「有东西在监听」不代表就是 SciSpark：很可能是别的软件（C-Lodop 打印服务、
    # 各种开发服务器……）。以前这里只看端口通不通，结果把别人的网页当成了自己的界面。
    try:
        preferred = int(os.environ.get("APP_PORT") or 8000)
    except ValueError:
        preferred = 8000

    if not args.rebuild and port_in_use(preferred):
        if is_scispark(preferred) and (PID_FILE.exists() or container_belongs_here()):
            # 确实是「这个文件夹」的实例在跑 → 直接打开
            set_port(preferred)
            warn("这个程序已经在运行了（就在当前文件夹）")
            info("如果你想重新启动：先双击「停止.command」，再双击「启动.command」")
            if not args.no_browser:
                open_browser()
            summary(saved_mode() or "native")
            return

        alt = find_free_port(preferred + 1)
        set_port(alt)
        if is_scispark(preferred):
            warn(f"{preferred} 上已经跑着另一个 SciSpark（可能是从别的文件夹启动的）")
            info(f"为避免看到别的文件夹的数据，这个文件夹改用 {alt} 端口启动自己的实例")
        else:
            warn(f"{preferred} 端口被别的软件占用了（不是 SciSpark）")
            info(f"已自动改用 {alt} 端口，不影响使用，浏览器会自动打开新地址")
    else:
        set_port(find_free_port(preferred))

    ensure_env()
    silence_spotlight()
    clear_quarantine()
    ensure_demo_data()

    mode = choose_mode(args)

    if mode == "native":
        start_native(getattr(args, "no_browser", False))
        return

    ensure_docker()
    check_resources()
    compose = compose_cmd()
    ensure_frontend_dist()

    # 镜像已经在本地就只启动，不重新构建。
    # 之前默认带 --build，Docker 用 BuildKit 且缓存为空时会从零装依赖，
    # 看起来就像「莫名其妙在下载软件」。
    need_build = args.rebuild or not image_exists()
    if not need_build:
        info("镜像已存在，直接启动（不重新构建）")
    compose_up(compose, build=need_build)

    if not wait_healthy():
        die("应用没能在 3 分钟内就绪", "看日志找原因：make logs")

    if not args.no_browser:
        open_browser()
    summary("docker")
    print(c("90", "  服务在后台运行：点界面左下角「关闭 SciSpark」即可停止。\n"))


def cmd_stop() -> None:
    if stop_native():
        return
    if not shutil.which("docker"):
        warn("没找到 Docker，也没有正在运行的本地进程")
        return
    compose = compose_cmd()
    step("停止容器")
    subprocess.run([*compose, "down"], cwd=ROOT)
    ok("已停止（数据保留在 ./data）")


def cmd_logs() -> None:
    if PID_FILE.exists():
        step("跟踪日志（Ctrl+C 退出）")
        subprocess.run(["tail", "-f", str(ROOT / "data" / "server.log")])
        return
    compose = compose_cmd()
    step("跟踪日志（Ctrl+C 退出）")
    subprocess.run([*compose, "logs", "-f", "--tail=120"], cwd=ROOT)


def cmd_status() -> None:
    step("状态")
    # 端口可能是 8000，也可能因为被占用而换成 8001+，扫一遍找 SciSpark
    try:
        base = int(os.environ.get("APP_PORT") or 8000)
    except ValueError:
        base = 8000
    found = None
    for p in range(base, base + 20):
        if port_in_use(p) and is_scispark(p):
            found = p
            break
    if found:
        set_port(found)

    if PID_FILE.exists():
        ok(f"运行方式：独立安装（PID {PID_FILE.read_text(encoding='utf-8').strip()}）")
    elif docker_ready():
        state = container_state(compose_cmd())
        ok(f"运行方式：Docker（{state or '未启动'}）")
    else:
        info("运行方式：未启动")

    if found:
        ok(f"应用可访问：{URL}")
    elif port_in_use(8000):
        warn("8000 被别的软件占用（不是 SciSpark），启动时会自动换端口")
    else:
        warn("服务没在运行")

    db = ROOT / "data" / "app.db"
    if db.exists():
        mb = db.stat().st_size / 1024 / 1024
        ok(f"数据库：data/app.db（{mb:.1f} MB）")
    if not VENV.exists() and not docker_ready():
        info("首次用原生模式会创建 .venv 并装依赖")


def cmd_clean() -> None:
    """删除运行环境（容器 + 镜像），释放空间。data/ 里的数据不动。"""
    step("清理运行环境")
    if PID_FILE.exists():
        stop_native()
    if docker_ready():
        compose = compose_cmd()
        info("停止并删除容器…")
        subprocess.run([*compose, "down"], cwd=ROOT, capture_output=True)
        info("删除镜像（约 700 MB）…")
        subprocess.run(["docker", "rmi", "scispark:latest"], capture_output=True)
    ok("运行环境已删除")
    info("你的数据还在 data/ 里，没有动。")
    info("下次启动会重新下载环境（约 1~2 分钟）。")


def main() -> None:
    p = argparse.ArgumentParser(description="SciSpark 一键启动")
    p.add_argument("--native", action="store_true", help="不用 Docker，直接跑本地 Python")
    p.add_argument("--docker", action="store_true", help="强制使用 Docker")
    p.add_argument("--rebuild", action="store_true", help="强制重新构建镜像（慢，会下载依赖）")
    p.add_argument("--no-build", action="store_true", help="兼容旧参数；现在默认不构建")
    p.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    p.add_argument("--stop", action="store_true", help="停止")
    p.add_argument("--logs", action="store_true", help="跟踪日志")
    p.add_argument("--status", action="store_true", help="只看状态")
    p.add_argument("--clean", action="store_true", help="删除运行环境（容器 + 镜像），数据不动")
    args = p.parse_args()

    print()
    print(c("36;1", "  SciSpark · 科研创新助手"))
    print(c("90", "  读论文 → 梳理逻辑 → 找空白 → 对话收敛"))

    if not (ROOT / "docker-compose.yml").exists():
        die(f"这里不像项目根目录：{ROOT}", "把 launcher 放在项目里跑")

    if args.stop:
        cmd_stop()
    elif args.logs:
        cmd_logs()
    elif args.status:
        cmd_status()
    elif args.clean:
        cmd_clean()
    else:
        cmd_start(args)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n已中断。")
        sys.exit(130)
