#!/bin/bash
# 双击这个文件即可启动 SciSpark（macOS）
cd "$(dirname "$0")" || exit 1

# 自愈：macOS 会给"从网上下载 / 微信 QQ 传来"的文件加隔离标记，导致双击被拦。
# 只要脚本被成功运行过一次（哪怕是拖进终端运行的），就把整个文件夹的标记清掉，
# 以后双击「启动」「停止」都不会再弹"无法验证开发者"。
if command -v xattr >/dev/null 2>&1; then
  xattr -dr com.apple.quarantine . 2>/dev/null
fi
for f in "启动.command" "停止.command"; do
  chmod +x "$f" 2>/dev/null
done

if ! command -v python3 >/dev/null 2>&1; then
  echo "没找到 python3。装一个：在终端执行 xcode-select --install"
  read -r -p "按回车关闭…" _
  exit 1
fi

python3 tools/launcher.py "$@"
rc=$?

if [ $rc -ne 0 ]; then
  echo
  read -r -p "启动失败，按回车关闭窗口…" _
fi
exit $rc
